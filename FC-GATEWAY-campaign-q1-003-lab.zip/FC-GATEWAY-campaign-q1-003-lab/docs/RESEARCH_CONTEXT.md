# Research Context Preserved From The Conversation

FC Gateway v0.1 emerged from a broader research thread on Fiduciary Computation, Durable Fiduciary Deeds and the collaboration around ACI / Technical Species.

## Intellectual Ladder

```text
Negentropy -> Fiduciary Computation -> DFD -> protocols -> software -> use cases
```

Negentropy remains the long-horizon research question: how structures preserve constitutive invariants under noise, transformation and time.

Fiduciary Computation is the applied field: explicit conditions for determining which facts can acquire consequences inside a system, while preserving independently verifiable evidence of that admission.

DFD is the primitive: a durable, identifiable computational deed whose admission conditions, authority, evidence, temporal context and lineage remain verifiable.

FC Gateway is the first product-shaped kernel: a fiduciary admission boundary between intelligence and consequence.

## ACI / DFD Bridge

Pedro's ACI work asks what an industrial cognitive infrastructure should learn and transmit across its life cycle. FC asks under what conditions those observations may be admitted as reliable machine experience.

The joint architecture is:

```text
Physical Event
  -> Fiduciary Gate
  -> DFD
  -> Cognitive Gate
  -> Knowledge
  -> Inheritance
```

Key distinction:

```text
Observation != Admitted Fact != Knowledge != Model
```

The ACI remembers. The fiduciary system proves where the remembered content came from.

## Epistemic Membrane

The conversation reframed Sentinel/JANO not merely as an immune system, but as an epistemic or fiduciary membrane.

It asks:

```text
What can cross the boundary and acquire the capacity to produce future consequences?
```

For FC Gateway, that boundary becomes practical:

```text
Information -> Fiduciary Admission -> Consequence
```

## Paper-Level Contribution

A publishable formulation preserved from the conversation:

```text
A cognitive system should not be allowed to transform an observation into inherited machine experience unless the conditions under which that observation entered the system remain verifiable.
```

Potential paper title:

```text
Fiduciary Admission for Cognitive Infrastructures: Verifiable Lineage of Machine Experience
```

Four contribution claims:

- Fiduciary Epistemic Membrane: formal boundary between physical observation and cognitive memory.
- Durable Fiduciary Deed: durable unit of admitted evidence preserving authority, time, provenance, integrity and lineage.
- Knowledge Lineage: explicit relation from evidence to knowledge to model.
- Adversarial Evaluation: whether corrupted, duplicated, incoherent or degraded observations can silently contaminate learning and inherited memory.

## Why It Matters For The MVP

The first product does not need to prove Technical Species. It proves a narrower operational statement:

```text
Cognitive compromise does not imply consequential authority.
```

That statement is testable with a small local gateway in front of tools and APIs.

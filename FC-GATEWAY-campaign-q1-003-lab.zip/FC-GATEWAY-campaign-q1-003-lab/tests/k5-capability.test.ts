import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  FiduciarySecurityError,
  assertValidCapabilityToken,
  computeCapabilityMac,
  generateEd25519KeyPair,
  issueCapabilityToken,
  signAuthorityClaim,
  tryIssueCapabilityToken,
} from "../src/index.js";
import type { FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

function setup() {
  const auth = generateEd25519KeyPair();
  const sealerKeys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "agent" };
  const policy: FiduciaryPolicy = {
    policyId: "pol",
    version: "1",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 3,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "ev1",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1000,
  };
  const proposal: Proposal = {
    proposalId: "p1",
    actor,
    action: "bank.transfer",
    target: "acct",
    parameters: { amount: 10 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1500,
  };
  const claim = signAuthorityClaim(
    {
      claimId: "c1",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1000,
      expiresAt: 5000,
      nonce: "n",
    },
    auth.privateKeyPem,
  );
  const engine = new FiduciaryEngine();
  const decision = engine.evaluate(proposal, [policy], [claim], trustedIssuers, [evidence], 2000);
  return { auth, sealerKeys, trustedIssuers, actor, policy, evidence, proposal, claim, engine, decision };
}

test("K5 no ADMIT -> no capability", () => {
  const f = setup();
  const rejected = { ...f.decision, result: "REJECT" as const };
  assert.equal(tryIssueCapabilityToken(rejected, f.proposal, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: 2000, hmacSecret }), null);
});

test("K5 bindings and MAC checks", () => {
  const f = setup();
  const token = issueCapabilityToken(f.decision, f.proposal, {
    issuer: "fc-gateway",
    audience: "fiduciary-executor",
    fiduciaryClock: 2000,
    hmacSecret,
  });
  assertValidCapabilityToken(token, f.decision, f.proposal, {
    expectedIssuer: "fc-gateway",
    expectedAudience: "fiduciary-executor",
    fiduciaryClock: 2100,
    hmacSecret,
  });

  assert.throws(
    () =>
      assertValidCapabilityToken(token, f.decision, { ...f.proposal, action: "other" }, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: 2100,
        hmacSecret,
      }),
    FiduciarySecurityError,
  );
  assert.throws(
    () =>
      assertValidCapabilityToken(token, f.decision, f.proposal, {
        expectedIssuer: "other",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: 2100,
        hmacSecret,
      }),
    /CAPABILITY_ISSUER_MISMATCH/,
  );
  assert.throws(
    () =>
      assertValidCapabilityToken(token, f.decision, f.proposal, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "other",
        fiduciaryClock: 2100,
        hmacSecret,
      }),
    /CAPABILITY_AUDIENCE_MISMATCH/,
  );
  assert.throws(
    () =>
      assertValidCapabilityToken(token, f.decision, f.proposal, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: token.expiresAt,
        hmacSecret,
      }),
    /CAPABILITY_EXPIRED_OR_PREDATED/,
  );
  assert.throws(
    () =>
      assertValidCapabilityToken(token, f.decision, f.proposal, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: token.issuedAt - 1,
        hmacSecret,
      }),
    /CAPABILITY_EXPIRED_OR_PREDATED/,
  );

  const tampered = { ...token, mac: "0".repeat(64) };
  assert.throws(
    () =>
      assertValidCapabilityToken(tampered, f.decision, f.proposal, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: 2100,
        hmacSecret,
      }),
    /INVALID_CAPABILITY_SIGNATURE/,
  );
  assert.throws(
    () =>
      assertValidCapabilityToken(token, f.decision, f.proposal, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: 2100,
        hmacSecret: Buffer.alloc(32, 9),
      }),
    /INVALID_CAPABILITY_SIGNATURE/,
  );
  assert.throws(
    () =>
      issueCapabilityToken(f.decision, f.proposal, {
        issuer: "fc-gateway",
        audience: "fiduciary-executor",
        fiduciaryClock: 2000,
        hmacSecret: Buffer.alloc(31, 1),
      }),
    /HMAC_SECRET_TOO_SHORT/,
  );

  const { mac: _mac, ...unsigned } = token;
  const reordered = {
    nonce: unsigned.nonce,
    scope: unsigned.scope,
    expiresAt: unsigned.expiresAt,
    issuedAt: unsigned.issuedAt,
    audience: unsigned.audience,
    issuer: unsigned.issuer,
    proposalHash: unsigned.proposalHash,
    admissionHash: unsigned.admissionHash,
    admissionId: unsigned.admissionId,
    tokenId: unsigned.tokenId,
  };
  assert.equal(computeCapabilityMac(reordered, hmacSecret), token.mac);
});

test("K5 valid capability is not consumed until journal reserve", async () => {
  const f = setup();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k5-"));
  try {
    const sealer = new DFDSealer("n", "k", f.sealerKeys.publicKeyPem, f.sealerKeys.privateKeyPem);
    const journal = new FiduciaryJournal(sealer, dir);
    const executor = new FiduciaryExecutor(hmacSecret, journal);
    const token = issueCapabilityToken(f.decision, f.proposal, {
      issuer: "fc-gateway",
      audience: "fiduciary-executor",
      fiduciaryClock: 2000,
      hmacSecret,
    });
    assert.equal(journal.isCapabilityConsumed(token.tokenId), false);
    assertValidCapabilityToken(token, f.decision, f.proposal, {
      expectedIssuer: "fc-gateway",
      expectedAudience: "fiduciary-executor",
      fiduciaryClock: 2100,
      hmacSecret,
    });
    assert.equal(journal.isCapabilityConsumed(token.tokenId), false);
    await executor.executeConsequence(f.proposal, f.decision, token, 2100, () => ({ ok: true }));
    assert.equal(journal.isCapabilityConsumed(token.tokenId), true);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

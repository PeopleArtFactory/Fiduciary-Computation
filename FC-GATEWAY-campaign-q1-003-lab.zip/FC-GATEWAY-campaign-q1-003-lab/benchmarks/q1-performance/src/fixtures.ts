import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryGateway,
  FiduciaryJournal,
  generateEd25519KeyPair,
  normalizeProposal,
  signAuthorityClaim,
} from "../../../dist/src/index.js";
import type {
  AdmissionDecision,
  AuthorityClaim,
  CapabilityToken,
  FiduciaryPolicy,
  JsonValue,
  Proposal,
  TrustedIssuer,
  VerifiedEvidenceRef,
} from "../../../dist/src/index.js";

export const HMAC_SECRET = Buffer.from(
  "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
  "hex",
);

export interface BenchFixture {
  rootDir: string;
  clock: number;
  auth: ReturnType<typeof generateEd25519KeyPair>;
  sealerKeys: ReturnType<typeof generateEd25519KeyPair>;
  trustedIssuers: TrustedIssuer[];
  policy: FiduciaryPolicy;
  evidence: VerifiedEvidenceRef;
  sealer: DFDSealer;
  claim: AuthorityClaim;
}

export function createBenchFixture(rootDir: string): BenchFixture {
  fs.mkdirSync(rootDir, { recursive: true });
  const auth = generateEd25519KeyPair();
  const sealerKeys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const policy: FiduciaryPolicy = {
    policyId: "pol_bank_transfer_01",
    version: "1.0",
    action: "FINANCIAL_TRANSFER",
    consequenceClass: "FINANCIAL",
    riskLevel: 3,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["ACCOUNT_STATUS"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "ev_account_01",
    type: "ACCOUNT_STATUS",
    producer: "ledger",
    contentHash: "a".repeat(64),
    verifiedAt: 1_000,
  };
  const claim = signAuthorityClaim(
    {
      claimId: "claim_transfer",
      issuer: "authority:finance-root",
      subject: "llm_agent_01",
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1_000,
      expiresAt: 9_999_999_999,
      nonce: "nonce_bench",
    },
    auth.privateKeyPem,
  );
  const sealer = new DFDSealer("fc-gateway-node-1", "authority:fc-root-01", sealerKeys.publicKeyPem, sealerKeys.privateKeyPem);
  return {
    rootDir,
    clock: 2_000,
    auth,
    sealerKeys,
    trustedIssuers,
    policy,
    evidence,
    sealer,
    claim,
  };
}

export function makeProposal(iteration: number, evidenceId: string): Proposal {
  return normalizeProposal({
    proposalId: `prop_bench_${iteration}_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    actor: { type: "ai", id: "llm_agent_01" },
    action: "FINANCIAL_TRANSFER",
    target: "account_7712",
    parameters: { amount: 1_000 },
    contextRefs: [evidenceId],
    requestedAt: 1_500,
  });
}

export function makeRawProposal(iteration: number, evidenceId: string): Record<string, unknown> {
  return {
    proposalId: `prop_bench_${iteration}_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    actor: { type: "ai", id: "llm_agent_01" },
    action: "FINANCIAL_TRANSFER",
    target: "account_7712",
    parameters: { amount: 1_000 },
    contextRefs: [evidenceId],
    requestedAt: 1_500,
    unsupportedNoise: true,
  };
}

export function openSession(fx: BenchFixture, label: string) {
  const dir = fs.mkdtempSync(path.join(fx.rootDir, `${label}-`));
  const journal = new FiduciaryJournal(fx.sealer, dir);
  const gateway = new FiduciaryGateway({
    policies: [fx.policy],
    trustedIssuers: fx.trustedIssuers,
    hmacSecret: HMAC_SECRET,
    journal,
    now: () => fx.clock,
  });
  const engine = new FiduciaryEngine();
  const executor = new FiduciaryExecutor(HMAC_SECRET, journal);
  return { dir, journal, gateway, engine, executor };
}

export async function protectedOperation(input: JsonValue): Promise<{ ok: true; input: JsonValue }> {
  return { ok: true, input };
}

export type { AdmissionDecision, CapabilityToken, Proposal };

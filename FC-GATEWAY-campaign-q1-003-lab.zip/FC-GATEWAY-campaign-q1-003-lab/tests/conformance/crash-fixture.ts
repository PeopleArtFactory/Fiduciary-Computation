import * as fs from "node:fs";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  issueCapabilityToken,
  normalizeProposal,
  signAuthorityClaim,
} from "../../src/index.js";
import type { AuthorityClaim, FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../../src/index.js";

export interface CrashFixtureBundle {
  dir: string;
  hmacSecretHex: string;
  sealerPublicKeyPem: string;
  sealerPrivateKeyPem: string;
  sealerIssuer: string;
  sealerIssuerKeyId: string;
  proposal: Proposal;
  decisionJson: string;
  capabilityJson: string;
  fiduciaryClock: number;
}

export function writeCrashFixture(bundle: CrashFixtureBundle): string {
  const file = `${bundle.dir}/crash-fixture.json`;
  fs.writeFileSync(file, JSON.stringify(bundle), "utf8");
  return file;
}

export function readCrashFixture(file: string): CrashFixtureBundle {
  return JSON.parse(fs.readFileSync(file, "utf8")) as CrashFixtureBundle;
}

export function buildCrashRuntime(bundle: CrashFixtureBundle) {
  const sealer = new DFDSealer(bundle.sealerIssuer, bundle.sealerIssuerKeyId, bundle.sealerPublicKeyPem, bundle.sealerPrivateKeyPem);
  const journal = new FiduciaryJournal(sealer, bundle.dir);
  const executor = new FiduciaryExecutor(Buffer.from(bundle.hmacSecretHex, "hex"), journal);
  return { sealer, journal, executor };
}

export async function prepareCrashBundle(dir: string): Promise<CrashFixtureBundle> {
  const { generateEd25519KeyPair } = await import("../../src/index.js");
  const auth = generateEd25519KeyPair();
  const sealerKeys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "agent" };
  const policy: FiduciaryPolicy = {
    policyId: "pol",
    version: "1",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 2,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "ev",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1_000,
  };
  const proposal = normalizeProposal({
    proposalId: "p",
    actor,
    action: "bank.transfer",
    target: "t",
    parameters: { amount: 10 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1_500,
  });
  const claim: AuthorityClaim = signAuthorityClaim(
    {
      claimId: "c",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1_000,
      expiresAt: 9_999,
      nonce: "n",
    },
    auth.privateKeyPem,
  );
  const engine = new FiduciaryEngine();
  const decision = engine.evaluate(proposal, [policy], [claim], trustedIssuers, [evidence], 2_000);
  const hmacSecretHex = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
  const capability = issueCapabilityToken(decision, proposal, {
    issuer: "fc-gateway",
    audience: "fiduciary-executor",
    fiduciaryClock: 2_000,
    hmacSecret: Buffer.from(hmacSecretHex, "hex"),
  });
  return {
    dir,
    hmacSecretHex,
    sealerPublicKeyPem: sealerKeys.publicKeyPem,
    sealerPrivateKeyPem: sealerKeys.privateKeyPem,
    sealerIssuer: "node",
    sealerIssuerKeyId: "root",
    proposal,
    decisionJson: JSON.stringify(decision),
    capabilityJson: JSON.stringify(capability),
    fiduciaryClock: 2_100,
  };
}

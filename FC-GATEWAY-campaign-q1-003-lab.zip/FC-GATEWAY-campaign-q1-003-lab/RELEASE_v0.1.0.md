# FC Gateway v0.1.0-conformant

Evidence-only release note. No security claims beyond the measured gates.

```text
Kernel tests:           58/58 PASS
Conformance result:     CONFORMANT
Runtime dependencies:   0
Distributable bytes:    75018 (< 1400000)
Report hash:            5869dcfaa6357746a0c34050016ae951e593c078f59b235c207d95e6449efb53
```

## Frozen protocol constructions

```text
Ed25519 (AuthorityClaim / Checkpoint / Lineage):
  M = UTF8( JCS({ domain: D, ...payloadFields }) )
  σ = Ed25519.Sign(sk, M)
  (no SHA-256 prehash inside the signature message)

Capability MAC:
  HMAC-SHA256(Kc, UTF8(D) || 0x00 || UTF8(JCS(CapabilityToken - {mac})))
  D = FCG:v0.1:CAPABILITY
  |Kc| >= 32 bytes

Canonical identity:
  SHA-256( UTF8( JCS(value) ) )

Lineage genesis:
  FCG_GENESIS_HASH
```

See `docs/DECISIONS.md` for the normative freeze text and `tests/protocol-freeze.test.ts` for stable regression vectors.

## Claim scope

`CONFORMANT` means this implementation satisfied the declared FC Gateway v0.1 conformance gates represented by the evidence artifacts produced by `pnpm release:check`.

It does not constitute a proof of security outside the declared threat model or TCB.

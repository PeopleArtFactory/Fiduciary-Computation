import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  generateEd25519KeyPair,
  signAuthorityClaim,
  verifyLineage,
} from "../src/index.js";
import type { FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k6-"));
  const auth = generateEd25519KeyPair();
  const sealerKeys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "a1" };
  const policy: FiduciaryPolicy = {
    policyId: "pol",
    version: "1",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 2,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "ev",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1,
  };
  const proposal: Proposal = {
    proposalId: "p",
    actor,
    action: "bank.transfer",
    target: "t",
    parameters: { amount: 1 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 2,
  };
  const claim = signAuthorityClaim(
    {
      claimId: "c",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1,
      expiresAt: 9_999,
      nonce: "n",
    },
    auth.privateKeyPem,
  );
  const sealer = new DFDSealer("node", "root", sealerKeys.publicKeyPem, sealerKeys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir);
  const engine = new FiduciaryEngine();
  const executor = new FiduciaryExecutor(hmacSecret, journal);
  return { dir, sealerKeys, trustedIssuers, policy, evidence, proposal, claim, sealer, journal, engine, executor };
}

test("K6 verifyLineage accepts open PREPARED with closureComplete=false", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 100);
    const cap = f.engine.mintCapability(decision, f.proposal, hmacSecret, 100)!;
    f.journal.reserveExecution({
      tokenId: cap.tokenId,
      admissionHash: decision.admissionHash,
      proposalHash: decision.proposalHash,
      actor: f.proposal.actor,
      action: f.proposal.action,
      target: f.proposal.target,
      timestamp: 100,
    });
    const { report } = verifyLineage(f.journal.readAllDeeds(), { sealerPublicKeyPem: f.sealerKeys.publicKeyPem });
    assert.equal(report.integrityValid, true);
    assert.equal(report.openPreparedCount, 1);
    assert.equal(report.closureComplete, false);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K6 ADV-03 mutation fails verifyLineage", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 100);
    const cap = f.engine.mintCapability(decision, f.proposal, hmacSecret, 100)!;
    await f.executor.executeConsequence(f.proposal, decision, cap, 110, () => ({ ok: true }));
    const lineagePath = f.journal.getLineagePath();
    const text = fs.readFileSync(lineagePath, "utf8").replace("OUTCOME_SUCCESS", "OUTCOME_NO_EFFECT");
    fs.writeFileSync(lineagePath, text);
    assert.throws(
      () => verifyLineage(JSON.parse(`[${text.trim().split(/\r?\n/).join(",")}]`) as never, { sealerPublicKeyPem: f.sealerKeys.publicKeyPem }),
      /CRITICAL_JOURNAL_CORRUPTION/,
    );
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K6 checkpoint relative completeness", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 100);
    const cap = f.engine.mintCapability(decision, f.proposal, hmacSecret, 100)!;
    await f.executor.executeConsequence(f.proposal, decision, cap, 110, () => ({ ok: true }));
    const checkpoint = f.journal.generateCheckpoint(200);
    const deeds = f.journal.readAllDeeds();
    const truncated = deeds.slice(0, -1);
    assert.throws(
      () =>
        verifyLineage(truncated, {
          sealerPublicKeyPem: f.sealerKeys.publicKeyPem,
          checkpoint,
          trustedIssuersForCheckpoint: [{ issuerId: f.sealer.issuerKeyId, publicKeyPem: f.sealerKeys.publicKeyPem }],
        }),
      /CHECKPOINT_MISMATCH|INVALID_CHECKPOINT/,
    );
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

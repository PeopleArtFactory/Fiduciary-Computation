$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

Write-Host "== FC Gateway lab bootstrap =="
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "node required" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw "git required" }

if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  if (Get-Command corepack -ErrorAction SilentlyContinue) {
    corepack enable
    corepack prepare pnpm@10.0.0 --activate
  } else {
    throw "pnpm not found; install pnpm 10 or enable corepack"
  }
}

Write-Host "node: $(node -v)"
Write-Host "pnpm: $(pnpm -v)"
if ((pnpm -v).Trim() -ne "10.0.0") { throw "campaign-q1-003 requires pnpm 10.0.0 exactly" }

pnpm install --frozen-lockfile

if (-not (Test-Path .git)) {
  git init
  git add -A
  git -c user.email="lab@fc-gateway.local" -c user.name="FC Gateway Lab" commit -m "lab: bootstrap campaign-q1-003 pack"
  Write-Host "Created local git commit for clean-tree gate."
}

pnpm build
pnpm test

Write-Host ""
Write-Host "Bootstrap OK. Next: .\lab\01-pilot.ps1 then .\lab\02-campaign-q1-003.ps1"
Write-Host "HEAD=$(git rev-parse HEAD)"

import { spawnSync } from "node:child_process";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { createOpenPreparedFixture } from "./recovery-fixtures.js";
import type { BenchFixture } from "./fixtures.js";
import type { BenchmarkSample } from "./statistics.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const workerJs = path.resolve(here, "b6-worker.js");

export interface B6Sample extends BenchmarkSample {
  coldProcessNs: string;
  bootstrapNs: string;
  reconcileNs: string;
  coreRecoveryNs: string;
}

function runWorker(journalDir: string): {
  closed: number;
  closureCount: number;
  integrityValid: boolean;
  openPreparedCount: number;
  coldProcessNs: string;
  bootstrapNs: string;
  reconcileNs: string;
  coreRecoveryNs: string;
  identityOk: boolean;
} {
  const res = spawnSync(process.execPath, [workerJs, journalDir], {
    encoding: "utf8",
    cwd: path.resolve(here, "../../.."),
  });
  if (res.status !== 0) {
    throw new Error(`INVALID_MEASUREMENT: B6 worker failed: ${res.stderr || res.stdout}`);
  }
  return JSON.parse(res.stdout) as ReturnType<typeof runWorker>;
}

export async function runB6(fx: BenchFixture, samples: number, warmup: number): Promise<B6Sample[]> {
  const out: B6Sample[] = [];

  const one = (iteration: number, record: boolean) => {
    const fixture = createOpenPreparedFixture(fx, `b6-${iteration}`);
    const first = runWorker(fixture.dir);
    if (!first.identityOk) throw new Error("INVALID_MEASUREMENT: B6 timing identity failed");
    if (first.closed !== 1 || first.closureCount !== 1 || first.openPreparedCount !== 0 || !first.integrityValid) {
      throw new Error("INVALID_MEASUREMENT: B6 first reconcile invariants failed");
    }
    const second = runWorker(fixture.dir);
    if (
      second.closed !== 0 ||
      second.closureCount !== 1 ||
      second.openPreparedCount !== 0 ||
      !second.integrityValid
    ) {
      throw new Error("INVALID_MEASUREMENT: B6 idempotence failed (second startup invariants)");
    }

    const sample: B6Sample = {
      benchmark: "B6",
      iteration,
      durationNs: first.coreRecoveryNs,
      success: true,
      coldProcessNs: first.coldProcessNs,
      bootstrapNs: first.bootstrapNs,
      reconcileNs: first.reconcileNs,
      coreRecoveryNs: first.coreRecoveryNs,
      meta: {
        coldProcessNs: first.coldProcessNs,
        bootstrapNs: first.bootstrapNs,
        reconcileNs: first.reconcileNs,
        coreRecoveryNs: first.coreRecoveryNs,
        secondClosed: second.closed,
      },
    };
    if (record) out.push(sample);
  };

  for (let i = 0; i < warmup; i++) one(i, false);
  for (let i = 0; i < samples; i++) one(i, true);
  return out;
}

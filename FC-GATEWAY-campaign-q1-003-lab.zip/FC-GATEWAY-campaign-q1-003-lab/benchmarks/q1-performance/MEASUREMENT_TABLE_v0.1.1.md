# MEASUREMENT_TABLE v0.1.1 (candidate harness)

Status: **normative experimental specification** for a future campaign.
Does **not** rewrite `campaign-q1-001` or invent medians.
Frozen `v0.1.0-conformant` / `H_benchmark` remain authoritative until a new accepted campaign produces `H_env'` / `H_benchmark'`.

Ordering invariant:

```text
Specification ≺ Execution ≺ RawEvidence ≺ Statistics ≺ Interpretation
```

## Timer boundaries (freeze before any sample)

| Bench | Primary magnitude | Inside `measure()` | Explicitly outside | Valid-sample condition |
|---|---|---|---|---|
| **B0** | Instrumental timing floor | Minimal local deterministic primitive | Setup / asserts | Completes without error |
| **B1** | Normalize + deterministic admission | `normalizeProposal()` + `gateway.evaluate()` | Raw-input construction, deterministic ID allocation, post asserts | `D.result = ADMIT` |
| **B2** | Capability issue + production validation | `issueCapabilityToken()` + `assertValidCapabilityToken()` | Proposal construction and admission | Capability issued and validated |
| **B3** | Durable PREPARED reservation | One complete `reserveExecution()` on a ready journal | Provisioning, readback, `verifyLineage`, asserts | Valid durable PREPARED; capability consumed |
| **B4** | Complete mediated successful consequence | From normalization start through durable `OUTCOME_SUCCESS` return | Input construction, asserts, **replay attempt** | ADMIT; exactly 1 tool entry; PREPARED+SUCCESS; later replay rejected |
| **B5** | In-memory lineage verification | Only `verifyLineage()` | Fixture generation, journal I/O, NDJSON parse, asserts | integrity valid; closure complete; exact record count |
| **B6** | Core restart/reconciliation | Bootstrap + durable UNKNOWN reconciliation (`T_coreRecovery`) | Fixture creation, process spawn envelope, final verify, second reconcile | First close=1; second close=0; open PREPARED=0; integrity valid |

### Notes

- **B0** ∉ {security baseline, system baseline, functional baseline}. No overhead ratio is a primary scientific claim.
- **B4** historical `campaign-q1-001` median 11.0489 ms included replay inside the timer; keep that label as compound. v0.1.1 harness moves replay outside `T_B4`.
- **B6** ambient spawn cost may be retained as diagnostic `workerEnvelope` (historical field name `coldProcessNs`); it is not pure kernel recovery.
- Inside `reserveExecution()` (production path): Seal → ValidateTransition → WriteAll → fsync → ApplyTransition.

## Report discipline

- Primary scientific latency claims: absolute B1–B6 distributions.
- Do **not** treat \(O_{FC}\) or \(\Delta L\) as primary scientific claims.
- B0 may appear in tables as calibration floor only.

## Campaign gate (before manuscript numeric refresh)

1. This table is frozen.
2. Run new campaign on accepted artifact.
3. Accept `VALID_MEASUREMENT` with new `H_env'` / `H_benchmark'`.
4. Only then update Section 7 numbers.
5. Never claim B1/B3/B4 “performance improvements” vs v0.1.0 from purity changes alone.

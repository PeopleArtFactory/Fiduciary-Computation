import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryGateway,
  FiduciaryJournal,
  generateEd25519KeyPair,
  normalizeProposal,
  signAuthorityClaim,
} from "../../src/index.js";
import type { AuthorityClaim, FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../../src/index.js";
import { createInstrumentedTool, createSideEffectCounters, type SideEffectCounters } from "./instrumentation.js";

export const FIXED_CLOCK = 2_000;
export const HMAC_SECRET = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

export interface ConformanceFixture {
  dir: string;
  counters: SideEffectCounters;
  auth: ReturnType<typeof generateEd25519KeyPair>;
  sealerKeys: ReturnType<typeof generateEd25519KeyPair>;
  trustedIssuers: TrustedIssuer[];
  policy: FiduciaryPolicy;
  evidence: VerifiedEvidenceRef;
  rawProposal: Record<string, unknown>;
  proposal: Proposal;
  claim: AuthorityClaim;
  engine: FiduciaryEngine;
  sealer: DFDSealer;
  journal: FiduciaryJournal;
  executor: FiduciaryExecutor;
  gateway: FiduciaryGateway;
  authorizedTool: () => { status: "EXECUTED" };
}

export function createConformanceFixture(): ConformanceFixture {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k9-"));
  const counters = createSideEffectCounters();
  const auth = generateEd25519KeyPair();
  const sealerKeys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "llm_agent_01" };
  const policy: FiduciaryPolicy = {
    policyId: "pol_bank_transfer_01",
    version: "1.0",
    action: "FINANCIAL_TRANSFER",
    consequenceClass: "FINANCIAL",
    riskLevel: 3,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["ACCOUNT_STATUS"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "ev_account_01",
    type: "ACCOUNT_STATUS",
    producer: "ledger",
    contentHash: "a".repeat(64),
    verifiedAt: 1_000,
  };
  const rawProposal: Record<string, unknown> = {
    proposalId: "prop_tx_001",
    actor,
    action: "FINANCIAL_TRANSFER",
    target: "account_7712",
    parameters: { amount: 1_000 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1_500,
  };
  const proposal = normalizeProposal(rawProposal);
  const claim = signAuthorityClaim(
    {
      claimId: "claim_transfer",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1_000,
      expiresAt: 5_000,
      nonce: "nonce_123",
    },
    auth.privateKeyPem,
  );
  const engine = new FiduciaryEngine();
  const sealer = new DFDSealer("fc-gateway-node-1", "authority:fc-root-01", sealerKeys.publicKeyPem, sealerKeys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir);
  const executor = new FiduciaryExecutor(HMAC_SECRET, journal);
  const gateway = new FiduciaryGateway({
    policies: [policy],
    trustedIssuers,
    hmacSecret: HMAC_SECRET,
    journal,
    now: () => FIXED_CLOCK,
  });
  return {
    dir,
    counters,
    auth,
    sealerKeys,
    trustedIssuers,
    policy,
    evidence,
    rawProposal,
    proposal,
    claim,
    engine,
    sealer,
    journal,
    executor,
    gateway,
    authorizedTool: createInstrumentedTool(counters, "authorized"),
  };
}

export function cleanupFixture(fixture: ConformanceFixture): void {
  fs.rmSync(fixture.dir, { recursive: true, force: true });
}

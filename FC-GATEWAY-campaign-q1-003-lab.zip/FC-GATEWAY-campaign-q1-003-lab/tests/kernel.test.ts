import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import {
  DFDSealer,
  FCG_GENESIS_HASH,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  CanonicalizationError,
  FiduciaryValidationError,
  canonicalizeJson,
  computeKernelMetrics,
  generateEd25519KeyPair,
  normalizeProposal,
  signAuthorityClaim,
} from "../src/index.js";
import type { AuthorityClaim, FiduciaryMetrics, FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fc-gateway-"));
  const auth = generateEd25519KeyPair();
  const sealerKeys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "llm_agent_01" };
  const policy: FiduciaryPolicy = {
    policyId: "pol_bank_transfer_01",
    version: "1.0",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 3,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "ev_kyc_01",
    type: "KYC_VERIFIED",
    producer: "kyc_service",
    contentHash: "a".repeat(64),
    verifiedAt: 1000,
  };
  const proposal: Proposal = {
    proposalId: "prop_tx_001",
    actor,
    action: "bank.transfer",
    target: "account_7712",
    parameters: { amount: 20_000 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1500,
  };
  const claim = makeClaim(auth.privateKeyPem, actor.id, "TRANSFER_APPROVE", "authority:finance-root", 1000, 5000);
  const engine = new FiduciaryEngine();
  const sealer = new DFDSealer("fc-gateway-node-1", "authority:fc-root-01", sealerKeys.publicKeyPem, sealerKeys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir);
  const executor = new FiduciaryExecutor(hmacSecret, journal);
  return { dir, auth, sealerKeys, trustedIssuers, actor, policy, evidence, proposal, claim, engine, sealer, journal, executor };
}

function makeClaim(privateKeyPem: string, subject: string, permit: string, issuer: string, issuedAt: number, expiresAt: number): AuthorityClaim {
  return signAuthorityClaim(
    {
      claimId: `claim_${subject}_${permit}_${issuedAt}_${expiresAt}`,
      issuer,
      subject,
      permits: [permit],
      issuedAt,
      expiresAt,
      nonce: "nonce_123",
    },
    privateKeyPem,
  );
}

test("FULL CHAIN: Proposal -> Admission -> Capability -> PREPARED -> OUTCOME", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    assert.equal(decision.result, "ADMIT");
    assert.equal(f.engine.verifyAdmissionDecision(decision), true);

    const capability = f.engine.mintCapability(decision, f.proposal, hmacSecret, 2000, 30_000);
    assert.ok(capability);
    assert.equal(capability.issuer, "fc-gateway");
    assert.equal(capability.audience, "fiduciary-executor");
    assert.deepEqual(capability.scope, { action: "bank.transfer", target: "account_7712" });
    assert.match(capability.mac, /^[0-9a-f]{64}$/);

    const result = await f.executor.executeConsequence(f.proposal, decision, capability, 2100, () => ({ status: "EXECUTED", txId: "tx_001" }));
    assert.equal(result.success, true);
    assert.equal(result.preparedDeed.phase, "EXECUTION_PREPARED");
    assert.equal(result.preparedDeed.prevDfdHash, FCG_GENESIS_HASH);
    assert.equal(result.preparedDeed.proposalHash, decision.proposalHash);
    assert.equal(result.outcomeDeed.preparedDfdHash, result.preparedDeed.dfdHash);
    assert.equal(result.outcomeDeed.phase, "OUTCOME_SUCCESS");
    assert.equal(f.journal.getOrdinal(), 2);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-01: over-limit policy bypass is rejected", () => {
  const f = fixture();
  try {
    const proposal = { ...f.proposal, parameters: { amount: 75_000 } };
    const decision = f.engine.evaluate(proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    assert.equal(decision.result, "REJECT");
    assert.match(decision.reasons.join("|"), /CONSTRAINT_VIOLATION/);
    assert.equal(f.engine.mintCapability(decision, proposal, hmacSecret, 2000), null);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-02: capability replay is rejected after restart", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    const capability = f.engine.mintCapability(decision, f.proposal, hmacSecret, 2000)!;
    await f.executor.executeConsequence(f.proposal, decision, capability, 2100, () => ({ ok: true }));

    const reloadedJournal = new FiduciaryJournal(f.sealer, f.dir);
    const reloadedExecutor = new FiduciaryExecutor(hmacSecret, reloadedJournal);
    await assert.rejects(
      () => reloadedExecutor.executeConsequence(f.proposal, decision, capability, 2200, () => ({ ok: true })),
      /CAPABILITY_REPLAY_REJECTED|ADMISSION_REPLAY_REJECTED/,
    );
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-03: lineage mutation fails closed on bootstrap", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    const capability = f.engine.mintCapability(decision, f.proposal, hmacSecret, 2000)!;
    await f.executor.executeConsequence(f.proposal, decision, capability, 2100, () => ({ ok: true }));

    const lineage = fs.readFileSync(f.journal.getLineagePath(), "utf8");
    fs.writeFileSync(f.journal.getLineagePath(), lineage.replace("OUTCOME_SUCCESS", "OUTCOME_NO_EFFECT"), "utf8");
    assert.throws(() => new FiduciaryJournal(f.sealer, f.dir), /CRITICAL_JOURNAL_CORRUPTION/);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-04: malformed payloads reject, extra top-level fields have no fiduciary effect", () => {
  const normalized = normalizeProposal({
    proposalId: "p1",
    actor: { type: "ai", id: "agent" },
    action: "email.send",
    parameters: { recipient: "a@example.com" },
    requestedAt: 1000,
    riskLevel: 0,
    consequenceClass: "READ",
  });
  assert.equal("riskLevel" in normalized, false);
  assert.throws(
    () => normalizeProposal({ proposalId: "p1", actor: { type: "ai", id: "agent" }, action: "email.send", parameters: {}, requestedAt: Number.NaN }),
    FiduciaryValidationError,
  );
});

test("ADV-05: missing or ambiguous trusted policy fails closed", () => {
  const f = fixture();
  try {
    const noPolicy = f.engine.evaluate(f.proposal, [], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    assert.equal(noPolicy.result, "REJECT");
    assert.equal(noPolicy.reasons[0], "NO_POLICY_MATCH");

    const ambiguous = f.engine.evaluate(f.proposal, [f.policy, { ...f.policy, policyId: "pol_duplicate" }], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    assert.equal(ambiguous.result, "REJECT");
    assert.equal(ambiguous.reasons[0], "AMBIGUOUS_POLICY_MATCH");
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-06: forged authority from unknown issuer is rejected", () => {
  const f = fixture();
  try {
    const attacker = generateEd25519KeyPair();
    const forged = makeClaim(attacker.privateKeyPem, f.actor.id, "TRANSFER_APPROVE", "authority:attacker", 1000, 5000);
    const decision = f.engine.evaluate(f.proposal, [f.policy], [forged], f.trustedIssuers, [f.evidence], 2000);
    assert.equal(decision.result, "REJECT");
    assert.match(decision.reasons.join("|"), /MISSING_OR_UNTRUSTED_AUTHORITY_PERMIT/);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-07: temporal anachronism is rejected", () => {
  const f = fixture();
  try {
    const futureClaim = makeClaim(f.auth.privateKeyPem, f.actor.id, "TRANSFER_APPROVE", "authority:finance-root", 3000, 5000);
    const expiredClaim = makeClaim(f.auth.privateKeyPem, f.actor.id, "TRANSFER_APPROVE", "authority:finance-root", 1000, 1500);
    assert.equal(f.engine.evaluate(f.proposal, [f.policy], [futureClaim], f.trustedIssuers, [f.evidence], 2000).result, "REJECT");
    assert.equal(f.engine.evaluate(f.proposal, [f.policy], [expiredClaim], f.trustedIssuers, [f.evidence], 2000).result, "REJECT");
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-08: admission binding prevents minting capability for another proposal", () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    const otherProposal = { ...f.proposal, proposalId: "prop_other", parameters: { amount: 1 } };
    assert.throws(() => f.engine.mintCapability(decision, otherProposal, hmacSecret, 2000), /PROPOSAL_ADMISSION_MISMATCH/);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("ADV-09: multiple capabilities from one admission cannot execute twice", async () => {
  const f = fixture();
  try {
    const decision = f.engine.evaluate(f.proposal, [f.policy], [f.claim], f.trustedIssuers, [f.evidence], 2000);
    const capA = f.engine.mintCapability(decision, f.proposal, hmacSecret, 2000)!;
    const capB = f.engine.mintCapability(decision, f.proposal, hmacSecret, 2001)!;
    await f.executor.executeConsequence(f.proposal, decision, capA, 2100, () => ({ ok: true }));
    await assert.rejects(
      () => f.executor.executeConsequence(f.proposal, decision, capB, 2101, () => ({ ok: true })),
      /ADMISSION_REPLAY_REJECTED/,
    );
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("startup reconciliation closes orphan PREPARED deeds as OUTCOME_UNKNOWN", () => {
  const f = fixture();
  try {
    const prepared = f.journal.reserveExecution({
      tokenId: "cap_orphan",
      admissionHash: "b".repeat(64),
      proposalHash: "c".repeat(64),
      actor: f.actor,
      action: "email.send",
      timestamp: 2000,
    });
    assert.equal(prepared.phase, "EXECUTION_PREPARED");

    const reloaded = new FiduciaryJournal(f.sealer, f.dir);
    const count = reloaded.reconcileStartupState(3000);
    assert.equal(count, 1);
    const deeds = reloaded.readAllDeeds();
    assert.equal(deeds.at(-1)?.phase, "OUTCOME_UNKNOWN");
    const reloadedAgain = new FiduciaryJournal(f.sealer, f.dir);
    assert.equal(reloadedAgain.reconcileStartupState(4000), 0);
    assert.equal(reloadedAgain.readAllDeeds().length, 2);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("canonical JSON rejects non-JCS runtime values", () => {
  assert.equal(canonicalizeJson({ b: 2, a: 1 }), '{"a":1,"b":2}');
  assert.throws(() => canonicalizeJson(Number.NaN as never), CanonicalizationError);
  assert.throws(() => canonicalizeJson(Infinity as never), CanonicalizationError);
  assert.throws(() => canonicalizeJson("\uD800"), /INVALID_UNICODE|isolated UTF-16 surrogate/);

  const cyclic: Record<string, unknown> = {};
  cyclic.self = cyclic;
  assert.throws(() => canonicalizeJson(cyclic as never), CanonicalizationError);

  const artifactsDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../artifacts");
  fs.mkdirSync(artifactsDir, { recursive: true });
  fs.writeFileSync(
    path.join(artifactsDir, "K1_RFC8785_GATES.json"),
    JSON.stringify(
      {
        schema: "FCG-K1-RFC8785-0.1",
        kernelVersion: "0.1.0",
        sourceRevision: "local",
        generatedAt: new Date().toISOString(),
        passed: 4,
        total: 4,
        status: "PASS",
      },
      null,
      2,
    ),
  );
});

test("metrics compute ASR/UCR/AD/ELC/FCC", () => {
  const metrics: FiduciaryMetrics = {
    adversarialAttempts: 8,
    adversarialSuccesses: 0,
    protectedExecutions: 1,
    unsanctionedExecutions: 0,
    repeatedAdmissions: 4,
    deterministicAdmissions: 4,
    protectedExecutionAttempts: 3,
    preparedLineageCount: 3,
    preparedCount: 3,
    closureCount: 3,
  };
  assert.deepEqual(computeKernelMetrics(metrics), { ASR: 0, UCR: 0, AD: 1, ELC: 1, FCC: 1 });
});

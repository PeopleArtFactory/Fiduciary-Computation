import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  generateEd25519KeyPair,
  nodeJournalWriteIO,
  signAuthorityClaim,
  verifyLineage,
  type JournalWriteIO,
} from "../src/index.js";
import type { FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

function setup(opts?: { writeIO?: JournalWriteIO }) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k7-dur-"));
  const auth = generateEd25519KeyPair();
  const keys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "a" };
  const policy: FiduciaryPolicy = {
    policyId: "p",
    version: "1",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 1,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 10 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "e",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1,
  };
  const proposal: Proposal = {
    proposalId: "prop",
    actor,
    action: "bank.transfer",
    parameters: { amount: 1 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1,
  };
  const claim = signAuthorityClaim(
    {
      claimId: "c",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1,
      expiresAt: 9_999,
      nonce: "n",
    },
    auth.privateKeyPem,
  );
  const sealer = new DFDSealer("n", "k", keys.publicKeyPem, keys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir, opts?.writeIO ?? nodeJournalWriteIO);
  const engine = new FiduciaryEngine();
  const executor = new FiduciaryExecutor(hmacSecret, journal);
  const decision = engine.evaluate(proposal, [policy], [claim], trustedIssuers, [evidence], 10);
  const capability = engine.mintCapability(decision, proposal, hmacSecret, 10)!;
  return { dir, journal, executor, proposal, decision, capability, sealer };
}

test("K7 durability: repeated short writes complete PREPARED before execution", async () => {
  const writeSizes: number[] = [];
  const io: JournalWriteIO = {
    ...nodeJournalWriteIO,
    writeSync(fd, buffer, offset, length, position) {
      assert.ok(Buffer.isBuffer(buffer));
      const off = offset ?? 0;
      const len = length ?? buffer.byteLength - off;
      const chunkLength = Math.min(len, 7);
      const written = fs.writeSync(fd, buffer, off, chunkLength, position ?? null);
      writeSizes.push(written);
      return written;
    },
  };
  const f = setup({ writeIO: io });
  try {
    let toolEntries = 0;
    const result = await f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => {
      toolEntries += 1;
      const deeds = f.journal.readAllDeeds();
      assert.equal(deeds.length, 1);
      assert.equal(deeds[0]!.phase, "EXECUTION_PREPARED");
      return { ok: true };
    });
    assert.equal(result.success, true);
    assert.equal(toolEntries, 1);
    assert.ok(writeSizes.length > 2);
    assert.ok(writeSizes.every((n) => n > 0 && n <= 7));
    const deeds = f.journal.readAllDeeds();
    assert.equal(deeds.length, 2);
    const verified = verifyLineage(deeds, {
      sealerPublicKeyPem: f.sealer.publicKeyPem,
      sealerIssuer: f.sealer.issuer,
      sealerIssuerKeyId: f.sealer.issuerKeyId,
    });
    assert.equal(verified.report.integrityValid, true);
    assert.equal(verified.report.closureComplete, true);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K7 durability: partial PREPARED followed by write failure never enters protected tool", async () => {
  let writeCalls = 0;
  const io: JournalWriteIO = {
    ...nodeJournalWriteIO,
    writeSync(fd, buffer, offset, length, position) {
      writeCalls += 1;
      if (writeCalls === 1) {
        const off = offset ?? 0;
        const len = length ?? buffer.byteLength - off;
        return fs.writeSync(fd, buffer, off, Math.min(len, 11), position ?? null);
      }
      throw new Error("INJECTED_WRITE_FAILURE");
    },
  };
  const f = setup({ writeIO: io });
  try {
    let toolEntries = 0;
    await assert.rejects(
      () =>
        f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => {
          toolEntries += 1;
          return { ok: true };
        }),
      /INJECTED_WRITE_FAILURE/,
    );
    assert.equal(toolEntries, 0);
    assert.throws(
      () =>
        f.journal.reserveExecution({
          tokenId: "x",
          admissionHash: "a".repeat(64),
          proposalHash: "b".repeat(64),
          actor: f.proposal.actor,
          action: f.proposal.action,
          timestamp: 30,
        }),
      /JOURNAL_FAIL_CLOSED_RESTART_REQUIRED/,
    );
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K7 durability: zero-progress write poisons journal before execution", async () => {
  const io: JournalWriteIO = {
    ...nodeJournalWriteIO,
    writeSync() {
      return 0;
    },
  };
  const f = setup({ writeIO: io });
  try {
    let toolEntries = 0;
    await assert.rejects(
      () =>
        f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => {
          toolEntries += 1;
          return { ok: true };
        }),
      /JOURNAL_WRITE_NO_PROGRESS/,
    );
    assert.equal(toolEntries, 0);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K7 durability: fsync failure after complete write never enters protected tool", async () => {
  const io: JournalWriteIO = {
    ...nodeJournalWriteIO,
    fsyncSync() {
      throw new Error("INJECTED_FSYNC_FAILURE");
    },
  };
  const f = setup({ writeIO: io });
  try {
    let toolEntries = 0;
    await assert.rejects(
      () =>
        f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => {
          toolEntries += 1;
          return { ok: true };
        }),
      /INJECTED_FSYNC_FAILURE/,
    );
    assert.equal(toolEntries, 0);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K7 durability: torn journal tail is rejected on bootstrap", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k7-torn-"));
  try {
    const keys = generateEd25519KeyPair();
    const sealer = new DFDSealer("n", "k", keys.publicKeyPem, keys.privateKeyPem);
    const journalPath = path.join(dir, "lineage.ndjson");
    fs.writeFileSync(journalPath, '{"phase":"EXECUTION_PREPARED"', "utf8");
    assert.throws(() => new FiduciaryJournal(sealer, dir), /JOURNAL_TORN_TAIL/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

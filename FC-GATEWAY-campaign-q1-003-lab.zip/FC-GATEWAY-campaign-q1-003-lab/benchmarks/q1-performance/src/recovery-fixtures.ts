import * as fs from "node:fs";
import * as path from "node:path";
import { issueCapabilityToken } from "../../../dist/src/index.js";
import { HMAC_SECRET, makeProposal, openSession, type BenchFixture } from "./fixtures.js";

export interface OpenPreparedFixture {
  dir: string;
  preparedDeedId: string;
  sealer: {
    issuer: string;
    issuerKeyId: string;
    publicKeyPem: string;
    privateKeyPem: string;
  };
  reconcileTimestamp: number;
}

export function createOpenPreparedFixture(fx: BenchFixture, label: string): OpenPreparedFixture {
  const session = openSession(fx, label);
  const proposal = makeProposal(Date.now(), fx.evidence.evidenceId);
  const decision = session.gateway.evaluate(proposal, [fx.claim], [fx.evidence]);
  if (decision.result !== "ADMIT") throw new Error("B6 fixture ADMIT failed");
  const capability = issueCapabilityToken(decision, proposal, {
    issuer: "fc-gateway",
    audience: "fiduciary-executor",
    fiduciaryClock: fx.clock,
    hmacSecret: HMAC_SECRET,
  });
  const prepared = session.journal.reserveExecution({
    tokenId: capability.tokenId,
    admissionHash: decision.admissionHash,
    proposalHash: capability.proposalHash,
    actor: proposal.actor,
    action: proposal.action,
    ...(proposal.target ? { target: proposal.target } : {}),
    timestamp: fx.clock,
  });
  // Persist sealer material for child process (same keys as parent fixture sealer).
  const metaPath = path.join(session.dir, "b6-meta.json");
  const meta = {
    preparedDeedId: prepared.deedId,
    sealer: {
      issuer: fx.sealer.issuer,
      issuerKeyId: fx.sealer.issuerKeyId,
      publicKeyPem: fx.sealerKeys.publicKeyPem,
      privateKeyPem: fx.sealerKeys.privateKeyPem,
    },
    reconcileTimestamp: fx.clock + 1_000,
  };
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));
  return {
    dir: session.dir,
    preparedDeedId: prepared.deedId,
    sealer: meta.sealer,
    reconcileTimestamp: meta.reconcileTimestamp,
  };
}

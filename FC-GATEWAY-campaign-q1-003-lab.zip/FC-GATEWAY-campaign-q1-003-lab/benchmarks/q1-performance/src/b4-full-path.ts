import type { AdmissionDecision, Proposal } from "../../../dist/src/index.js";
import { normalizeProposal } from "../../../dist/src/index.js";
import { measure, type BenchmarkSample } from "./statistics.js";
import { makeRawProposal, openSession, protectedOperation, type BenchFixture } from "./fixtures.js";

/**
 * B4 measures the complete mediated success path through OUTCOME_SUCCESS.
 * Immediate post-success replay rejection is checked outside the timer for
 * measurement purity (v0.1.1 harness). Historical campaign-q1-001 included
 * that replay check inside the timed region; do not reinterpret its B4
 * median as pure success-path latency alone.
 */
export async function runB4(fx: BenchFixture, samples: number, warmup: number): Promise<BenchmarkSample[]> {
  const out: BenchmarkSample[] = [];

  const one = async (iteration: number, record: boolean) => {
    const session = openSession(fx, "b4");
    let toolEntries = 0;
    let proposal!: Proposal;
    let decision!: AdmissionDecision;
    let executeOk = false;
    let preparedPhase: string | undefined;

    // Frozen v0.1.1 spec: raw input construction is explicitly outside B4.
    const raw = makeRawProposal(iteration, fx.evidence.evidenceId);

    const sample = await measure("B4", iteration, async () => {
      proposal = normalizeProposal(raw);
      decision = session.gateway.evaluate(proposal, [fx.claim], [fx.evidence]);
      if (decision.result !== "ADMIT") throw new Error("B4 ADMIT failed");
      const result = await session.gateway.execute(proposal, decision, async () => {
        toolEntries += 1;
        return protectedOperation({ iteration });
      });
      executeOk = Boolean(result?.success);
      preparedPhase = result?.preparedDeed?.phase;
    });

    if (!sample.success) throw new Error(`INVALID_MEASUREMENT: B4 failed at ${iteration}: ${sample.meta?.error}`);
    if (!executeOk) throw new Error("INVALID_MEASUREMENT: B4 execute failed");
    if (toolEntries !== 1) throw new Error("INVALID_MEASUREMENT: B4 tool entry delta != 1");
    if (preparedPhase !== "EXECUTION_PREPARED") {
      throw new Error("INVALID_MEASUREMENT: missing PREPARED deed");
    }

    // Replay check outside timer (harness invariant, not part of B4 latency).
    let replayRejected = false;
    try {
      await session.gateway.execute(proposal, decision, async () => {
        toolEntries += 1;
        return protectedOperation({ iteration, replay: true });
      });
    } catch (error) {
      replayRejected =
        String(error).includes("ADMISSION_REPLAY_REJECTED") || String(error).includes("CAPABILITY_REPLAY");
    }
    if (!replayRejected || toolEntries !== 1) {
      throw new Error("INVALID_MEASUREMENT: B4 admission reuse was not rejected before second tool entry");
    }
    if (record) out.push(sample);
  };

  for (let i = 0; i < warmup; i++) await one(i, false);
  for (let i = 0; i < samples; i++) await one(i, true);
  return out;
}

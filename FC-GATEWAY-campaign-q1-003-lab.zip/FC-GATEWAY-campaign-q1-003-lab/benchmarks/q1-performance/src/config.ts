export const FREEZE = {
  tag: "v0.1.0-conformant",
  commit: "d6ff393cee8e9f8fc48e9e75517eb88a85218dab",
  reportHash: "5869dcfaa6357746a0c34050016ae951e593c078f59b235c207d95e6449efb53",
} as const;

export const CANDIDATE = {
  label: "v0.1.1-conformant-candidate",
  historicalTag: FREEZE.tag,
  historicalCommit: FREEZE.commit,
} as const;

export const TOOLCHAIN = {
  pnpm: "10.0.0",
  typescript: "5.9.3",
  typesNode: "25.9.6",
  undiciTypes: "7.24.6",
} as const;

export type BenchmarkId = "B0" | "B1" | "B2" | "B3" | "B4" | "B5" | "B6";
export type BenchmarkProfile = "freeze" | "candidate";

export interface BenchmarkConfig {
  profile: BenchmarkProfile;
  samples: number;
  warmupCore: number;
  warmupB5: number;
  warmupB6: number;
  lineageSizes: number[];
  only?: BenchmarkId[];
  outputDir: string;
  journalRoot: string;
  /** If true, allow running on a dirty tree but force INVALID_MEASUREMENT. */
  allowDirtyPilot: boolean;
}

export function parseArgs(argv: string[]): BenchmarkConfig {
  const args = argv.filter((a) => a !== "--");
  const get = (name: string, fallback?: string): string | undefined => {
    const i = args.indexOf(name);
    if (i < 0) return fallback;
    return args[i + 1] ?? fallback;
  };
  const has = (name: string) => args.includes(name);
  const onlyRaw = get("--only");
  const lineage = (get("--lineage-sizes", "10,100,1000,10000") ?? "")
    .split(",")
    .map((s) => Number(s.trim()))
    .filter((n) => Number.isFinite(n) && n > 0);

  const runId = new Date().toISOString().replace(/[:.]/g, "-");
  const output = get("--output", `benchmarks/q1-performance/results/run-${runId}`)!;
  const profileRaw = (get("--profile", "candidate") ?? "candidate").toLowerCase();
  const profile: BenchmarkProfile = profileRaw === "freeze" ? "freeze" : "candidate";

  const cfg: BenchmarkConfig = {
    profile,
    samples: Number(get("--samples", "1000")),
    warmupCore: Number(get("--warmup-core", get("--warmup", "200"))),
    warmupB5: Number(get("--warmup-b5", "20")),
    warmupB6: Number(get("--warmup-b6", "5")),
    lineageSizes: lineage.length ? lineage : [10, 100, 1000, 10000],
    outputDir: output,
    journalRoot: get("--journal-root", `${output}/journals`)!,
    allowDirtyPilot: has("--allow-dirty-pilot"),
  };
  if (onlyRaw) cfg.only = onlyRaw.split(",").map((s) => s.trim()) as BenchmarkId[];
  return cfg;
}

export function shouldRun(cfg: BenchmarkConfig, id: BenchmarkId): boolean {
  return !cfg.only || cfg.only.includes(id);
}

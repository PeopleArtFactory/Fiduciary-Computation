# Roadmap

## v0.1 Reference Kernel

- Keep the kernel small and model-agnostic.
- Prove the causal chain with tests before adding adapters.
- Keep runtime dependencies at zero.
- Treat RFC 8785 conformance vectors as a release gate.
- Publish measured ASR/UCR/AD/ELC/FCC for the reference executor.

## v0.2 Adapters

- MCP adapter
- REST reverse proxy adapter
- generic webhook adapter
- Node/TypeScript SDK helper
- file-system action adapter
- email/send adapter for the inaugural demo

## v0.3 Portable Bundles

Create exportable offline verification bundles:

```text
fc-bundle/
  proposals.ndjson
  admissions.ndjson
  deeds.ndjson
  policies/
  authorities/
  evidence/
  checkpoint.json
  public-keys/
```

## Edge / Air-Gapped OT Profile (post-v0.1 annex)

Normative annex and executable deployment plane (**outside** frozen kernel):

- Spec: `papers/EDGE_PROFILE.md`
- Code: `edge/` (`pnpm build:edge`, `pnpm test:edge`)

Covers appliance lifecycle (`UNBOUND`→`READY`/`DEGRADED`), hybrid Vendor/Customer roots of trust, claim matrix, storage qualification hooks, non-exportable custody boundary, and DR as cryptographic epoch change (Node Retirement + Lineage Successor deeds). Does **not** modify `v0.1.0-conformant`.

## Commercial Path

Open core:

- Community: local kernel, CLI, verifier
- Pro: dashboard, policy management, DFD explorer, alerts, replay/simulation
- Enterprise: on-prem, SSO, HSM/KMS integration, SIEM, distributed policies, support

Commercial sentence:

```text
Protect your first agent with the power to act.
```

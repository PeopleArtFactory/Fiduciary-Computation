import { FiduciarySecurityError } from "./errors.js";
import { assertValidCapabilityToken } from "./capability.js";
import type { DFDDeed, ExecutionResult, JsonValue } from "./types.js";
import type { AdmissionDecision, CapabilityToken, Proposal } from "./types.js";
import { FiduciaryJournal } from "../journal/journal.js";

export class FiduciaryExecutor {
  constructor(
    private readonly hmacSecret: Buffer,
    private readonly journal: FiduciaryJournal,
    private readonly expectedIssuer = "fc-gateway",
    private readonly expectedAudience = "fiduciary-executor",
  ) {}

  public async executeConsequence<T extends JsonValue>(
    proposal: Proposal,
    decision: AdmissionDecision,
    capability: CapabilityToken,
    currentTime: number,
    operation: () => Promise<T> | T,
  ): Promise<ExecutionResult<T>> {
    try {
      assertValidCapabilityToken(capability, decision, proposal, {
        expectedIssuer: this.expectedIssuer,
        expectedAudience: this.expectedAudience,
        fiduciaryClock: currentTime,
        hmacSecret: this.hmacSecret,
      });
    } catch (error) {
      if (error instanceof FiduciarySecurityError) throw error;
      throw new FiduciarySecurityError(error instanceof Error ? error.message : String(error));
    }

    const preparedDeed = this.journal.reserveExecution({
      tokenId: capability.tokenId,
      admissionHash: decision.admissionHash,
      proposalHash: capability.proposalHash,
      actor: proposal.actor,
      action: proposal.action,
      target: proposal.target,
      timestamp: currentTime,
    });

    // ================= CONSEQUENCE BOUNDARY =================
    // PREPARED is durable before entering operation(). Journal OUTCOME
    // persistence errors must never be rewritten as a second OUTCOME.

    let value: T;
    let operationError: Error | undefined;
    try {
      value = await operation();
    } catch (error) {
      operationError = error instanceof Error ? error : new Error(String(error));
      const outcomeDeed = this.journal.appendOutcome(preparedDeed, "OUTCOME_UNKNOWN", {
        timestamp: currentTime + 1,
        errorCode: `OPERATION_ERROR_OBSERVED:${operationError.message}`,
      });
      return {
        success: false,
        error: operationError,
        preparedDeed,
        outcomeDeed,
      };
    }

    const outcomeDeed = this.journal.appendOutcome(preparedDeed, "OUTCOME_SUCCESS", {
      outcome: value,
      timestamp: currentTime + 1,
    });
    return { success: true, value, preparedDeed, outcomeDeed };
  }
}

export function isClosedOutcome(deed: DFDDeed): boolean {
  return deed.phase !== "EXECUTION_PREPARED" && Boolean(deed.preparedDeedId);
}

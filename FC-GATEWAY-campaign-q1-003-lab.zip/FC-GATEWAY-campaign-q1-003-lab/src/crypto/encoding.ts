import { FiduciaryValidationError } from "../core/errors.js";
import {
  ED25519_SIGNATURE_HEX_LENGTH,
  HASH256_HEX_LENGTH,
  HMAC_SHA256_HEX_LENGTH,
} from "../core/constants.js";
import type { Hash256 } from "../core/types.js";

const LOWER_HEX = /^[0-9a-f]+$/;

export function assertHash256Hex(value: unknown): asserts value is Hash256 {
  if (typeof value !== "string" || value.length !== HASH256_HEX_LENGTH || !LOWER_HEX.test(value)) {
    throw new FiduciaryValidationError("MALFORMED_HASH256");
  }
}

export function decodeHash256Hex(value: unknown): Buffer {
  assertHash256Hex(value);
  return Buffer.from(value, "hex");
}

export function assertEd25519SignatureHex(value: unknown): asserts value is string {
  if (typeof value !== "string" || value.length !== ED25519_SIGNATURE_HEX_LENGTH || !LOWER_HEX.test(value)) {
    throw new FiduciaryValidationError("MALFORMED_SIGNATURE");
  }
}

export function decodeEd25519SignatureHex(value: unknown): Buffer {
  assertEd25519SignatureHex(value);
  return Buffer.from(value, "hex");
}

export function assertHmacSha256Hex(value: unknown): asserts value is string {
  if (typeof value !== "string" || value.length !== HMAC_SHA256_HEX_LENGTH || !LOWER_HEX.test(value)) {
    throw new FiduciaryValidationError("MALFORMED_HMAC");
  }
}

export function decodeHmacSha256Hex(value: unknown): Buffer {
  assertHmacSha256Hex(value);
  return Buffer.from(value, "hex");
}

export function isHash256Hex(value: unknown): value is Hash256 {
  return typeof value === "string" && value.length === HASH256_HEX_LENGTH && LOWER_HEX.test(value);
}

export function isEd25519SignatureHex(value: unknown): value is string {
  return typeof value === "string" && value.length === ED25519_SIGNATURE_HEX_LENGTH && LOWER_HEX.test(value);
}

export function isHmacSha256Hex(value: unknown): value is string {
  return typeof value === "string" && value.length === HMAC_SHA256_HEX_LENGTH && LOWER_HEX.test(value);
}

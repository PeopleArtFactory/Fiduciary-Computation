# FC Gateway v0.1 Architecture

## Product Form

FC Gateway is the first installable product form of Fiduciary Computation: a small gateway between information producers and consequential systems.

```text
AI / Human / Sensor / Workflow / Script
  -> Proposal
  -> Fiduciary Gateway
  -> Tool / API / Database / SaaS / Filesystem
```

The gateway does not try to transform the whole internet. It creates a fiduciary perimeter at the scale of one developer, one app, one team, or one organization.

## Deployment Modes

- Local daemon: `Agent -> localhost -> external API`
- Sidecar: app container plus FC sidecar
- Reverse proxy: replace `api.service.com` with a mediated endpoint
- SDK: direct integration inside TypeScript code
- Enterprise gateway: shared perimeter for many agents and tools

## Data Plane / Control Plane

The v0.1 data plane must remain small, local, and capable of operating without a remote service for critical policies.

```text
Local Agent -> FC Data Plane -> Protected Tool
```

A later control plane can manage policies, authorities, analytics, DFD indexes, dashboards and deployments. If the control plane is down, the local gateway should continue enforcing its last trusted configuration.

## Causal State Machine

```text
Proposal
  -> AdmissionDecision
  -> CapabilityToken
  -> DFD EXECUTION_PREPARED
  -> External Operation
  -> DFD OUTCOME_SUCCESS | OUTCOME_NO_EFFECT | OUTCOME_UNKNOWN
```

The important v0.1 discovery is that `EXECUTION_PREPARED` is not audit after the fact. It is durable causal precommitment before the consequence boundary.

## Distinctions Preserved

```text
Identity assertion != Authenticity != Authority != Admission
Authorization != Admission
Evidence != Truth
Admission != Outcome
Action != Audit
```

FC Gateway complements IAM/RBAC/ABAC. An actor can be authorized generally and still fail admission for a concrete consequence under current policy, evidence, authority and time.

Trusted evidence ingress is external to the Gateway:

```text
E_raw --(V_E)--> E_adm --(Pi_F)--> D
```

`PreverifiedEvidenceRef` (historical alias `VerifiedEvidenceRef`) is a trusted input class, not a claim that the Gateway re-established physical truth.

## MVP Scope

- TypeScript
- Node.js local runtime
- no runtime dependencies
- JCS-compatible deterministic JSON
- SHA-256 content identity
- Ed25519 DFD and authority signatures
- HMAC capability tokens
- append-only NDJSON journal
- offline verifier CLI
- ADV-01..ADV-09 tests

## First Demonstration

A compromised agent receives a prompt injection asking it to transfer money or send confidential material externally. The LLM can fail completely and still emit the dangerous proposal. FC Gateway rejects the consequence because it lacks the required admission path.

```text
Prompt injection succeeds
LLM proposes dangerous action
FC Gateway evaluates policy/authority/evidence
REJECT
No protected execution
DFD lineage records the attempt
```

Scientific claim:

```text
Cognitive compromise does not imply consequential authority.
```

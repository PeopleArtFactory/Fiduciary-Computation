$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$Src = "benchmarks/q1-performance/results/campaign-q1-003"
if (-not (Test-Path $Src)) { throw "missing $Src" }

$HostSafe = ($env:COMPUTERNAME -replace '[^A-Za-z0-9._-]', '_')
$Utc = [DateTime]::UtcNow.ToString("yyyyMMddTHHmmssZ")
$OutDir = "lab-out"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$Staging = Join-Path $OutDir "staging-$Utc"
New-Item -ItemType Directory -Force -Path $Staging | Out-Null
Copy-Item -Recurse $Src (Join-Path $Staging "campaign-q1-003")

@"
# Lab report — campaign-q1-003

- Host: $env:COMPUTERNAME
- UTC pack: $Utc
- HEAD: $(git rev-parse HEAD)
- Node: $(node -v)
- pnpm: $(pnpm -v)
- Platform: $([System.Environment]::OSVersion.VersionString)

Attach cloud instance type / region / disk type here before upload.
"@ | Set-Content -Encoding utf8 (Join-Path $Staging "LAB_REPORT.md")

$Zip = Join-Path $OutDir "campaign-q1-003-$HostSafe-$Utc.zip"
if (Test-Path $Zip) { Remove-Item $Zip }
Compress-Archive -Path (Join-Path $Staging '*') -DestinationPath $Zip
Remove-Item -Recurse -Force $Staging
Write-Host "Wrote $Zip"
Write-Host "Upload this file to the paper swarm. Do not invent Section 7 numbers locally."

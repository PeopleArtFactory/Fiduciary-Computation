import { FiduciaryValidationError } from "../core/errors.js";
import type { JsonObject, JsonValue } from "../core/types.js";

export class CanonicalizationError extends Error {
  constructor(
    public readonly code: "NON_JSON_VALUE" | "NON_FINITE_NUMBER" | "INVALID_UNICODE" | "CYCLIC_STRUCTURE",
    message: string,
  ) {
    super(message);
    this.name = "CanonicalizationError";
  }
}

export function canonicalizeJson(value: JsonValue): string {
  return serialize(value, new Set<object>(), "$root");
}

export function assertJsonValue(value: unknown, path = "$root"): asserts value is JsonValue {
  if (value === null) return;

  switch (typeof value) {
    case "string":
    case "boolean":
      return;
    case "number":
      if (!Number.isFinite(value)) {
        throw new CanonicalizationError("NON_FINITE_NUMBER", `Non-finite JSON number at ${path}.`);
      }
      return;
    case "object":
      if (Array.isArray(value)) {
        for (let index = 0; index < value.length; index += 1) {
          if (!Object.prototype.hasOwnProperty.call(value, index)) {
            throw new CanonicalizationError("NON_JSON_VALUE", `Sparse array hole at ${path}[${index}].`);
          }
          assertJsonValue(value[index], `${path}[${index}]`);
        }
        return;
      }
      if (Object.getPrototypeOf(value) !== Object.prototype) {
        throw new CanonicalizationError("NON_JSON_VALUE", `Unsupported JSON object at ${path}.`);
      }
      for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
        if (typeof child === "undefined") {
          throw new CanonicalizationError("NON_JSON_VALUE", `Undefined property at ${path}.${key}.`);
        }
        assertJsonValue(child, `${path}.${key}`);
      }
      return;
    default:
      throw new CanonicalizationError("NON_JSON_VALUE", `Unsupported JSON value at ${path}.`);
  }
}

export function assertJsonObject(value: unknown, path = "$root"): asserts value is JsonObject {
  assertJsonValue(value, path);
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new FiduciaryValidationError(`INVALID_JSON_OBJECT:${path}`);
  }
}

function serialize(value: JsonValue, seen: Set<object>, path: string): string {
  if (value === null) return "null";

  switch (typeof value) {
    case "boolean":
      return value ? "true" : "false";
    case "number":
      if (!Number.isFinite(value)) throw new CanonicalizationError("NON_FINITE_NUMBER", `Non-finite JSON number at ${path}.`);
      return JSON.stringify(value);
    case "string":
      assertValidUnicode(value);
      return JSON.stringify(value);
    case "object":
      break;
    default:
      throw new CanonicalizationError("NON_JSON_VALUE", `Unsupported JSON value at ${path}.`);
  }

  if (seen.has(value)) {
    throw new CanonicalizationError("CYCLIC_STRUCTURE", `Cyclic structure at ${path}.`);
  }

  seen.add(value);
  try {
    if (Array.isArray(value)) {
      for (let index = 0; index < value.length; index += 1) {
        if (!Object.prototype.hasOwnProperty.call(value, index)) {
          throw new CanonicalizationError("NON_JSON_VALUE", `Sparse array hole at ${path}[${index}].`);
        }
        // continue serialization via map after validation loop
      }
      return `[${value.map((item, index) => serialize(item, seen, `${path}[${index}]`)).join(",")}]`;
    }

    if (Object.getPrototypeOf(value) !== Object.prototype) {
      throw new CanonicalizationError("NON_JSON_VALUE", `Unsupported JSON object at ${path}.`);
    }

    const obj = value as Record<string, JsonValue>;
    return `{${Object.keys(obj)
      .sort()
      .map((key) => {
        assertValidUnicode(key);
        const member = obj[key];
        if (typeof member === "undefined") {
          throw new CanonicalizationError("NON_JSON_VALUE", `Undefined property at ${path}.${key}.`);
        }
        return `${JSON.stringify(key)}:${serialize(member, seen, `${path}.${key}`)}`;
      })
      .join(",")}}`;
  } finally {
    seen.delete(value);
  }
}

function assertValidUnicode(value: string): void {
  for (let i = 0; i < value.length; i += 1) {
    const code = value.charCodeAt(i);

    if (code >= 0xd800 && code <= 0xdbff) {
      if (i + 1 >= value.length) throw invalidUnicode();
      const next = value.charCodeAt(i + 1);
      if (next < 0xdc00 || next > 0xdfff) throw invalidUnicode();
      i += 1;
      continue;
    }

    if (code >= 0xdc00 && code <= 0xdfff) throw invalidUnicode();
  }
}

function invalidUnicode(): CanonicalizationError {
  return new CanonicalizationError("INVALID_UNICODE", "Canonical JSON contains an isolated UTF-16 surrogate.");
}

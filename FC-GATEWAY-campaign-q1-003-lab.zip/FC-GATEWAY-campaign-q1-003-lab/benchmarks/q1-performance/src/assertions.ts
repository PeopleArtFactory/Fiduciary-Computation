import type { DFDDeed } from "../../../dist/src/index.js";
import { verifyLineage } from "../../../dist/src/index.js";
import type { FiduciaryJournal } from "../../../dist/src/index.js";

export function assertPreparedPersisted(journal: FiduciaryJournal, prepared: DFDDeed): void {
  const deeds = journal.readAllDeeds();
  const found = deeds.find(
    (d) => d.deedId === prepared.deedId && d.dfdHash === prepared.dfdHash && d.phase === "EXECUTION_PREPARED",
  );
  if (!found) {
    throw new Error("INVALID_MEASUREMENT: B3 PREPARED not readable from journal");
  }
}

export function assertLineageValid(
  deeds: readonly DFDDeed[],
  opts: { sealerPublicKeyPem: string; sealerIssuer: string; sealerIssuerKeyId: string },
): void {
  const verification = verifyLineage(deeds, opts);
  if (!verification.report.integrityValid) {
    throw new Error("INVALID_MEASUREMENT: lineage integrity invalid");
  }
}

export function assertSingleClosure(deeds: readonly DFDDeed[], preparedDeedId: string): void {
  const closures = deeds.filter(
    (d) =>
      d.preparedDeedId === preparedDeedId &&
      (d.phase === "OUTCOME_SUCCESS" || d.phase === "OUTCOME_UNKNOWN" || d.phase === "OUTCOME_NO_EFFECT"),
  );
  if (closures.length !== 1) {
    throw new Error(`INVALID_MEASUREMENT: expected exactly 1 closure, got ${closures.length}`);
  }
}

import type { Hash256 } from "./types.js";

export const FCG_VERSION = "0.1";

/** Domain tags for cryptographic protocol messages. Null byte is appended by domainSeparatedMessage(). */
export const DOMAIN_CAPABILITY = "FCG:v0.1:CAPABILITY";
export const DOMAIN_AUTHORITY = "FCG:v0.1:AUTHORITY_CLAIM";
export const DOMAIN_LINEAGE = "FCG:v0.1:LINEAGE";
export const DOMAIN_CHECKPOINT = "FCG:v0.1:CHECKPOINT";

export const GENESIS_LABEL = "FCG:v0.1:GENESIS";

/** Canonical empty-lineage predecessor hash for ordinal 0. */
export const FCG_GENESIS_HASH: Hash256 = "817f19c269a50f8b244331fef16d92e0eacde624718422d7d20d9f137e6bdabc";

export const HASH256_HEX_LENGTH = 64;
export const HMAC_SHA256_HEX_LENGTH = 64;
export const ED25519_SIGNATURE_HEX_LENGTH = 128;
export const MIN_HMAC_SECRET_BYTES = 32;
export const MAX_CAPABILITY_TTL_MS = 300_000;
export const DEFAULT_CAPABILITY_TTL_MS = 30_000;

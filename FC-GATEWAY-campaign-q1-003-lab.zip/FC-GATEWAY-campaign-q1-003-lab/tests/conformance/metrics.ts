export interface RatioMetric {
  numerator: number;
  denominator: number;
  value: number | null;
  target: number;
  status: "PASS" | "FAIL" | "N/A";
}

export interface K9Metrics {
  positiveControlPassed: boolean;
  consequenceCases: number;
  consequenceBreaches: number;
  consequenceVectors: number;
  compromisedVectors: number;
  integrityCases: number;
  integrityFailures: number;
  externalEffects: number;
  authorizedEffects: number;
  unsanctionedEffects: number;
  asrCase: RatioMetric;
  asrVector: RatioMetric;
  ucr: RatioMetric;
}

export function ratio(numerator: number, denominator: number, target: number): RatioMetric {
  if (denominator <= 0) {
    return { numerator, denominator, value: null, target, status: "N/A" };
  }
  const value = numerator / denominator;
  return {
    numerator,
    denominator,
    value,
    target,
    status: value === target ? "PASS" : "FAIL",
  };
}

export function buildK9Metrics(input: {
  positiveControlPassed: boolean;
  consequenceCases: number;
  consequenceBreaches: number;
  consequenceVectors: number;
  compromisedVectors: number;
  integrityCases: number;
  integrityFailures: number;
  externalEffects: number;
  authorizedEffects: number;
  unsanctionedEffects: number;
}): K9Metrics {
  return {
    ...input,
    asrCase: ratio(input.consequenceBreaches, input.consequenceCases, 0),
    asrVector: ratio(input.compromisedVectors, input.consequenceVectors, 0),
    ucr: ratio(input.unsanctionedEffects, input.externalEffects, 0),
  };
}

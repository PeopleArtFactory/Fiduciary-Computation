import test from "node:test";
import assert from "node:assert/strict";
import {
  DOMAIN_AUTHORITY,
  DOMAIN_CAPABILITY,
  canonicalizeJson,
  computeCapabilityMac,
  signCanonical,
  verifyCanonical,
} from "../src/index.js";

/**
 * Stable TEST-ONLY Ed25519 keypair for protocol freeze regression.
 * Not a production key. Do not reuse outside conformance vectors.
 */
const FREEZE_PRIVATE_KEY = `-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEII8Os5HuzaqiiMZ8GLsp75HeRRi7lEWwKozNaZ/1AFMM
-----END PRIVATE KEY-----
`;

const FREEZE_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAgky4bgM/VY8QNuQInHHxs7QU6ju2gtSQnZNFGGDSpVQ=
-----END PUBLIC KEY-----
`;

const FREEZE_CLAIM = {
  claimId: "claim_freeze_v01",
  issuer: "authority:freeze-root",
  subject: "actor_freeze",
  permits: ["TRANSFER_APPROVE"],
  issuedAt: 1000,
  expiresAt: 5000,
  nonce: "nonce_freeze_01",
};

const EXPECTED_AUTHORITY_JCS =
  '{"claim":{"claimId":"claim_freeze_v01","expiresAt":5000,"issuedAt":1000,"issuer":"authority:freeze-root","nonce":"nonce_freeze_01","permits":["TRANSFER_APPROVE"],"subject":"actor_freeze"},"domain":"FCG:v0.1:AUTHORITY_CLAIM"}';

const EXPECTED_AUTHORITY_SIGNATURE =
  "101c65fea8e3c001065d0fe56e79f3e0964f69ae13a23676ae8e307fd9f2130f37c3b3e6ab34d2abaf5a719718845a40a9ba305e1165f126b3617a7af35f4807";

const FREEZE_HMAC_SECRET = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

const FREEZE_UNSIGNED_CAPABILITY = {
  tokenId: "cap_freeze_v01",
  admissionId: "adm_freeze_v01",
  admissionHash: "aa".repeat(32),
  proposalHash: "bb".repeat(32),
  issuer: "fc-gateway",
  audience: "fiduciary-executor",
  issuedAt: 2000,
  expiresAt: 5000,
  scope: { action: "bank.transfer", target: "account_1" },
  nonce: "nonce_cap_freeze",
};

test("v0.1 freeze: AuthorityClaim signs UTF8(JCS({domain, claim})) with no SHA-256 prehash", () => {
  const wrapped = { domain: DOMAIN_AUTHORITY, claim: FREEZE_CLAIM };
  assert.equal(canonicalizeJson(wrapped as never), EXPECTED_AUTHORITY_JCS);
  const signature = signCanonical(wrapped, FREEZE_PRIVATE_KEY);
  assert.equal(signature, EXPECTED_AUTHORITY_SIGNATURE);
  assert.equal(verifyCanonical(wrapped, EXPECTED_AUTHORITY_SIGNATURE, FREEZE_PUBLIC_KEY), true);
});

const EXPECTED_CAPABILITY_MAC = "a80bc6d2dbb20384746f48051902693aa56a682eb1fa4964d6ff228b995e16f5";

test("v0.1 freeze: capability MAC is HMAC over Domain || 0x00 || JCS(unsigned)", () => {
  assert.equal(DOMAIN_CAPABILITY, "FCG:v0.1:CAPABILITY");
  const mac = computeCapabilityMac(FREEZE_UNSIGNED_CAPABILITY, FREEZE_HMAC_SECRET);
  assert.equal(mac, EXPECTED_CAPABILITY_MAC);
  const reordered = {
    nonce: FREEZE_UNSIGNED_CAPABILITY.nonce,
    scope: FREEZE_UNSIGNED_CAPABILITY.scope,
    expiresAt: FREEZE_UNSIGNED_CAPABILITY.expiresAt,
    issuedAt: FREEZE_UNSIGNED_CAPABILITY.issuedAt,
    audience: FREEZE_UNSIGNED_CAPABILITY.audience,
    issuer: FREEZE_UNSIGNED_CAPABILITY.issuer,
    proposalHash: FREEZE_UNSIGNED_CAPABILITY.proposalHash,
    admissionHash: FREEZE_UNSIGNED_CAPABILITY.admissionHash,
    admissionId: FREEZE_UNSIGNED_CAPABILITY.admissionId,
    tokenId: FREEZE_UNSIGNED_CAPABILITY.tokenId,
  };
  assert.equal(computeCapabilityMac(reordered, FREEZE_HMAC_SECRET), EXPECTED_CAPABILITY_MAC);
});

import { tryIssueCapabilityToken } from "./capability.js";
import { FiduciaryEngine } from "./engine.js";
import { FiduciaryExecutor } from "./executor.js";
import { FiduciarySecurityError } from "./errors.js";
import { publicKeyFingerprint } from "../crypto/hash.js";
import type {
  AdmissionDecision,
  AuthorityClaim,
  ExecutionResult,
  FiduciaryPolicy,
  JsonValue,
  Proposal,
  TrustedIssuer,
  VerifiedEvidenceRef,
} from "./types.js";
import { FiduciaryJournal } from "../journal/journal.js";

export interface FiduciaryGatewayConfig {
  policies: readonly FiduciaryPolicy[];
  trustedIssuers: readonly TrustedIssuer[];
  hmacSecret: Buffer;
  journal: FiduciaryJournal;
  gatewayId?: string;
  executorId?: string;
  now?: () => number;
}

function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value as Record<string, unknown>)) {
      deepFreeze(child);
    }
  }
  return value;
}

function cloneJson<T>(value: T): T {
  return structuredClone(value);
}

export class FiduciaryGateway {
  private readonly engine = new FiduciaryEngine();
  private readonly executor: FiduciaryExecutor;
  private readonly now: () => number;
  private readonly policies: readonly FiduciaryPolicy[];
  private readonly trustedIssuers: readonly TrustedIssuer[];
  private readonly hmacSecret: Buffer;
  private readonly gatewayId?: string;
  private readonly executorId?: string;

  constructor(config: FiduciaryGatewayConfig) {
    this.assertTrustedIssuerSet(config.trustedIssuers);
    this.policies = deepFreeze(cloneJson(config.policies));
    this.trustedIssuers = deepFreeze(cloneJson(config.trustedIssuers));
    this.hmacSecret = Buffer.from(config.hmacSecret);
    this.gatewayId = config.gatewayId;
    this.executorId = config.executorId;
    this.executor = new FiduciaryExecutor(this.hmacSecret, config.journal, config.gatewayId, config.executorId);
    this.now = config.now ?? Date.now;
  }

  public evaluate(proposal: Proposal, authorityClaims: readonly AuthorityClaim[] = [], evidences: readonly VerifiedEvidenceRef[] = []): AdmissionDecision {
    return this.engine.evaluate(proposal, this.policies, authorityClaims, this.trustedIssuers, evidences, this.now());
  }

  public async execute<T extends JsonValue>(
    proposal: Proposal,
    decision: AdmissionDecision,
    operation: () => Promise<T> | T,
    ttlMs = 30_000,
  ): Promise<ExecutionResult<T> | null> {
    const t = this.now();
    const capability = tryIssueCapabilityToken(decision, proposal, {
      issuer: this.gatewayId ?? "fc-gateway",
      audience: this.executorId ?? "fiduciary-executor",
      fiduciaryClock: t,
      ttlMs,
      hmacSecret: this.hmacSecret,
    });
    if (!capability) return null;
    return this.executor.executeConsequence(proposal, decision, capability, t, operation);
  }

  private assertTrustedIssuerSet(issuers: readonly TrustedIssuer[]): void {
    const fingerprints = new Map<string, string>();
    for (const issuer of issuers) {
      const fp = publicKeyFingerprint(issuer.publicKeyPem);
      const existing = fingerprints.get(issuer.issuerId);
      if (existing && existing !== fp) {
        throw new FiduciarySecurityError("DUPLICATE_TRUSTED_ISSUER");
      }
      fingerprints.set(issuer.issuerId, fp);
    }
  }
}

import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { canonicalizeJson } from "../../../dist/src/index.js";
import type { JsonValue } from "../../../dist/src/index.js";

const here = path.dirname(fileURLToPath(import.meta.url));
export const HARNESS_ROOT = path.resolve(here, "..");
export const SPEC_PATH = path.join(HARNESS_ROOT, "benchmark-spec-v0.1.1.json");
export const SPEC_HASH_PATH = path.join(HARNESS_ROOT, "benchmark-spec-v0.1.1.sha256");
export const PACK_HASH_PATH = path.join(HARNESS_ROOT, "source-pack-v0.1.1.sha256");

/** Pinned H_spec from the frozen pre-campaign file. Any mismatch ⇒ NEW CAMPAIGN. */
export const PINNED_H_SPEC = fs.readFileSync(SPEC_HASH_PATH, "utf8").trim();

export interface BenchSpecV011 {
  schema: string;
  parameters: {
    samples: number;
    warmupCore: number;
    warmupB5: number;
    warmupB6: number;
    lineageSizes: number[];
  };
  [key: string]: unknown;
}

export interface SourceIdentity {
  label: string;
  commit: string;
  tree: string | null;
  dirty: boolean;
  dirtyPaths: string[];
  lockfileSha256: string | null;
  packageJsonSha256: string;
  packagePath: string;
  gitRoot: string;
  packageRelPath: string;
}

export interface GeneratorIdentity {
  files: Record<string, string>;
  generatorHash: string;
}

export interface PackIdentity {
  files: Record<string, string>;
  packHash: string;
}

function tryExec(cmd: string, args: string[], cwd: string): string | null {
  try {
    return execFileSync(cmd, args, { cwd, encoding: "utf8" }).trim();
  } catch {
    return null;
  }
}

export function sha256Bytes(data: Buffer | string): string {
  return createHash("sha256").update(data).digest("hex");
}

export function sha256File(filePath: string): string {
  return sha256Bytes(fs.readFileSync(filePath));
}

export function loadBenchSpec(specPath = SPEC_PATH): BenchSpecV011 {
  const raw = fs.readFileSync(specPath, "utf8");
  return JSON.parse(raw) as BenchSpecV011;
}

export function computeSpecHash(spec: BenchSpecV011): string {
  return sha256Bytes(canonicalizeJson(spec as unknown as JsonValue));
}

export function assertSpecPinned(spec: BenchSpecV011 = loadBenchSpec()): string {
  const h = computeSpecHash(spec);
  if (h !== PINNED_H_SPEC) {
    throw new Error(
      `INVALID_MEASUREMENT: H_spec mismatch (computed=${h}, pinned=${PINNED_H_SPEC}). Spec change requires NEW CAMPAIGN.`,
    );
  }
  return h;
}

export function collectSourceIdentity(packageRoot: string, label: string): SourceIdentity {
  const gitRoot = tryExec("git", ["rev-parse", "--show-toplevel"], packageRoot) ?? packageRoot;
  const commit = tryExec("git", ["rev-parse", "HEAD"], packageRoot) ?? "UNKNOWN";
  const tree = tryExec("git", ["rev-parse", "HEAD^{tree}"], packageRoot);
  const packageRelPath = path.relative(gitRoot, packageRoot).split(path.sep).join("/");
  const monitored = ["src", "tests", "package.json", "tsconfig.json", "benchmarks/q1-performance"].map(
    (p) => (packageRelPath ? `${packageRelPath}/${p}` : p),
  );
  const status = tryExec("git", ["status", "--porcelain", "--", ...monitored], gitRoot) ?? "";
  const dirtyPaths = status
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  const packageJsonPath = path.join(packageRoot, "package.json");
  const lockCandidates = ["pnpm-lock.yaml", "package-lock.json", "yarn.lock"].map((n) =>
    path.join(packageRoot, n),
  );
  const lockPath = lockCandidates.find((p) => fs.existsSync(p)) ?? null;

  return {
    label,
    commit,
    tree,
    dirty: dirtyPaths.length > 0,
    dirtyPaths,
    lockfileSha256: lockPath ? sha256File(lockPath) : null,
    packageJsonSha256: sha256File(packageJsonPath),
    packagePath: packageRoot,
    gitRoot,
    packageRelPath,
  };
}

/** Hash all TypeScript sources that define measurement/report behavior. */
export function collectGeneratorIdentity(harnessSrcDir = path.join(HARNESS_ROOT, "src")): GeneratorIdentity {
  const files: Record<string, string> = {};
  const walk = (dir: string) => {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(abs);
      else if (ent.isFile() && ent.name.endsWith(".ts")) {
        const rel = path.relative(harnessSrcDir, abs).split(path.sep).join("/");
        files[rel] = sha256File(abs);
      }
    }
  };
  walk(harnessSrcDir);
  const ordered = Object.keys(files)
    .sort()
    .map((k) => [k, files[k]!] as const);
  const generatorHash = sha256Bytes(
    canonicalizeJson(Object.fromEntries(ordered) as unknown as JsonValue),
  );
  return { files: Object.fromEntries(ordered), generatorHash };
}

const PACK_ROOTS = ["src", "tests", "scripts", "lab", "benchmarks/q1-performance"] as const;
const PACK_SINGLE_FILES = ["package.json", "pnpm-lock.yaml", "tsconfig.json", "LAB_MANIFEST.json"] as const;
const PACK_EXCLUDED_DIRS = new Set(["dist", "results", "node_modules", ".git", "lab-out"]);
const PACK_EXCLUDED_FILES = new Set(["source-pack-v0.1.1.sha256"]);

/** Canonical source-pack identity for multi-runner campaign equivalence. */
export function collectPackIdentity(packageRoot: string): PackIdentity {
  const files: Record<string, string> = {};
  const addFile = (abs: string) => {
    const rel = path.relative(packageRoot, abs).split(path.sep).join("/");
    if (PACK_EXCLUDED_FILES.has(path.basename(abs))) return;
    files[rel] = sha256File(abs);
  };
  const walk = (absDir: string) => {
    if (!fs.existsSync(absDir)) return;
    for (const ent of fs.readdirSync(absDir, { withFileTypes: true })) {
      if (PACK_EXCLUDED_DIRS.has(ent.name)) continue;
      const abs = path.join(absDir, ent.name);
      if (ent.isDirectory()) walk(abs);
      else if (ent.isFile()) addFile(abs);
    }
  };
  for (const rel of PACK_ROOTS) walk(path.join(packageRoot, rel));
  for (const rel of PACK_SINGLE_FILES) {
    const abs = path.join(packageRoot, rel);
    if (fs.existsSync(abs)) addFile(abs);
  }
  const ordered = Object.keys(files)
    .sort()
    .map((k) => [k, files[k]!] as const);
  const packHash = sha256Bytes(
    canonicalizeJson(Object.fromEntries(ordered) as unknown as JsonValue),
  );
  return { files: Object.fromEntries(ordered), packHash };
}

export function assertPackPinned(packageRoot: string): PackIdentity {
  const identity = collectPackIdentity(packageRoot);
  const pinned = fs.readFileSync(PACK_HASH_PATH, "utf8").trim();
  if (identity.packHash !== pinned) {
    throw new Error(
      `INVALID_MEASUREMENT: H_pack mismatch (computed=${identity.packHash}, pinned=${pinned}). Use the exact campaign pack.`,
    );
  }
  return identity;
}

export function wrapRawEnvelope(opts: {
  benchmark: string;
  sourceCommit: string;
  specHash: string;
  environmentHash: string;
  samplesExpected: number;
  samples: unknown;
  extra?: Record<string, unknown>;
}): Record<string, unknown> {
  const samplesArr = Array.isArray(opts.samples) ? opts.samples : null;
  return {
    schema: "FC-GATEWAY-BENCH-RAW-v0.1.1",
    sourceCommit: opts.sourceCommit,
    specHash: opts.specHash,
    environmentHash: opts.environmentHash,
    benchmark: opts.benchmark,
    samplesExpected: opts.samplesExpected,
    samplesObserved: samplesArr ? samplesArr.length : null,
    ...(opts.extra ?? {}),
    samples: opts.samples,
  };
}

#!/usr/bin/env node
import * as fs from "node:fs";
import type { LineageCheckpoint } from "../core/types.js";
import { verifyLineage } from "../lineage/verify.js";

const args = parseArgs(process.argv.slice(2));
const format = args.format === "human" ? "human" : "json";

if (!args.journal || !args.key) {
  usageAndExit();
}

try {
  const publicKeyPem = fs.readFileSync(args.key, "utf8");
  const deeds = fs.existsSync(args.journal)
    ? fs.readFileSync(args.journal, "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line))
    : [];
  const checkpoint = args.checkpoint
    ? (JSON.parse(fs.readFileSync(args.checkpoint, "utf8")) as LineageCheckpoint)
    : undefined;

  const { report } = verifyLineage(deeds, {
    sealerPublicKeyPem: publicKeyPem,
    checkpoint,
  });

  const payload = {
    result: "VALID",
    ...report,
  };

  if (format === "human") {
    console.log(`RESULT: VALID`);
    console.log(`deedCount: ${report.deedCount}`);
    console.log(`preparedCount: ${report.preparedCount}`);
    console.log(`closedCount: ${report.closedCount}`);
    console.log(`openPreparedCount: ${report.openPreparedCount}`);
    console.log(`headHash: ${report.headHash}`);
    console.log(`checkpointProvided: ${report.checkpointProvided}`);
    console.log(`checkpointVerified: ${report.checkpointVerified}`);
    console.log(`closureComplete: ${report.closureComplete}`);
  } else {
    console.log(JSON.stringify(payload, null, 2));
  }
  process.exit(0);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  if (/ENOENT|Unexpected token|JSON|Usage|INVALID_/.test(message) && !message.includes("CRITICAL_JOURNAL_CORRUPTION")) {
    // fall through — distinguish usage/IO vs integrity below
  }
  if (message.includes("CRITICAL_JOURNAL_CORRUPTION") || message.includes("INVALID_CHECKPOINT") || message.includes("CHECKPOINT_MISMATCH")) {
    if (format === "human") console.error(`RESULT: INVALID\n${message}`);
    else console.error(JSON.stringify({ result: "INVALID", reason: message }, null, 2));
    process.exit(1);
  }
  if (format === "human") console.error(`RESULT: ERROR\n${message}`);
  else console.error(JSON.stringify({ result: "ERROR", reason: message }, null, 2));
  process.exit(2);
}

function usageAndExit(): never {
  console.error("Usage: node dist/src/cli/verify.js --journal lineage.ndjson --key sealer-public.pem [--checkpoint checkpoint.json] [--format json|human]");
  process.exit(2);
}

function parseArgs(argv: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (let i = 0; i < argv.length; i += 1) {
    if (!argv[i].startsWith("--")) continue;
    const key = argv[i].slice(2);
    const value = argv[i + 1];
    if (!value || value.startsWith("--")) {
      console.error(`Missing value for --${key}`);
      process.exit(2);
    }
    out[key] = value;
    i += 1;
  }
  return out;
}

import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { canonicalizeJson } from "../../../dist/src/index.js";
import type { JsonValue } from "../../../dist/src/index.js";
import { CANDIDATE, FREEZE } from "./config.js";
import type { EnvironmentRecord } from "./environment.js";
import { wrapRawEnvelope } from "./provenance.js";
import { summarize, type BenchmarkSample, type DistributionSummary } from "./statistics.js";

export type MeasurementStatus = "VALID_MEASUREMENT" | "INVALID_MEASUREMENT";

export interface RawBundle {
  B0?: BenchmarkSample[];
  B1?: BenchmarkSample[];
  B2?: BenchmarkSample[];
  B3?: BenchmarkSample[];
  B4?: BenchmarkSample[];
  B5?: Array<{ lineageSize: number; samples: BenchmarkSample[] }>;
  B6?: BenchmarkSample[];
}

function sha256File(filePath: string): string {
  return createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

function assertSamples(id: string, samples: BenchmarkSample[], expected: number): void {
  if (samples.length !== expected) {
    throw new Error(`INVALID_MEASUREMENT: ${id} expected ${expected} samples, got ${samples.length}`);
  }
  const seen = new Set<number>();
  for (const s of samples) {
    if (!s.success) throw new Error(`INVALID_MEASUREMENT: ${id} contains failed sample`);
    if (BigInt(s.durationNs) <= 0n) throw new Error(`INVALID_MEASUREMENT: ${id} non-positive duration`);
    if (seen.has(s.iteration)) throw new Error(`INVALID_MEASUREMENT: ${id} duplicate iteration`);
    seen.add(s.iteration);
  }
  for (let i = 0; i < expected; i++) {
    if (!seen.has(i)) throw new Error(`INVALID_MEASUREMENT: ${id} missing iteration ${i}`);
  }
}

export function buildReport(opts: {
  outputDir: string;
  env: EnvironmentRecord;
  envHash: string;
  raw: RawBundle;
  samples: number;
  lineageSizes: number[];
}): { status: MeasurementStatus; summary: Record<string, unknown>; summaryMd: string; benchmarkHash: string } {
  const { outputDir, env, envHash, raw, samples, lineageSizes } = opts;
  const rawHashes: Record<string, string> = {};
  const sourceCommit = env.source.commit;
  const specHash = env.specHash;

  const writeRawEnvelope = (name: string, benchmark: string, data: unknown, extra?: Record<string, unknown>) => {
    const envelope = wrapRawEnvelope({
      benchmark,
      sourceCommit,
      specHash,
      environmentHash: envHash,
      samplesExpected: samples,
      samples: data,
      extra,
    });
    const file = path.join(outputDir, name);
    fs.writeFileSync(file, JSON.stringify(envelope, null, 2) + "\n");
    rawHashes[name] = sha256File(file);
  };

  if (raw.B0) {
    assertSamples("B0", raw.B0, samples);
    writeRawEnvelope("B0-direct.raw.json", "B0", raw.B0);
  }
  if (raw.B1) {
    assertSamples("B1", raw.B1, samples);
    writeRawEnvelope("B1-admission.raw.json", "B1", raw.B1);
  }
  if (raw.B2) {
    assertSamples("B2", raw.B2, samples);
    writeRawEnvelope("B2-capability.raw.json", "B2", raw.B2);
  }
  if (raw.B3) {
    assertSamples("B3", raw.B3, samples);
    writeRawEnvelope("B3-prepared.raw.json", "B3", raw.B3);
  }
  if (raw.B4) {
    assertSamples("B4", raw.B4, samples);
    writeRawEnvelope("B4-end-to-end.raw.json", "B4", raw.B4);
  }
  if (raw.B5) {
    const sizes = raw.B5.map((x) => x.lineageSize).sort((a, b) => a - b);
    const expected = [...lineageSizes].sort((a, b) => a - b);
    if (JSON.stringify(sizes) !== JSON.stringify(expected)) {
      throw new Error(`INVALID_MEASUREMENT: B5 lineage sizes mismatch ${sizes} vs ${expected}`);
    }
    for (const block of raw.B5) {
      assertSamples(`B5/${block.lineageSize}`, block.samples, samples);
      writeRawEnvelope(`B5-verification-N${block.lineageSize}.raw.json`, "B5", block.samples, {
        lineageSize: block.lineageSize,
      });
    }
  }
  if (raw.B6) {
    assertSamples("B6", raw.B6, samples);
    for (const s of raw.B6) {
      const boot = BigInt(String(s.meta?.bootstrapNs ?? "0"));
      const rec = BigInt(String(s.meta?.reconcileNs ?? "0"));
      const core = BigInt(String(s.meta?.coreRecoveryNs ?? s.durationNs));
      const cold = BigInt(String(s.meta?.coldProcessNs ?? "0"));
      if (boot + rec !== core) throw new Error("INVALID_MEASUREMENT: B6 bootstrap+reconcile != coreRecovery");
      if (!(core < cold)) throw new Error("INVALID_MEASUREMENT: B6 coreRecovery must be < workerEnvelope/coldProcess");
    }
    writeRawEnvelope("B6-recovery.raw.json", "B6", raw.B6);
  }

  const dist = (samplesArr?: BenchmarkSample[]): DistributionSummary | null =>
    samplesArr ? summarize(samplesArr) : null;

  const b0 = dist(raw.B0);
  const b4 = dist(raw.B4);
  const delta =
    b0 && b4
      ? {
          deltaLMedianMs: b4.medianMs - b0.medianMs,
          diagnosticNormalizedRatio:
            b0.medianMs > 0 ? (b4.medianMs - b0.medianMs) / b0.medianMs : null,
          note: "B0 is an instrumental timing floor only; absolute B1–B6 latencies are primary. Do not treat O_FC as a scientific claim.",
        }
      : null;

  const benchmarks: Record<string, unknown> = {
    B0: b0,
    B1: dist(raw.B1),
    B2: dist(raw.B2),
    B3: dist(raw.B3),
    B4: b4,
    B5: (raw.B5 ?? []).map((block) => ({
      lineageSize: block.lineageSize,
      ...summarize(block.samples),
      perDeedMedianMs: summarize(block.samples).medianMs / block.lineageSize,
    })),
    B6: raw.B6
      ? {
          ...summarize(raw.B6),
          workerEnvelopeMedianMs: summarize(
            raw.B6.map((s) => ({ ...s, durationNs: String(s.meta?.coldProcessNs ?? s.durationNs) })),
          ).medianMs,
          coldProcessMedianMs: summarize(
            raw.B6.map((s) => ({ ...s, durationNs: String(s.meta?.coldProcessNs ?? s.durationNs) })),
          ).medianMs,
          bootstrapMedianMs: summarize(
            raw.B6.map((s) => ({ ...s, durationNs: String(s.meta?.bootstrapNs ?? s.durationNs) })),
          ).medianMs,
          reconcileMedianMs: summarize(
            raw.B6.map((s) => ({ ...s, durationNs: String(s.meta?.reconcileNs ?? s.durationNs) })),
          ).medianMs,
        }
      : null,
    comparison: delta,
  };

  const invalidReasons: string[] = [];
  if (env.source.dirty) invalidReasons.push("dirty monitored tree");
  if (env.profile === "freeze" && !(env.source.frozenCommitMatches && env.source.frozenTagAtHead)) {
    invalidReasons.push("freeze mismatch");
  }

  const summaryBody = {
    schemaVersion: "fc-q1-benchmark-2",
    profile: env.profile,
    artifact: {
      historicalTag: FREEZE.tag,
      historicalCommit: FREEZE.commit,
      historicalReportHash: FREEZE.reportHash,
      candidateLabel: env.candidateLabel,
      sourceCommit: env.source.commit,
      sourceTree: env.source.tree,
      sourceDirty: env.source.dirty,
    },
    provenance: {
      rule: "H_benchmark commits Source + Spec + Environment + RawData + Generator + ReportBody",
      specHash,
      environmentHash: envHash,
      generatorHash: env.generator.generatorHash,
      rawFileSha256: rawHashes,
      source: {
        label: env.source.label,
        commit: env.source.commit,
        tree: env.source.tree,
        packageJsonSha256: env.source.packageJsonSha256,
        lockfileSha256: env.source.lockfileSha256,
      },
    },
    parameters: env.parameters,
    benchmarks,
  };

  const benchmarkHash = createHash("sha256")
    .update(canonicalizeJson(summaryBody as unknown as JsonValue), "utf8")
    .digest("hex");

  const status: MeasurementStatus = invalidReasons.length === 0 ? "VALID_MEASUREMENT" : "INVALID_MEASUREMENT";

  const summary = {
    ...summaryBody,
    status,
    invalidReasons,
    benchmarkHash,
    generatedAt: new Date().toISOString(),
    environment: env,
  };

  const label =
    env.profile === "candidate"
      ? `${CANDIDATE.label} @ ${env.source.commit}`
      : `${FREEZE.tag} / ${FREEZE.commit}`;

  const lines = [
    `# FC Gateway Q1 Benchmark Summary`,
    ``,
    `Status: **${status}**`,
    ``,
    `- Profile: \`${env.profile}\``,
    `- Artifact: \`${label}\``,
    `- H_spec: \`${specHash}\``,
    `- H_env: \`${envHash}\``,
    `- H_generator: \`${env.generator.generatorHash}\``,
    `- H_benchmark: \`${benchmarkHash}\``,
    `- Samples: ${samples}`,
  ];
  if (invalidReasons.length) {
    lines.push(`- Invalid reasons: ${invalidReasons.join("; ")}`);
  }
  lines.push(
    ``,
    `## Distributions (ms)`,
    ``,
    `| Bench | N | median | p95 | p99 | min | max |`,
    `|---|---:|---:|---:|---:|---:|---:|`,
  );
  for (const id of ["B0", "B1", "B2", "B3", "B4"] as const) {
    const d = benchmarks[id] as DistributionSummary | null;
    if (!d) continue;
    lines.push(
      `| ${id} | ${d.samples} | ${d.medianMs.toFixed(3)} | ${d.p95Ms.toFixed(3)} | ${d.p99Ms.toFixed(3)} | ${d.minMs.toFixed(3)} | ${d.maxMs.toFixed(3)} |`,
    );
  }
  if (delta) {
    lines.push(``, `ΔL_median(B4-B0)=${delta.deltaLMedianMs.toFixed(3)} ms (diagnostic only)`);
    lines.push(
      `diagnosticNormalizedRatio=${delta.diagnosticNormalizedRatio === null ? "n/a" : delta.diagnosticNormalizedRatio.toFixed(3)} (not a primary claim)`,
    );
    lines.push(``, `> ${delta.note}`);
  }
  lines.push(``, `## B5 scaling`);
  for (const row of benchmarks.B5 as Array<DistributionSummary & { lineageSize: number; perDeedMedianMs: number }>) {
    lines.push(
      `- N=${row.lineageSize}: median=${row.medianMs.toFixed(3)} ms (${row.perDeedMedianMs.toExponential(3)} ms/deed)`,
    );
  }
  if (benchmarks.B6) {
    const b6 = benchmarks.B6 as Record<string, number>;
    lines.push(``, `## B6 recovery`);
    lines.push(`- coreRecovery median: ${Number(b6.medianMs).toFixed(3)} ms`);
    lines.push(`- bootstrap median: ${Number(b6.bootstrapMedianMs).toFixed(3)} ms`);
    lines.push(`- reconcile median: ${Number(b6.reconcileMedianMs).toFixed(3)} ms`);
    lines.push(`- workerEnvelope median: ${Number(b6.workerEnvelopeMedianMs).toFixed(3)} ms`);
  }
  lines.push(``, `_Do not edit this file by hand. Regenerated by report.ts._`, ``);

  return { status, summary, summaryMd: lines.join("\n"), benchmarkHash };
}

export function writeReportOutputs(outputDir: string, summary: Record<string, unknown>, summaryMd: string): void {
  fs.writeFileSync(path.join(outputDir, "summary.json"), JSON.stringify(summary, null, 2) + "\n");
  fs.writeFileSync(path.join(outputDir, "SUMMARY.md"), summaryMd);
}

import { issueCapabilityToken } from "../../../dist/src/index.js";
import { assertPreparedPersisted } from "./assertions.js";
import { measure, type BenchmarkSample } from "./statistics.js";
import { HMAC_SECRET, makeProposal, openSession, type BenchFixture } from "./fixtures.js";

export async function runB3(fx: BenchFixture, samples: number, warmup: number): Promise<BenchmarkSample[]> {
  const out: BenchmarkSample[] = [];

  const one = async (iteration: number, record: boolean) => {
    // Fresh journal per sample so PREPARED assertions stay unambiguous and admissions are unused.
    const session = openSession(fx, "b3");
    const proposal = makeProposal(iteration, fx.evidence.evidenceId);
    const decision = session.gateway.evaluate(proposal, [fx.claim], [fx.evidence]);
    if (decision.result !== "ADMIT") throw new Error("B3 ADMIT failed");
    const capability = issueCapabilityToken(decision, proposal, {
      issuer: "fc-gateway",
      audience: "fiduciary-executor",
      fiduciaryClock: fx.clock,
      hmacSecret: HMAC_SECRET,
    });

    let prepared: ReturnType<typeof session.journal.reserveExecution> | undefined;
    const sample = await measure("B3", iteration, () => {
      prepared = session.journal.reserveExecution({
        tokenId: capability.tokenId,
        admissionHash: decision.admissionHash,
        proposalHash: capability.proposalHash,
        actor: proposal.actor,
        action: proposal.action,
        ...(proposal.target ? { target: proposal.target } : {}),
        timestamp: fx.clock,
      });
    });
    if (!sample.success) throw new Error(`INVALID_MEASUREMENT: B3 failed at ${iteration}: ${sample.meta?.error}`);
    if (!prepared) throw new Error("INVALID_MEASUREMENT: B3 missing PREPARED");
    assertPreparedPersisted(session.journal, prepared);
    if (!session.journal.isCapabilityConsumed(capability.tokenId)) {
      throw new Error("INVALID_MEASUREMENT: capability not marked consumed after PREPARED");
    }
    if (record) out.push(sample);
  };

  for (let i = 0; i < warmup; i++) await one(i, false);
  for (let i = 0; i < samples; i++) await one(i, true);
  return out;
}

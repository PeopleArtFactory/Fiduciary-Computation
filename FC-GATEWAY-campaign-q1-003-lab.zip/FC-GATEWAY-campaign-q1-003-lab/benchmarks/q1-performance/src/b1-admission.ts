import { normalizeProposal } from "../../../dist/src/index.js";
import { measure, type BenchmarkSample } from "./statistics.js";
import { createBenchFixture, makeRawProposal, openSession, type BenchFixture } from "./fixtures.js";

export async function runB1(fx: BenchFixture, samples: number, warmup: number): Promise<BenchmarkSample[]> {
  const session = openSession(fx, "b1");
  const raw = makeRawProposal(0, fx.evidence.evidenceId);

  const once = (iteration: number): void => {
    const proposal = normalizeProposal({
      ...raw,
      proposalId: `prop_b1_warm_${iteration}`,
    });
    const decision = session.gateway.evaluate(proposal, [fx.claim], [fx.evidence]);
    if (decision.result !== "ADMIT") throw new Error(`B1 not ADMIT: ${decision.result}`);
  };

  for (let i = 0; i < warmup; i++) once(i);

  const out: BenchmarkSample[] = [];
  for (let i = 0; i < samples; i++) {
    // Deterministic identity allocated outside the timer (no Math.random in hot path).
    const proposalId = `prop_b1_${i}`;
    const rawWithId = { ...raw, proposalId };
    let admitOk = false;
    const sample = await measure("B1", i, () => {
      const proposal = normalizeProposal(rawWithId);
      const decision = session.gateway.evaluate(proposal, [fx.claim], [fx.evidence]);
      admitOk = decision.result === "ADMIT";
    });
    if (!sample.success) throw new Error(`INVALID_MEASUREMENT: B1 failed at ${i}: ${sample.meta?.error}`);
    if (!admitOk) throw new Error(`INVALID_MEASUREMENT: B1 not ADMIT at ${i}`);
    out.push(sample);
  }
  return out;
}

export function bootstrapFixture(root: string): BenchFixture {
  return createBenchFixture(root);
}

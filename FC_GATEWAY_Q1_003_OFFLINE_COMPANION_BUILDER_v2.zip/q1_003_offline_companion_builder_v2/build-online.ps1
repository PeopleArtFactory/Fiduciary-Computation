param(
  [Parameter(Mandatory=$true)][string]$LabZip,
  [string]$OutputDir = (Join-Path (Get-Location) "FC-GATEWAY-q1-003-offline-toolchain")
)
$ErrorActionPreference = "Stop"
$ExpectedZip = "f0b46ab0d3f81e87fe7c82fc4a6f23ceb8057c59940cd7a67adb8f696b98c488"
$actual = (Get-FileHash -Algorithm SHA256 $LabZip).Hash.ToLowerInvariant()
if ($actual -ne $ExpectedZip) { throw "q1-003 lab ZIP hash mismatch: $actual" }

$tmp = Join-Path ([IO.Path]::GetTempPath()) ("fcgw-q1003-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
try {
  Expand-Archive -Path $LabZip -DestinationPath (Join-Path $tmp "lab")
  $root = Get-ChildItem (Join-Path $tmp "lab") -Directory | Select-Object -First 1
  if (-not $root) { throw "Extracted lab root not found" }
  if (Test-Path $OutputDir) { Remove-Item -Recurse -Force $OutputDir }
  New-Item -ItemType Directory -Force -Path (Join-Path $OutputDir "pnpm-store") | Out-Null
  $env:COREPACK_HOME = Join-Path $tmp "corepack-home"
  New-Item -ItemType Directory -Force -Path $env:COREPACK_HOME | Out-Null

  Push-Location $root.FullName
  corepack pack pnpm@10.0.0 -o (Join-Path $OutputDir "corepack-pnpm-10.0.0.tgz")
  corepack install -g --cache-only (Join-Path $OutputDir "corepack-pnpm-10.0.0.tgz")
  if ((corepack pnpm --version).Trim() -ne "10.0.0") { throw "pnpm 10.0.0 not active" }
  corepack pnpm fetch --frozen-lockfile --store-dir (Join-Path $OutputDir "pnpm-store")
  Pop-Location

  Copy-Item (Join-Path $root.FullName "pnpm-lock.yaml") $OutputDir
  Copy-Item (Join-Path $root.FullName "package.json") $OutputDir

  $files = Get-ChildItem $OutputDir -Recurse -File | Sort-Object FullName
  $manifest = foreach ($f in $files) {
    $rel = [IO.Path]::GetRelativePath($OutputDir, $f.FullName).Replace('\','/')
    $h = (Get-FileHash -Algorithm SHA256 $f.FullName).Hash.ToLowerInvariant()
    "$h  $rel"
  }
  $manifest | Set-Content -Encoding ascii (Join-Path $OutputDir "MANIFEST.sha256")

  $zip = "$OutputDir.zip"
  if (Test-Path $zip) { Remove-Item -Force $zip }
  Compress-Archive -Path "$OutputDir\*" -DestinationPath $zip
  $bundleHash = (Get-FileHash -Algorithm SHA256 $zip).Hash.ToLowerInvariant()
  "$bundleHash  $([IO.Path]::GetFileName($zip))" | Set-Content -Encoding ascii "$zip.sha256"
  Write-Host "OFFLINE TOOLCHAIN BUNDLE CREATED"
  Write-Host "bundle: $zip"
  Write-Host "sha256: $bundleHash"
}
finally {
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
}

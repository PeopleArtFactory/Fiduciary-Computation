#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 /path/to/FC-GATEWAY-campaign-q1-003-lab.zip /path/to/offline-toolchain.{tar.gz,zip} [work-dir]" >&2
  exit 2
fi

LAB_ZIP="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
BUNDLE="$(cd "$(dirname "$2")" && pwd)/$(basename "$2")"
WORK="${3:-$PWD/q1-003-offline-run}"
EXPECTED_ZIP="f0b46ab0d3f81e87fe7c82fc4a6f23ceb8057c59940cd7a67adb8f696b98c488"

for c in node corepack unzip sha256sum bash cp; do
  command -v "$c" >/dev/null || { echo "ERROR: $c required" >&2; exit 1; }
done

[ "$(sha256sum "$LAB_ZIP" | awk '{print $1}')" = "$EXPECTED_ZIP" ] || {
  echo "ERROR: lab ZIP hash mismatch" >&2
  exit 1
}

rm -rf "$WORK"
mkdir -p "$WORK/lab" "$WORK/toolchain" "$WORK/corepack-home"
unzip -q "$LAB_ZIP" -d "$WORK/lab"

case "$BUNDLE" in
  *.tar.gz|*.tgz)
    command -v tar >/dev/null || { echo "ERROR: tar required for $BUNDLE" >&2; exit 1; }
    tar -xzf "$BUNDLE" -C "$WORK/toolchain"
    ;;
  *.zip)
    unzip -q "$BUNDLE" -d "$WORK/toolchain"
    ;;
  *)
    echo "ERROR: unsupported companion archive: $BUNDLE" >&2
    exit 1
    ;;
esac

LABROOT="$(find "$WORK/lab" -mindepth 1 -maxdepth 1 -type d | head -1)"
[ -n "$LABROOT" ] || { echo "ERROR: extracted lab root not found" >&2; exit 1; }

# Builders differ in archive layout: POSIX tar contains one top-level directory,
# whereas PowerShell ZIP may place companion files at archive root.
if [ -f "$WORK/toolchain/MANIFEST.sha256" ]; then
  TOOLROOT="$WORK/toolchain"
else
  TOOLROOT="$(find "$WORK/toolchain" -mindepth 1 -maxdepth 1 -type d -exec test -f '{}/MANIFEST.sha256' ';' -print | head -1)"
fi
[ -n "${TOOLROOT:-}" ] && [ -f "$TOOLROOT/MANIFEST.sha256" ] || {
  echo "ERROR: companion MANIFEST.sha256 not found" >&2
  exit 1
}

(
  cd "$TOOLROOT"
  sha256sum -c MANIFEST.sha256
)

export COREPACK_HOME="$WORK/corepack-home"
corepack install -g --cache-only "$TOOLROOT/corepack-pnpm-10.0.0.tgz"
corepack pnpm@10.0.0 --version | grep -qx '10.0.0'

# Determine pnpm's native default store path, then seed it without changing any
# byte in the frozen q1-003 source pack.
STORE_PATH="$(cd "$LABROOT" && corepack pnpm@10.0.0 store path)"
mkdir -p "$STORE_PATH"
# pnpm 10 reports a versioned store path ending in /v10, while `pnpm fetch
# --store-dir <root>` materializes <root>/v10. Seed the contents of that
# versioned directory, not the parent, to avoid <store>/v10/v10 nesting.
if [ -d "$TOOLROOT/pnpm-store/v10" ] && [ "$(basename "$STORE_PATH")" = "v10" ]; then
  cp -a "$TOOLROOT/pnpm-store/v10/." "$STORE_PATH/"
else
  cp -a "$TOOLROOT/pnpm-store/." "$STORE_PATH/"
fi

# Force offline resolution while preserving the original laboratory files.
export npm_config_offline=true
export npm_config_prefer_offline=true

cd "$LABROOT"

# Expose the exact cached pnpm to the original bootstrap without editing it.
SHIMDIR="$WORK/bin"
mkdir -p "$SHIMDIR"
cat > "$SHIMDIR/pnpm" <<'EOS'
#!/usr/bin/env bash
exec corepack pnpm@10.0.0 "$@"
EOS
chmod +x "$SHIMDIR/pnpm"
export PATH="$SHIMDIR:$PATH"
pnpm --version | grep -qx '10.0.0'

# ZIP transport does not reliably preserve POSIX executable mode bits. Invoke
# the original scripts through bash; their bytes remain untouched and H_pack
# is therefore unaffected.
bash ./lab/00-bootstrap.sh
bash ./lab/01-pilot.sh

echo
cat <<EOF2
Offline bootstrap + pilot completed using the frozen q1-003 source bytes.
Inspect the pilot before the definitive campaign. If it reports
VALID_MEASUREMENT with the frozen q1-003 identities, run:
  cd "$LABROOT"
  bash ./lab/02-campaign-q1-003.sh
  bash ./lab/03-pack-results.sh
EOF2

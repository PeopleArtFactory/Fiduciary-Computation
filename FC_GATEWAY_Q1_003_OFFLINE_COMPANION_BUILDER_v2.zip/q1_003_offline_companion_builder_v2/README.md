# FC Gateway q1-003 Offline Toolchain Companion Builder — v2

This directory is **external to the frozen campaign-q1-003 source pack**. It
makes the exact toolchain available to an evaluator with no registry network
access without changing `H_spec`, `H_generator`, or `H_pack`.

## Why v2

An audit of the first companion builder found two transport-level defects that
do **not** affect campaign-q1-003 itself:

1. the frozen lab ZIP stores the POSIX `.sh` files without executable mode
   bits, while the first offline runner invoked them with `./...`;
2. the PowerShell builder emits a `.zip`, while the first POSIX offline runner
   accepted only `.tar.gz`.

v2 fixes only the external reproduction wrapper. It does not edit any file in
the frozen q1-003 source pack. The offline runner now invokes the original
scripts through `bash` and accepts either companion archive format.

## On a machine WITH registry/network access

POSIX:

```bash
./build-online.sh /path/to/FC-GATEWAY-campaign-q1-003-lab.zip
```

This creates `FC-GATEWAY-q1-003-offline-toolchain.tar.gz` plus its SHA-256.

Windows PowerShell:

```powershell
.\build-online.ps1 -LabZip .\FC-GATEWAY-campaign-q1-003-lab.zip
```

This creates `FC-GATEWAY-q1-003-offline-toolchain.zip` plus its SHA-256.

Both builders first verify the frozen lab ZIP SHA-256 and populate the
companion from the frozen lockfile using pnpm 10.0.0.

## On the OFFLINE evaluator

```bash
./seed-and-run-offline.sh \
  /path/to/FC-GATEWAY-campaign-q1-003-lab.zip \
  /path/to/FC-GATEWAY-q1-003-offline-toolchain.tar.gz
```

The second argument may also be the `.zip` emitted by the PowerShell builder.
The runner verifies the frozen lab ZIP, verifies every companion file against
`MANIFEST.sha256`, installs/caches pnpm 10.0.0 via Corepack, seeds pnpm's store,
forces offline resolution, and runs the **original** q1-003 bootstrap and pilot
files through `bash` without modifying their bytes.

The definitive N=1000 campaign remains a subsequent explicit action after the
pilot is inspected.

## Frozen scientific identity

The q1-003 source-pack identity remains unchanged:

- lab ZIP SHA-256: `f0b46ab0d3f81e87fe7c82fc4a6f23ceb8057c59940cd7a67adb8f696b98c488`
- `H_spec`: `9d7435f81f687a311537f2488727f43ae10746b1500cc71af3c29571814a7efe`
- `H_generator`: `c737483d4ecf3e466ec95dc941727b5fd9c5795cea8ca3253b39858f50cfa2f9`
- `H_pack`: `ee0111781bc4e22404fd1ee961698068bdef58700b9919211c1e0e08b481df44`

The companion bundle receives its own SHA-256 identity after it is built. It is
reproduction material, not part of the measurement generator. Publication
acceptance still requires every original q1-003 gate.

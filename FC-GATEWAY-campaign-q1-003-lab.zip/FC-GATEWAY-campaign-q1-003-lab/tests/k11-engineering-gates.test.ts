import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const script = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../scripts/check-engineering-gates.mjs");

function run(args: string[]) {
  return spawnSync(process.execPath, [script, ...args], { encoding: "utf8" });
}

function tempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k11-"));
}

test("K11-01 only devDependencies + small dist → exit 0", () => {
  const dir = tempDir();
  try {
    fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ dependencies: {}, devDependencies: { typescript: "5" } }));
    const dist = path.join(dir, "dist", "src");
    fs.mkdirSync(dist, { recursive: true });
    fs.writeFileSync(path.join(dist, "a.js"), "x".repeat(100));
    const out = path.join(dir, "out.json");
    const r = run(["--package", path.join(dir, "package.json"), "--dist", dist, "--output", out]);
    assert.equal(r.status, 0);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("K11-02 dependencies present → exit 1", () => {
  const dir = tempDir();
  try {
    fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ dependencies: { lodash: "1" } }));
    const dist = path.join(dir, "dist");
    fs.mkdirSync(dist, { recursive: true });
    fs.writeFileSync(path.join(dist, "a.js"), "x");
    const r = run(["--package", path.join(dir, "package.json"), "--dist", dist, "--output", path.join(dir, "o.json")]);
    assert.equal(r.status, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("K11-03 peerDependencies present → exit 1", () => {
  const dir = tempDir();
  try {
    fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ peerDependencies: { react: "18" } }));
    const dist = path.join(dir, "dist");
    fs.mkdirSync(dist, { recursive: true });
    fs.writeFileSync(path.join(dist, "a.js"), "x");
    const r = run(["--package", path.join(dir, "package.json"), "--dist", dist, "--output", path.join(dir, "o.json")]);
    assert.equal(r.status, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("K11-04 exactly 1_400_000 bytes → exit 1", () => {
  const dir = tempDir();
  try {
    fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ dependencies: {} }));
    const dist = path.join(dir, "dist");
    fs.mkdirSync(dist, { recursive: true });
    fs.writeFileSync(path.join(dist, "a.js"), Buffer.alloc(1_400_000, 1));
    const r = run(["--package", path.join(dir, "package.json"), "--dist", dist, "--output", path.join(dir, "o.json")]);
    assert.equal(r.status, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("K11-05 1_399_999 bytes → exit 0", () => {
  const dir = tempDir();
  try {
    fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ dependencies: {} }));
    const dist = path.join(dir, "dist");
    fs.mkdirSync(dist, { recursive: true });
    fs.writeFileSync(path.join(dist, "a.js"), Buffer.alloc(1_399_999, 1));
    const r = run(["--package", path.join(dir, "package.json"), "--dist", dist, "--output", path.join(dir, "o.json")]);
    assert.equal(r.status, 0);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("K11-06 missing dist → exit 2", () => {
  const dir = tempDir();
  try {
    fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ dependencies: {} }));
    const r = run(["--package", path.join(dir, "package.json"), "--dist", path.join(dir, "missing"), "--output", path.join(dir, "o.json")]);
    assert.equal(r.status, 2);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

import { FiduciaryValidationError } from "../core/errors.js";

/**
 * Domain-separated message: UTF-8(domain) || 0x00 || payloadBytes.
 * Domains must come from src/core/constants.ts and must not already contain a trailing NUL.
 */
export function domainSeparatedMessage(domain: string, payloadBytes: Buffer): Buffer {
  if (!domain || domain.includes("\0")) {
    throw new FiduciaryValidationError("INVALID_CRYPTO_DOMAIN");
  }
  return Buffer.concat([Buffer.from(domain, "utf8"), Buffer.from([0]), payloadBytes]);
}

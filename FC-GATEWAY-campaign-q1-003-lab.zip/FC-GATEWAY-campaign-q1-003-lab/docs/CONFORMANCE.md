# v0.1 Conformance Notes

These notes preserve the final canonical corrections from the source conversation. They distinguish the frozen protocol shape from the work required to claim a conformant release.

## Frozen Does Not Mean Conformant

`v0.1-canonical` freezes the architecture:

```text
Cognition -> Proposal -> ADMIT -> Capability -> PREPARED -> ExecutionAttempt -> SUCCESS | NO_EFFECT | UNKNOWN
```

The implementation can only be called `v0.1.0-conformant` after its code and tests prove that the frozen invariants hold under the ADV suite and crash/restart cases.

## Canonical Input Domain

All operands of `Pi_F(P,R,A,K_T,E,t_F)` must be data artifacts that can be represented with deterministic JSON canonicalization:

- `Proposal`
- declarative `FiduciaryPolicy` data
- `AuthorityClaim`
- canonical trusted issuer records
- verified evidence references
- trusted fiduciary clock

The canonical input domain excludes executable policy functions, `unknown`, `Map`, `Set`, `undefined`, non-finite numbers, cyclic structures and invalid UTF-16 surrogate strings. Raw JSON parsers at HTTP or CLI boundaries must eventually reject duplicate property names before values enter the kernel.

## Capability Contract

A `CapabilityToken` is a runtime-local HMAC artifact, not a long-term public proof. It must bind:

- `admissionId`
- `admissionHash`
- `proposalHash`
- `issuer`
- `audience`
- `scope`
- validity window
- nonce

The HMAC input is domain-separated with `FCG:v0.1:CAPABILITY`. Ed25519 is reserved for authority claims, durable DFD lineage and checkpoints.

## Durable Lineage Contract

Every durable execution record must preserve the causal chain:

```text
ProposalHash -> AdmissionHash -> Capability -> EXECUTION_PREPARED -> OUTCOME_*
```

The journal must enforce:

- Ed25519 authenticity for durable deeds, not only SHA-256 hash chaining.
- `EXECUTION_PREPARED -> CLOSED` as the only valid state machine.
- No outcome without a matching unclosed prepared deed.
- No duplicate outcome for the same prepared deed.
- `OUTCOME_NO_EFFECT` only with proof of no external effect.
- `OUTCOME_UNKNOWN` for crash, timeout or ambiguous external state.
- Durable state is written and fsynced before volatile state is mutated.
- Failed or uncertain persistence poisons the in-memory journal and requires restart.
- The first record uses the fixed genesis hash, not an absent previous hash.

## Operational Preconditions

FC Gateway v0.1 assumes exclusive single-writer ownership of each lineage journal. Other processes may audit/read the journal, but multiwriter locking and distributed consensus are explicitly later-version work.

`fsync` means fsync-backed crash-durable persistence under the guarantees of the host OS and filesystem. It is not a portable promise that bytes reached physical media under every hardware/controller/power-loss condition.

## Journal Release Gates

The journal cannot be tagged as conformant until these checks pass:

- Hash integrity
- Ed25519 authenticity
- transition validity
- admission at-most-once
- crash recovery
- checkpoint verification
- RFC 8785 conformance at the value boundary
- idempotent reconciliation: one orphan `EXECUTION_PREPARED` produces exactly one `OUTCOME_UNKNOWN`


import { readCrashFixture, buildCrashRuntime } from "../conformance/crash-fixture.js";
import type { AdmissionDecision, CapabilityToken } from "../../src/index.js";

const fixturePath = process.argv[2];
if (!fixturePath) {
  console.error("Usage: crash-inside-execution.js <fixture.json>");
  process.exit(2);
}

const bundle = readCrashFixture(fixturePath);
const { executor } = buildCrashRuntime(bundle);
const decision = JSON.parse(bundle.decisionJson) as AdmissionDecision;
const capability = JSON.parse(bundle.capabilityJson) as CapabilityToken;

process.send?.({ type: "READY" });

await executor.executeConsequence(bundle.proposal, decision, capability, bundle.fiduciaryClock, async () => {
  process.send?.({ type: "EXTERNAL_HANDLER_ENTERED" });
  await new Promise(() => {
    /* block forever until SIGKILL */
  });
  return { status: "UNREACHABLE" };
});

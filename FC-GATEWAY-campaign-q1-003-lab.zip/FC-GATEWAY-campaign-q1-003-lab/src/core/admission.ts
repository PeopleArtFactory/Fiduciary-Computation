import { hashJson } from "../crypto/hash.js";
import type { AdmissionDecision, JsonValue, VerifiedAuthorityClaimRef, VerifiedEvidenceRefBound } from "./types.js";
import { FiduciarySecurityError } from "./errors.js";

function sortByHash<T>(items: readonly T[]): T[] {
  return [...items].sort((a, b) => hashJson(a as unknown as JsonValue).localeCompare(hashJson(b as unknown as JsonValue)));
}

export function admissionBody(decision: Omit<AdmissionDecision, "admissionId" | "admissionHash">) {
  return {
    proposalHash: decision.proposalHash,
    policyId: decision.policyId,
    policyVersion: decision.policyVersion,
    policyHash: decision.policyHash,
    result: decision.result,
    reasons: [...decision.reasons].sort(),
    verifiedAuthorityClaims: sortByHash(decision.verifiedAuthorityClaims as readonly VerifiedAuthorityClaimRef[]),
    verifiedEvidences: sortByHash(decision.verifiedEvidences as readonly VerifiedEvidenceRefBound[]),
    evaluatedAt: decision.evaluatedAt,
  };
}

export function computeAdmissionHash(decision: Omit<AdmissionDecision, "admissionId" | "admissionHash">): string {
  return hashJson(admissionBody(decision) as unknown as JsonValue);
}

export function computeAdmissionId(admissionHash: string): string {
  return `adm_${admissionHash.slice(0, 24)}`;
}

export function assertAdmissionDecisionIntegrity(decision: AdmissionDecision): void {
  const { admissionId, admissionHash, ...body } = decision;
  const expectedHash = computeAdmissionHash(body);
  if (expectedHash !== admissionHash) {
    throw new FiduciarySecurityError("INVALID_ADMISSION_HASH");
  }
  if (admissionId !== computeAdmissionId(admissionHash)) {
    throw new FiduciarySecurityError("INVALID_ADMISSION_ID");
  }
}

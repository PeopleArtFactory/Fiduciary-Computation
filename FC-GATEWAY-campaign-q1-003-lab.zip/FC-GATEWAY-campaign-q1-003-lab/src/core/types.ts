export type JsonPrimitive = null | boolean | number | string;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };

export type Hash256 = string;
export type ActorType = "human" | "ai" | "sensor" | "software";
export type RiskLevel = 0 | 1 | 2 | 3 | 4;

export type ConsequenceClass =
  | "READ"
  | "WRITE"
  | "COMMUNICATION"
  | "FINANCIAL"
  | "IDENTITY"
  | "PRIVILEGED"
  | "PHYSICAL"
  | "IRREVERSIBLE";

export type AdmissionResult = "ADMIT" | "DEGRADE" | "REJECT";
export type DeedPhase =
  | "EXECUTION_PREPARED"
  | "OUTCOME_SUCCESS"
  | "OUTCOME_NO_EFFECT"
  | "OUTCOME_UNKNOWN";

export interface ActorRef {
  type: ActorType;
  id: string;
}

export interface Proposal {
  proposalId: string;
  actor: ActorRef;
  action: string;
  target?: string;
  parameters: JsonObject;
  contextRefs: string[];
  requestedAt: number;
}

export interface PolicyConstraint {
  field: string;
  operator: "eq" | "neq" | "lte" | "gte" | "contains";
  value: JsonValue;
}

export interface FiduciaryPolicy {
  policyId: string;
  version: string;
  action: string;
  consequenceClass: ConsequenceClass;
  riskLevel: RiskLevel;
  requiredAuthorityPermits?: string[];
  requiredEvidenceTypes?: string[];
  constraints?: PolicyConstraint[];
  effectOnMatch: AdmissionResult;
}

export interface AuthorityClaim {
  claimId: string;
  issuer: string;
  subject: string;
  permits: string[];
  issuedAt: number;
  expiresAt: number;
  nonce: string;
  signature: string;
}

export interface TrustedIssuer {
  issuerId: string;
  publicKeyPem: string;
}

export interface PreverifiedEvidenceRef {
  evidenceId: string;
  type: string;
  producer: string;
  contentHash: Hash256;
  verifiedAt: number;
}

/**
 * @deprecated Historical v0.1 name.
 * Gateway consumes pre-verified evidence references; it does not itself
 * authenticate the underlying raw evidence artifact (that is V_E).
 */
export type VerifiedEvidenceRef = PreverifiedEvidenceRef;

export interface VerifiedAuthorityClaimRef {
  claimId: string;
  claimHash: Hash256;
  issuerKeyFingerprint: Hash256;
}

export interface VerifiedEvidenceRefBound {
  evidenceId: string;
  evidenceHash: Hash256;
}

export interface AdmissionDecision {
  admissionId: string;
  proposalHash: Hash256;
  policyId: string;
  policyVersion: string;
  policyHash: Hash256;
  result: AdmissionResult;
  reasons: string[];
  verifiedAuthorityClaims: VerifiedAuthorityClaimRef[];
  verifiedEvidences: VerifiedEvidenceRefBound[];
  evaluatedAt: number;
  admissionHash: Hash256;
}

export interface CapabilityToken {
  tokenId: string;
  admissionId: string;
  admissionHash: Hash256;
  proposalHash: Hash256;
  issuer: string;
  audience: string;
  issuedAt: number;
  expiresAt: number;
  scope: {
    action: string;
    target?: string;
  };
  nonce: string;
  mac: string;
}

export interface DFDDeed {
  dfdVersion: "0.1";
  ordinal: number;
  deedId: string;
  phase: DeedPhase;
  tokenId: string;
  admissionHash: Hash256;
  proposalHash: Hash256;
  actor: ActorRef;
  action: string;
  target?: string;
  outcomeHash?: Hash256;
  errorCode?: string;
  preparedDeedId?: string;
  preparedDfdHash?: Hash256;
  timestamp: number;
  prevDfdHash: Hash256;
  issuer: string;
  issuerKeyId: string;
  dfdHash: Hash256;
  signature: string;
}

export interface UnsignedDFDDeed extends Omit<DFDDeed, "dfdHash" | "signature"> {}

export interface LineageCheckpoint {
  version: "0.1";
  ordinal: number;
  headHash: Hash256;
  issuedAt: number;
  issuer: string;
  issuerKeyId: string;
  signature: string;
}

export interface ExecutionResult<T extends JsonValue = JsonValue> {
  success: boolean;
  value?: T;
  error?: Error;
  preparedDeed: DFDDeed;
  outcomeDeed: DFDDeed;
}

export interface FiduciaryMetrics {
  adversarialAttempts: number;
  adversarialSuccesses: number;
  protectedExecutions: number;
  unsanctionedExecutions: number;
  repeatedAdmissions: number;
  deterministicAdmissions: number;
  protectedExecutionAttempts: number;
  preparedLineageCount: number;
  preparedCount: number;
  closureCount: number;
}

import * as fs from "node:fs";
import * as path from "node:path";
import { FCG_GENESIS_HASH } from "../core/constants.js";
import { hashJson } from "../crypto/hash.js";
import type { DFDDeed, DeedPhase, Hash256, JsonValue, LineageCheckpoint } from "../core/types.js";
import type { DeedDraft, DFDSealer } from "../dfd/sealer.js";
import { applyLineageTransition, createLineageState, validateLineageTransition, type LineageState } from "../lineage/state-machine.js";
import { verifyLineage } from "../lineage/verify.js";

/**
 * Minimal injectable write surface for deterministic fault-injection tests.
 * Intentionally not a general storage adapter.
 */
export interface JournalWriteIO {
  openSync: typeof fs.openSync;
  writeSync: (
    fd: number,
    buffer: NodeJS.ArrayBufferView,
    offset?: number | null,
    length?: number | null,
    position?: number | null,
  ) => number;
  fsyncSync: typeof fs.fsyncSync;
  closeSync: typeof fs.closeSync;
}

export const nodeJournalWriteIO: JournalWriteIO = {
  openSync: fs.openSync,
  writeSync: fs.writeSync,
  fsyncSync: fs.fsyncSync,
  closeSync: fs.closeSync,
};

function writeAllSync(io: JournalWriteIO, fd: number, data: Buffer): void {
  let offset = 0;
  while (offset < data.length) {
    const written = io.writeSync(fd, data, offset, data.length - offset, null);
    if (written <= 0) {
      throw new Error("JOURNAL_WRITE_NO_PROGRESS");
    }
    offset += written;
  }
}

export class FiduciaryJournal {
  private readonly lineagePath: string;
  private currentHeadHash: Hash256 = FCG_GENESIS_HASH;
  private currentOrdinal = 0;
  private poisoned = false;
  private lineageState: LineageState = createLineageState();

  constructor(
    private readonly sealer: DFDSealer,
    private readonly baseDir = "./.fiduciary-journal",
    private readonly writeIO: JournalWriteIO = nodeJournalWriteIO,
  ) {
    fs.mkdirSync(baseDir, { recursive: true });
    this.lineagePath = path.join(baseDir, "lineage.ndjson");
    this.bootstrapAndVerify();
  }

  public getLineagePath(): string {
    return this.lineagePath;
  }

  public getHeadHash(): Hash256 {
    return this.currentHeadHash;
  }

  public getOrdinal(): number {
    return this.currentOrdinal;
  }

  public isCapabilityConsumed(tokenId: string): boolean {
    return this.lineageState.consumedTokenIds.has(tokenId);
  }

  public isAdmissionConsumed(admissionHash: Hash256): boolean {
    return this.lineageState.consumedAdmissionHashes.has(admissionHash);
  }

  public reserveExecution(draft: Omit<DeedDraft, "phase">): DFDDeed {
    this.assertHealthy();
    if (this.lineageState.consumedTokenIds.has(draft.tokenId)) throw new Error("CAPABILITY_REPLAY_REJECTED");
    if (this.lineageState.consumedAdmissionHashes.has(draft.admissionHash)) throw new Error("ADMISSION_REPLAY_REJECTED");

    const deed = this.appendSignedDeed({ ...draft, phase: "EXECUTION_PREPARED" });
    return deed;
  }

  public appendOutcome(preparedDeed: DFDDeed, phase: Exclude<DeedPhase, "EXECUTION_PREPARED">, details: { outcome?: JsonValue; errorCode?: string; timestamp: number }): DFDDeed {
    this.assertHealthy();
    if (preparedDeed.phase !== "EXECUTION_PREPARED") throw new Error("INVALID_LINEAGE_TRANSITION:OUTCOME_WITHOUT_PREPARED");
    if (this.lineageState.closedPreparedIds.has(preparedDeed.deedId)) throw new Error("INVALID_LINEAGE_TRANSITION:PREPARED_ALREADY_CLOSED");

    const outcomeHash = typeof details.outcome === "undefined" ? undefined : hashJson(details.outcome);
    return this.appendSignedDeed({
      phase,
      tokenId: preparedDeed.tokenId,
      admissionHash: preparedDeed.admissionHash,
      proposalHash: preparedDeed.proposalHash,
      actor: preparedDeed.actor,
      action: preparedDeed.action,
      target: preparedDeed.target,
      preparedDeedId: preparedDeed.deedId,
      preparedDfdHash: preparedDeed.dfdHash,
      ...(outcomeHash ? { outcomeHash } : {}),
      ...(details.errorCode ? { errorCode: details.errorCode } : {}),
      timestamp: details.timestamp,
    });
  }

  public reconcileStartupState(timestamp: number): number {
    this.assertHealthy();
    const open = [...this.lineageState.preparedByDeedId.values()];
    let count = 0;
    for (const deed of open) {
      this.appendOutcome(deed, "OUTCOME_UNKNOWN", { timestamp, errorCode: "STARTUP_RECONCILIATION_UNKNOWN" });
      count += 1;
    }
    return count;
  }

  public generateCheckpoint(timestamp: number): LineageCheckpoint {
    this.assertHealthy();
    return this.sealer.signCheckpoint({
      version: "0.1",
      ordinal: this.currentOrdinal,
      headHash: this.currentHeadHash,
      issuedAt: timestamp,
      issuer: this.sealer.issuer,
      issuerKeyId: this.sealer.issuerKeyId,
    });
  }

  public readAllDeeds(): DFDDeed[] {
    if (!fs.existsSync(this.lineagePath)) return [];
    const text = fs.readFileSync(this.lineagePath, "utf8");
    if (text.length === 0) return [];
    if (!(text.endsWith("\n") || text.endsWith("\r\n"))) {
      throw new Error("JOURNAL_TORN_TAIL");
    }
    const lines = text.split(/\r?\n/).filter(Boolean);
    return lines.map((line) => JSON.parse(line) as DFDDeed);
  }

  private appendSignedDeed(draft: DeedDraft): DFDDeed {
    this.assertHealthy();
    const deed = this.sealer.sealDeed(draft, this.currentOrdinal + 1, this.currentHeadHash);
    if (!this.sealer.verifyDeed(deed)) throw new Error("INVALID_DEED_SIGNATURE");

    const transition = validateLineageTransition(this.lineageState, deed);

    const encoded = Buffer.from(`${JSON.stringify(deed)}\n`, "utf8");
    const fd = this.writeIO.openSync(this.lineagePath, "a");
    try {
      writeAllSync(this.writeIO, fd, encoded);
      this.writeIO.fsyncSync(fd);
    } catch (error) {
      this.poisoned = true;
      throw error;
    } finally {
      this.writeIO.closeSync(fd);
    }

    // In-memory transition only after complete write + successful host sync.
    applyLineageTransition(this.lineageState, transition);
    this.currentOrdinal = deed.ordinal;
    this.currentHeadHash = deed.dfdHash;
    return deed;
  }

  private bootstrapAndVerify(): void {
    const deeds = this.readAllDeeds();
    const verified = verifyLineage(deeds, { sealerPublicKeyPem: this.sealer.publicKeyPem, sealerIssuer: this.sealer.issuer, sealerIssuerKeyId: this.sealer.issuerKeyId });
    this.lineageState = verified.state;
    this.currentHeadHash = verified.report.headHash;
    this.currentOrdinal = verified.report.lastOrdinal;
  }

  private assertHealthy(): void {
    if (this.poisoned) throw new Error("JOURNAL_FAIL_CLOSED_RESTART_REQUIRED");
  }
}

import { measure, type BenchmarkSample } from "./statistics.js";
import { protectedOperation } from "./fixtures.js";

export async function runB0(samples: number, warmup: number): Promise<BenchmarkSample[]> {
  const input = { ok: true, n: 1 };
  const once = async () => {
    await protectedOperation(input);
  };
  for (let i = 0; i < warmup; i++) await once();
  const out: BenchmarkSample[] = [];
  for (let i = 0; i < samples; i++) {
    const sample = await measure("B0", i, once);
    if (!sample.success) throw new Error(`INVALID_MEASUREMENT: B0 failed at ${i}`);
    out.push(sample);
  }
  return out;
}

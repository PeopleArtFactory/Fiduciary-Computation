import test from "node:test";
import assert from "node:assert/strict";
import { FiduciaryValidationError, hashJson, normalizeProposal } from "../src/index.js";

const base = {
  proposalId: "p1",
  actor: { type: "ai", id: "agent" },
  action: "email.send",
  parameters: { recipient: "a@example.com" },
  requestedAt: 1000,
};

test("K3-01 normalizeProposal(undefined) REJECT", () => {
  assert.throws(() => normalizeProposal(undefined), FiduciaryValidationError);
});

test("K3-02 parameters undefined property REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { x: undefined } }), FiduciaryValidationError);
});

test("K3-03 parameters NaN REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { x: Number.NaN } }), FiduciaryValidationError);
});

test("K3-04 parameters Infinity REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { x: Infinity } }), FiduciaryValidationError);
});

test("K3-05 parameters BigInt REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { x: 1n as never } }), FiduciaryValidationError);
});

test("K3-06 actor.type workflow REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, actor: { type: "workflow", id: "w1" } }), /INVALID_ACTOR_TYPE/);
});

test("K3-07 actor.id wrong type REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, actor: { type: "ai", id: 1 } }), FiduciaryValidationError);
});

test("K3-08 action wrong type REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, action: 123 }), FiduciaryValidationError);
});

test("K3-09 fiduciary self-classification fields projected out", () => {
  const normalized = normalizeProposal({
    ...base,
    riskLevel: 0,
    consequenceClass: "READ",
    overrideAdmission: true,
  });
  assert.equal("riskLevel" in normalized, false);
  assert.equal("consequenceClass" in normalized, false);
  assert.equal("overrideAdmission" in normalized, false);
});

test("K3-10 actor.version / actor.extra projected out", () => {
  const normalized = normalizeProposal({
    ...base,
    actor: { type: "ai", id: "agent", version: "9.9.9", extra: true },
  });
  assert.deepEqual(normalized.actor, { type: "ai", id: "agent" });
});

test("K3-11 omitted contextRefs NORMALIZE []", () => {
  const normalized = normalizeProposal(base);
  assert.deepEqual(normalized.contextRefs, []);
});

test("K3-12 sparse array inside parameters REJECT", () => {
  const sparse: unknown[] = [];
  sparse[1] = "x";
  assert.throws(() => normalizeProposal({ ...base, parameters: { items: sparse } }), FiduciaryValidationError);
});

test("K3-13 Date inside parameters REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { when: new Date() } }), FiduciaryValidationError);
});

test("K3-14 Buffer inside parameters REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { blob: Buffer.from("x") } }), FiduciaryValidationError);
});

test("K3-15 function inside parameters REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, parameters: { fn: () => 1 } }), FiduciaryValidationError);
});

test("K3-16 requestedAt NaN / float / Infinity REJECT", () => {
  assert.throws(() => normalizeProposal({ ...base, requestedAt: Number.NaN }), FiduciaryValidationError);
  assert.throws(() => normalizeProposal({ ...base, requestedAt: 1.5 }), FiduciaryValidationError);
  assert.throws(() => normalizeProposal({ ...base, requestedAt: Infinity }), FiduciaryValidationError);
});

test("K3-17 omitted contextRefs vs [] same canonical hash", () => {
  const a = normalizeProposal(base);
  const b = normalizeProposal({ ...base, contextRefs: [] });
  assert.deepEqual(a, b);
  assert.equal(hashJson(a as never), hashJson(b as never));
});

import { FiduciaryValidationError } from "./errors.js";
import { CanonicalizationError, assertJsonObject, assertJsonValue } from "../dfd/canonicalize.js";
import type { ActorRef, ActorType, Proposal } from "./types.js";

const actorTypes = new Set<ActorType>(["human", "ai", "sensor", "software"]);

export function normalizeProposal(input: unknown): Proposal {
  if (!isRecord(input)) throw new FiduciaryValidationError("INVALID_PROPOSAL_PAYLOAD");

  const proposalId = requireNonEmptyString(input.proposalId, "INVALID_PROPOSAL_ID");
  const action = requireNonEmptyString(input.action, "INVALID_ACTION");
  const actor = parseActor(input.actor);

  if ("target" in input && input.target !== undefined) {
    if (typeof input.target !== "string" || input.target.length === 0) {
      throw new FiduciaryValidationError("INVALID_TARGET");
    }
  }
  const target = typeof input.target === "string" && input.target.length > 0 ? input.target : undefined;

  if (!Number.isSafeInteger(input.requestedAt) || (input.requestedAt as number) < 0) {
    throw new FiduciaryValidationError("INVALID_REQUESTED_AT");
  }

  try {
    assertJsonObject(input.parameters, "parameters");
  } catch (error) {
    if (error instanceof CanonicalizationError || error instanceof FiduciaryValidationError) {
      throw new FiduciaryValidationError("INVALID_PARAMETERS");
    }
    throw error;
  }

  const contextRefs = parseContextRefs(input.contextRefs);

  return {
    proposalId,
    actor,
    action,
    ...(target ? { target } : {}),
    parameters: input.parameters,
    contextRefs,
    requestedAt: input.requestedAt as number,
  };
}

export function parseJsonPayload(input: unknown) {
  assertJsonValue(input, "payload");
  return input;
}

function parseActor(value: unknown): ActorRef {
  if (!isRecord(value)) throw new FiduciaryValidationError("INVALID_ACTOR");
  const type = requireNonEmptyString(value.type, "INVALID_ACTOR_TYPE") as ActorType;
  if (!actorTypes.has(type)) throw new FiduciaryValidationError("INVALID_ACTOR_TYPE");
  const id = requireNonEmptyString(value.id, "INVALID_ACTOR_ID");
  // actor.version and any other fields are projected out intentionally.
  return { type, id };
}

function parseContextRefs(value: unknown): string[] {
  if (typeof value === "undefined") return [];
  if (!Array.isArray(value)) throw new FiduciaryValidationError("INVALID_CONTEXT_REFS");
  // Reject sparse arrays: every index in [0, length) must be an own present element.
  for (let i = 0; i < value.length; i += 1) {
    if (!Object.prototype.hasOwnProperty.call(value, i)) {
      throw new FiduciaryValidationError("INVALID_CONTEXT_REFS");
    }
    const item = value[i];
    if (typeof item !== "string" || item.length === 0) {
      throw new FiduciaryValidationError("INVALID_CONTEXT_REFS");
    }
  }
  return value as string[];
}

function requireNonEmptyString(value: unknown, code: string): string {
  if (typeof value !== "string" || value.trim() === "") {
    throw new FiduciaryValidationError(code);
  }
  return value;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

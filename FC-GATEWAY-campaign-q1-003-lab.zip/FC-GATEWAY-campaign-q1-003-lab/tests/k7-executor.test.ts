import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  generateEd25519KeyPair,
  signAuthorityClaim,
} from "../src/index.js";
import type { FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");

function setup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k7-"));
  const auth = generateEd25519KeyPair();
  const keys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "a" };
  const policy: FiduciaryPolicy = {
    policyId: "p",
    version: "1",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 1,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 10 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "e",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1,
  };
  const proposal: Proposal = {
    proposalId: "prop",
    actor,
    action: "bank.transfer",
    parameters: { amount: 1 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1,
  };
  const claim = signAuthorityClaim(
    {
      claimId: "c",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1,
      expiresAt: 9_999,
      nonce: "n",
    },
    auth.privateKeyPem,
  );
  const sealer = new DFDSealer("n", "k", keys.publicKeyPem, keys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir);
  const engine = new FiduciaryEngine();
  const executor = new FiduciaryExecutor(hmacSecret, journal);
  const decision = engine.evaluate(proposal, [policy], [claim], trustedIssuers, [evidence], 10);
  const capability = engine.mintCapability(decision, proposal, hmacSecret, 10)!;
  return { dir, journal, executor, proposal, decision, capability };
}

test("K7 PREPARED is readable from disk before handler runs", async () => {
  const f = setup();
  try {
    let sawPrepared = false;
    await f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => {
      const deeds = f.journal.readAllDeeds();
      assert.equal(deeds.length, 1);
      assert.equal(deeds[0].phase, "EXECUTION_PREPARED");
      sawPrepared = true;
      return { ok: true };
    });
    assert.equal(sawPrepared, true);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K7 external throw yields OUTCOME_UNKNOWN without second rewrite", async () => {
  const f = setup();
  try {
    const result = await f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => {
      throw new Error("boom");
    });
    assert.equal(result.success, false);
    assert.equal(result.outcomeDeed.phase, "OUTCOME_UNKNOWN");
    assert.equal(f.journal.readAllDeeds().length, 2);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K7 invalid capability never enters operation", async () => {
  const f = setup();
  try {
    let calls = 0;
    await assert.rejects(
      () =>
        f.executor.executeConsequence(f.proposal, f.decision, { ...f.capability, mac: "0".repeat(64) }, 20, () => {
          calls += 1;
          return { ok: true };
        }),
      /INVALID_CAPABILITY_SIGNATURE/,
    );
    assert.equal(calls, 0);
    assert.equal(f.journal.readAllDeeds().length, 0);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

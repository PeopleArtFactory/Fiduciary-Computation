#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

SRC="benchmarks/q1-performance/results/campaign-q1-003"
test -d "$SRC" || { echo "ERROR: missing $SRC"; exit 1; }

HOST="$(hostname | tr -c 'A-Za-z0-9._-' '_' )"
UTC="$(date -u +%Y%m%dT%H%M%SZ)"
OUTDIR="lab-out"
mkdir -p "$OUTDIR"
STAGING="$OUTDIR/staging-$UTC"
mkdir -p "$STAGING"

cp -R "$SRC" "$STAGING/campaign-q1-003"

cat > "$STAGING/LAB_REPORT.md" <<EOF
# Lab report — campaign-q1-003

- Host: $(hostname)
- UTC pack: $UTC
- HEAD: $(git rev-parse HEAD 2>/dev/null || echo UNKNOWN)
- Node: $(node -v)
- pnpm: $(pnpm -v 2>/dev/null || echo UNKNOWN)
- Platform: $(uname -a 2>/dev/null || echo UNKNOWN)

Attach cloud instance type / region / disk type here before upload.
EOF

ZIP="$OUTDIR/campaign-q1-003-${HOST}-${UTC}.zip"
(
  cd "$STAGING"
  if command -v zip >/dev/null; then
    zip -r -q "../$(basename "$ZIP")" .
  else
    # fallback
    tar -czf "../$(basename "$ZIP" .zip).tar.gz" .
    echo "Wrote tar.gz (zip not available)"
    exit 0
  fi
)

rm -rf "$STAGING"
echo "Wrote $ZIP"
echo "Upload this file to the paper swarm. Do not invent Section 7 numbers locally."

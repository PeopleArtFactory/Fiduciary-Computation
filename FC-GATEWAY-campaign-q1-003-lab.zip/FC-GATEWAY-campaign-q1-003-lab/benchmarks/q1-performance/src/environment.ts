import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import { canonicalizeJson } from "../../../dist/src/index.js";
import type { JsonValue } from "../../../dist/src/index.js";
import { CANDIDATE, FREEZE, TOOLCHAIN, type BenchmarkConfig } from "./config.js";
import {
  assertSpecPinned,
  assertPackPinned,
  collectGeneratorIdentity,
  collectSourceIdentity,
  loadBenchSpec,
  type GeneratorIdentity,
  type PackIdentity,
  type SourceIdentity,
} from "./provenance.js";

export interface EnvironmentRecord {
  schema: "FC-GATEWAY-BENCH-ENV-v0.1.1";
  profile: BenchmarkConfig["profile"];
  artifactTag: string;
  artifactCommit: string;
  candidateLabel: string | null;
  source: SourceIdentity & {
    frozenCommitMatches: boolean;
    frozenTagAtHead: boolean;
    currentTag: string | null;
  };
  specHash: string;
  pack: PackIdentity;
  generator: GeneratorIdentity;
  node: string;
  pnpm: string | null;
  typescript: string | null;
  typesNode: string | null;
  undiciTypes: string | null;
  platform: string;
  osRelease: string;
  arch: string;
  cpuModel: string;
  logicalCpuCount: number;
  memoryBytes: number;
  filesystem: string | null;
  storageModel: string | null;
  cwdFilesystem: string | null;
  timezone: string;
  powerPolicy: string | null;
  virtualization: string | null;
  journalRoot: string;
  parameters: BenchmarkConfig;
  warmupPolicy: string;
  cachePolicy: string;
  hashExcludes: string[];
  generatedAt: string;
}

function tryExec(cmd: string, args: string[], cwd?: string): string | null {
  try {
    return execFileSync(cmd, args, { cwd, encoding: "utf8" }).trim();
  } catch {
    return null;
  }
}

function installedPackageVersion(repoRoot: string, packageName: string): string | null {
  const direct = pathForPackageJson(repoRoot, packageName);
  if (direct && fs.existsSync(direct)) {
    try {
      return (JSON.parse(fs.readFileSync(direct, "utf8")) as { version?: string }).version ?? null;
    } catch {
      return null;
    }
  }
  const pnpmRoot = `${repoRoot}/node_modules/.pnpm`;
  if (!fs.existsSync(pnpmRoot)) return null;
  const prefix = `${packageName.replace("/", "+")}@`;
  const entry = fs.readdirSync(pnpmRoot).find((name) => name.startsWith(prefix));
  if (!entry) return null;
  const abs = `${pnpmRoot}/${entry}/node_modules/${packageName}/package.json`;
  if (!fs.existsSync(abs)) return null;
  try {
    return (JSON.parse(fs.readFileSync(abs, "utf8")) as { version?: string }).version ?? null;
  } catch {
    return null;
  }
}

function pathForPackageJson(repoRoot: string, packageName: string): string | null {
  const parts = packageName.split("/");
  return `${repoRoot}/node_modules/${parts.join("/")}/package.json`;
}

export function collectEnvironment(cfg: BenchmarkConfig, repoRoot: string): EnvironmentRecord {
  const spec = loadBenchSpec();
  const specHash = assertSpecPinned(spec);
  const sourceBase = collectSourceIdentity(
    repoRoot,
    cfg.profile === "candidate" ? CANDIDATE.label : FREEZE.tag,
  );
  const currentTag = tryExec("git", ["describe", "--tags", "--exact-match", "HEAD"], repoRoot);
  const pack = assertPackPinned(repoRoot);
  const generator = collectGeneratorIdentity();
  const actualTypeScript = installedPackageVersion(repoRoot, "typescript");
  const actualTypesNode = installedPackageVersion(repoRoot, "@types/node");
  const actualUndiciTypes = installedPackageVersion(repoRoot, "undici-types");

  return {
    schema: "FC-GATEWAY-BENCH-ENV-v0.1.1",
    profile: cfg.profile,
    artifactTag: FREEZE.tag,
    artifactCommit: FREEZE.commit,
    candidateLabel: cfg.profile === "candidate" ? CANDIDATE.label : null,
    source: {
      ...sourceBase,
      currentTag,
      frozenCommitMatches: sourceBase.commit === FREEZE.commit,
      frozenTagAtHead: currentTag === FREEZE.tag,
    },
    specHash,
    pack,
    generator,
    node: process.version,
    pnpm: tryExec("pnpm", ["--version"], repoRoot),
    typescript: actualTypeScript,
    typesNode: actualTypesNode,
    undiciTypes: actualUndiciTypes,
    platform: process.platform,
    osRelease: os.release(),
    arch: process.arch,
    cpuModel: os.cpus()[0]?.model ?? "unknown",
    logicalCpuCount: os.cpus().length,
    memoryBytes: os.totalmem(),
    filesystem:
      process.platform === "win32"
        ? "ntfs-or-host"
        : tryExec("df", ["-T", "."])?.split("\n")[1]?.split(/\s+/)[1] ?? null,
    storageModel: null,
    cwdFilesystem: null,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone ?? "unknown",
    powerPolicy: null,
    virtualization: null,
    journalRoot: cfg.journalRoot,
    parameters: cfg,
    warmupPolicy: `core=${cfg.warmupCore};b5=${cfg.warmupB5};b6=${cfg.warmupB6}`,
    cachePolicy: "no-manual-cache-flush; host filesystem defaults",
    hashExcludes: ["generatedAt"],
    generatedAt: new Date().toISOString(),
  };
}

export function environmentHash(env: EnvironmentRecord): string {
  const { generatedAt: _t, ...stable } = env;
  const canonical = canonicalizeJson(stable as unknown as JsonValue);
  return createHash("sha256").update(canonical, "utf8").digest("hex");
}

export function assertMeasurementGates(env: EnvironmentRecord): void {
  if (env.source.dirty && !env.parameters.allowDirtyPilot) {
    throw new Error(
      `INVALID_MEASUREMENT: dirty monitored tree (${env.source.dirtyPaths.slice(0, 5).join("; ")})`,
    );
  }
  if (env.pnpm !== TOOLCHAIN.pnpm) {
    throw new Error(`INVALID_MEASUREMENT: pnpm ${env.pnpm ?? "missing"} != ${TOOLCHAIN.pnpm}`);
  }
  if (env.typescript !== TOOLCHAIN.typescript) {
    throw new Error(`INVALID_MEASUREMENT: TypeScript ${env.typescript ?? "missing"} != ${TOOLCHAIN.typescript}`);
  }
  if (env.typesNode !== TOOLCHAIN.typesNode) {
    throw new Error(`INVALID_MEASUREMENT: @types/node ${env.typesNode ?? "missing"} != ${TOOLCHAIN.typesNode}`);
  }
  if (env.undiciTypes !== TOOLCHAIN.undiciTypes) {
    throw new Error(`INVALID_MEASUREMENT: undici-types ${env.undiciTypes ?? "missing"} != ${TOOLCHAIN.undiciTypes}`);
  }
  if (env.profile === "freeze") {
    if (!env.source.frozenCommitMatches || !env.source.frozenTagAtHead) {
      throw new Error(
        `INVALID_MEASUREMENT: freeze mismatch commit=${env.source.commit} tag=${env.source.currentTag}`,
      );
    }
  }
}

/** Historical alias used by older call sites. */
export function assertFrozenEnvironment(env: EnvironmentRecord): void {
  assertMeasurementGates(env);
}

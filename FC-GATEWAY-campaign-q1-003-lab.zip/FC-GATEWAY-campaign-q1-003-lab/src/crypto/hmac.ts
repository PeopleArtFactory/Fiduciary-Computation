import { createHmac, timingSafeEqual } from "node:crypto";
import { DOMAIN_CAPABILITY, MIN_HMAC_SECRET_BYTES } from "../core/constants.js";
import { FiduciarySecurityError } from "../core/errors.js";
import type { JsonValue } from "../core/types.js";
import { canonicalizeJson } from "../dfd/canonicalize.js";
import { domainSeparatedMessage } from "./domain.js";
import { assertHmacSha256Hex, isHmacSha256Hex } from "./encoding.js";

export function assertHmacSecret(secret: Buffer): void {
  if (!Buffer.isBuffer(secret) || secret.length < MIN_HMAC_SECRET_BYTES) {
    throw new FiduciarySecurityError("HMAC_SECRET_TOO_SHORT");
  }
}

export function timingSafeHexEqual(a: string, b: string): boolean {
  if (!/^[0-9a-f]+$/.test(a) || !/^[0-9a-f]+$/.test(b)) return false;
  const left = Buffer.from(a, "hex");
  const right = Buffer.from(b, "hex");
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

function hmacSha256Hex(secret: Buffer, message: Buffer): string {
  assertHmacSecret(secret);
  return createHmac("sha256", secret).update(message).digest("hex");
}

/** Low-level HMAC over an already domain-separated message. Exported for K2 wrong-domain tests. */
export function hmacDomainSeparated(secret: Buffer, domain: string, payloadBytes: Buffer): string {
  return hmacSha256Hex(secret, domainSeparatedMessage(domain, payloadBytes));
}

export function computeCapabilityMac(unsignedCapability: object, secret: Buffer): string {
  const payload = Buffer.from(canonicalizeJson(unsignedCapability as JsonValue), "utf8");
  return hmacDomainSeparated(secret, DOMAIN_CAPABILITY, payload);
}

export function verifyCapabilityMac(unsignedCapability: object, mac: string, secret: Buffer): boolean {
  if (!isHmacSha256Hex(mac)) return false;
  assertHmacSha256Hex(mac);
  const expected = computeCapabilityMac(unsignedCapability, secret);
  return timingSafeHexEqual(expected, mac);
}

export function requireValidCapabilityMac(unsignedCapability: object, mac: string, secret: Buffer): void {
  if (!verifyCapabilityMac(unsignedCapability, mac, secret)) {
    throw new FiduciarySecurityError("INVALID_CAPABILITY_SIGNATURE");
  }
}

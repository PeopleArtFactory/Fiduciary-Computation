export interface SideEffectCounters {
  attackAttempts: number;
  externalEffects: number;
  authorizedEffects: number;
  unsanctionedEffects: number;
}

export function createSideEffectCounters(): SideEffectCounters {
  return {
    attackAttempts: 0,
    externalEffects: 0,
    authorizedEffects: 0,
    unsanctionedEffects: 0,
  };
}

export function createInstrumentedTool(counters: SideEffectCounters, mode: "authorized" | "adversarial" = "authorized") {
  return () => {
    counters.externalEffects += 1;
    if (mode === "authorized") counters.authorizedEffects += 1;
    else counters.unsanctionedEffects += 1;
    return { status: "EXECUTED" as const };
  };
}

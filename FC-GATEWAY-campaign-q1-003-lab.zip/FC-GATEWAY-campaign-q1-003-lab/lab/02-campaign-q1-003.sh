#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

OUT="benchmarks/q1-performance/results/campaign-q1-003"
mkdir -p "$OUT"
LOG="$OUT/run.log"

if [ -n "$(git status --porcelain -- src tests package.json tsconfig.json benchmarks/q1-performance)" ]; then
  echo "ERROR: monitored tree dirty — commit or stash before VALID campaign"
  git status --porcelain -- src tests package.json tsconfig.json benchmarks/q1-performance
  exit 1
fi

echo "START_UTC=$(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee "$LOG"
echo "HEAD=$(git rev-parse HEAD)" | tee -a "$LOG"
echo "HOST=$(hostname)" | tee -a "$LOG"
echo "NODE=$(node -v)" | tee -a "$LOG"

set +e
pnpm benchmark:q1 -- --profile candidate \
  --samples 1000 \
  --warmup-core 200 \
  --warmup-b5 20 \
  --warmup-b6 5 \
  --lineage-sizes 10,100,1000,10000 \
  --output "$OUT" >>"$LOG" 2>&1
CODE=$?
set -e

echo "END_UTC=$(date -u +%Y-%m-%dT%H:%M:%SZ)" | tee -a "$LOG"
echo "EXIT=$CODE" | tee -a "$LOG"

if [ -f "$OUT/summary.json" ]; then
  echo "--- summary status ---"
  node -e "const s=require('./$OUT/summary.json'); console.log(s.status||s.measurementStatus||JSON.stringify(s).slice(0,200))"
else
  echo "WARNING: no summary.json yet (exit=$CODE). See $LOG"
fi
exit $CODE

import type { DFDDeed } from "../core/types.js";

export interface LineageState {
  readonly preparedByDeedId: Map<string, DFDDeed>;
  readonly closedPreparedIds: Set<string>;
  readonly consumedTokenIds: Set<string>;
  readonly consumedAdmissionHashes: Set<string>;
}

export type LineageTransition =
  | { readonly kind: "PREPARE"; readonly deed: DFDDeed }
  | { readonly kind: "CLOSE"; readonly deed: DFDDeed; readonly preparedDeedId: string };

export function createLineageState(): LineageState {
  return {
    preparedByDeedId: new Map(),
    closedPreparedIds: new Set(),
    consumedTokenIds: new Set(),
    consumedAdmissionHashes: new Set(),
  };
}

export function validateLineageTransition(state: LineageState, deed: DFDDeed): LineageTransition {
  if (deed.phase === "EXECUTION_PREPARED") {
    if (state.consumedTokenIds.has(deed.tokenId)) {
      throw new Error("CRITICAL_JOURNAL_CORRUPTION:DUPLICATE_TOKEN");
    }
    if (state.consumedAdmissionHashes.has(deed.admissionHash)) {
      throw new Error("CRITICAL_JOURNAL_CORRUPTION:DUPLICATE_ADMISSION");
    }
    if (state.preparedByDeedId.has(deed.deedId) || state.closedPreparedIds.has(deed.deedId)) {
      throw new Error("CRITICAL_JOURNAL_CORRUPTION:DUPLICATE_PREPARED");
    }
    return { kind: "PREPARE", deed };
  }

  if (!deed.preparedDeedId) {
    throw new Error("CRITICAL_JOURNAL_CORRUPTION:OUTCOME_WITHOUT_PREPARED");
  }
  if (state.closedPreparedIds.has(deed.preparedDeedId)) {
    throw new Error("CRITICAL_JOURNAL_CORRUPTION:PREPARED_ALREADY_CLOSED");
  }

  const prepared = state.preparedByDeedId.get(deed.preparedDeedId);
  if (!prepared) {
    throw new Error("CRITICAL_JOURNAL_CORRUPTION:OUTCOME_WITHOUT_PREPARED");
  }
  if (deed.preparedDfdHash !== prepared.dfdHash) {
    throw new Error("CRITICAL_JOURNAL_CORRUPTION:PREPARED_HASH_MISMATCH");
  }
  if (deed.tokenId !== prepared.tokenId || deed.admissionHash !== prepared.admissionHash || deed.proposalHash !== prepared.proposalHash) {
    throw new Error("CRITICAL_JOURNAL_CORRUPTION:OUTCOME_BINDING_MISMATCH");
  }
  if (deed.action !== prepared.action || deed.target !== prepared.target) {
    throw new Error("CRITICAL_JOURNAL_CORRUPTION:OUTCOME_ACTION_MISMATCH");
  }

  return { kind: "CLOSE", deed, preparedDeedId: prepared.deedId };
}

export function applyLineageTransition(state: LineageState, transition: LineageTransition): void {
  if (transition.kind === "PREPARE") {
    state.consumedTokenIds.add(transition.deed.tokenId);
    state.consumedAdmissionHashes.add(transition.deed.admissionHash);
    state.preparedByDeedId.set(transition.deed.deedId, transition.deed);
    return;
  }

  state.preparedByDeedId.delete(transition.preparedDeedId);
  state.closedPreparedIds.add(transition.preparedDeedId);
}

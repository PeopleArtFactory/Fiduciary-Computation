#!/usr/bin/env node
import * as fs from "node:fs";
import * as path from "node:path";
import { pathToFileURL } from "node:url";

const artifactsDir = path.resolve("artifacts");

async function loadCrypto() {
  const canonicalizeUrl = pathToFileURL(path.resolve("dist/src/dfd/canonicalize.js")).href;
  const hashUrl = pathToFileURL(path.resolve("dist/src/crypto/hash.js")).href;
  const { canonicalizeJson } = await import(canonicalizeUrl);
  const { sha256Hex } = await import(hashUrl);
  return { canonicalizeJson, sha256Hex };
}

function readJson(name) {
  const file = path.join(artifactsDir, name);
  if (!fs.existsSync(file)) return { missing: true, file };
  try {
    return { missing: false, file, data: JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {
    return { missing: true, file, unreadable: true };
  }
}

const { canonicalizeJson, sha256Hex } = await loadCrypto();

const incompleteReasons = [];
const failures = [];

const k1 = readJson("K1_RFC8785_GATES.json");
const k4 = readJson("K4_ADMISSION_DETERMINISM.json");
const k9 = readJson("K9_ADVERSARIAL.json");
const k10 = readJson("K10_CRASH_RECOVERY.json");
const k11 = readJson("K11_ENGINEERING_GATES.json");

for (const [label, art] of [
  ["k1", k1],
  ["k4", k4],
  ["k9", k9],
  ["k10", k10],
  ["k11", k11],
]) {
  if (art.missing) incompleteReasons.push(`MISSING_${label.toUpperCase()}`);
}

const revisions = [k1, k4, k9, k10, k11]
  .filter((a) => !a.missing)
  .map((a) => `${a.data.kernelVersion}|${a.data.sourceRevision}`);
if (new Set(revisions).size > 1) incompleteReasons.push("MIXED_SOURCE_REVISION");

function metricOk(metric, expected) {
  if (!metric || metric.denominator <= 0 || metric.value === null || metric.value === undefined) return "incomplete";
  return metric.value === expected ? "pass" : "fail";
}

if (incompleteReasons.length === 0) {
  const checks = [
    ["ad", metricOk(k4.data.ad, 1)],
    ["asrCase", metricOk(k9.data.asrCase, 0)],
    ["asrVector", metricOk(k9.data.asrVector, 0)],
    ["ucr", metricOk(k9.data.ucr, 0)],
    ["elc", metricOk(k10.data.elc, 1)],
    ["fcc", metricOk(k10.data.fcc, 1)],
  ];
  for (const [name, status] of checks) {
    if (status === "incomplete") incompleteReasons.push(`METRIC_INCOMPLETE_${name}`);
    if (status === "fail") failures.push(name);
  }
  if (!k9.data.positiveControlPassed) failures.push("positiveControl");
  if ((k9.data.integrityFailures ?? 1) !== 0) failures.push("integrity");
  if (!k10.data.crashRecoveryPassed) failures.push("crashRecovery");
  if (!k10.data.reconciliationIdempotent) failures.push("reconciliationIdempotent");
  if (k1.data.status !== "PASS") failures.push("rfc8785");
  if (k11.data.runtimeDependencies?.status !== "PASS") failures.push("runtimeDependencies");
  if (k11.data.distributable?.status !== "PASS") failures.push("distributable");
}

let result = "INCOMPLETE";
if (incompleteReasons.length === 0) {
  result = failures.length === 0 ? "CONFORMANT" : "NON_CONFORMANT";
}

function stripVolatile(data) {
  if (!data || typeof data !== "object") return data;
  const clone = structuredClone(data);
  delete clone.generatedAt;
  if (clone.distributable && typeof clone.distributable === "object") {
    // Keep relative root only; ignore any absolute path residue.
    if (typeof clone.distributable.root === "string" && path.isAbsolute(clone.distributable.root)) {
      clone.distributable.root = "dist/src";
    }
  }
  return clone;
}

const evidence = {};
for (const [key, art] of [
  ["core", k1],
  ["k4", k4],
  ["k9", k9],
  ["k10", k10],
  ["k11", k11],
]) {
  if (!art.missing) {
    evidence[key] = {
      file: path.basename(art.file),
      hash: sha256Hex(Buffer.from(canonicalizeJson(stripVolatile(art.data)), "utf8")),
    };
  }
}

const unsigned = {
  schema: "FC_GATEWAY_v0.1_CONFORMANCE_REPORT",
  specification: "FC Gateway v0.1",
  kernelVersion: "0.1.0",
  sourceRevision: "local",
  evidence,
  gates: {
    positiveControl: k9.data?.positiveControlPassed ? "PASS" : "FAIL",
    adversarial: (k9.data?.asrCase?.value ?? 1) === 0 ? "PASS" : "FAIL",
    integrity: (k9.data?.integrityFailures ?? 1) === 0 ? "PASS" : "FAIL",
    crashRecovery: k10.data?.crashRecoveryPassed ? "PASS" : "FAIL",
    reconciliationIdempotence: k10.data?.reconciliationIdempotent ? "PASS" : "FAIL",
    rfc8785: k1.data?.status === "PASS" ? "PASS" : "FAIL",
  },
  metrics: {
    ad: k4.data?.ad ?? null,
    asrCase: k9.data?.asrCase ?? null,
    asrVector: k9.data?.asrVector ?? null,
    ucr: k9.data?.ucr ?? null,
    elc: k10.data?.elc ?? null,
    fcc: k10.data?.fcc ?? null,
  },
  engineering: {
    runtimeDependencies: k11.data?.runtimeDependencies ?? null,
    distributableBytes: stripVolatile(k11.data)?.distributable ?? null,
  },
  failures,
  incompleteReasons,
  result,
};

const reportHash = sha256Hex(Buffer.from(canonicalizeJson(unsigned), "utf8"));
const report = { ...unsigned, generatedAt: new Date().toISOString(), reportHash };

fs.mkdirSync(artifactsDir, { recursive: true });
fs.writeFileSync(path.join(artifactsDir, "FC_GATEWAY_v0.1_CONFORMANCE_REPORT.json"), JSON.stringify(report, null, 2));
fs.writeFileSync(
  path.join(artifactsDir, "FC_GATEWAY_v0.1_CONFORMANCE_REPORT.md"),
  `# FC Gateway v0.1 Conformance Report

Result: ${report.result}
Kernel version: ${report.kernelVersion}
Source revision: ${report.sourceRevision}
Report hash: ${report.reportHash}

## Claim Scope

CONFORMANT means that this implementation satisfied the declared FC Gateway v0.1 conformance gates represented by the evidence artifacts referenced in this report.

It does not constitute a proof of security outside the declared threat model or TCB.

## Failures
${failures.length ? failures.map((f) => `- ${f}`).join("\n") : "- none"}

## Incomplete reasons
${incompleteReasons.length ? incompleteReasons.map((f) => `- ${f}`).join("\n") : "- none"}
`,
);

console.log(`RESULT: ${result}`);
console.log(`REPORT_HASH: ${reportHash}`);
process.exit(result === "CONFORMANT" ? 0 : result === "NON_CONFORMANT" ? 1 : 2);

import { FCG_GENESIS_HASH } from "../core/constants.js";
import type { DFDDeed, Hash256, LineageCheckpoint, TrustedIssuer } from "../core/types.js";
import { DFDSealer } from "../dfd/sealer.js";
import { applyLineageTransition, createLineageState, validateLineageTransition, type LineageState } from "./state-machine.js";

export interface LineageVerificationOptions {
  readonly sealerPublicKeyPem: string;
  readonly sealerIssuer?: string;
  readonly sealerIssuerKeyId?: string;
  readonly checkpoint?: LineageCheckpoint;
  readonly trustedIssuersForCheckpoint?: readonly TrustedIssuer[];
}

export interface LineageVerificationReport {
  readonly integrityValid: true;
  readonly deedCount: number;
  readonly preparedCount: number;
  readonly closedCount: number;
  readonly openPreparedCount: number;
  readonly lastOrdinal: number;
  readonly headHash: Hash256;
  readonly checkpointProvided: boolean;
  readonly checkpointVerified: boolean;
  readonly closureComplete: boolean;
}

export interface LineageVerificationResult {
  readonly report: LineageVerificationReport;
  readonly state: LineageState;
}

export function verifyLineage(deeds: readonly DFDDeed[], options: LineageVerificationOptions): LineageVerificationResult {
  const sealer = new DFDSealer(
    options.sealerIssuer ?? "offline-verifier",
    options.sealerIssuerKeyId ?? "offline-key",
    options.sealerPublicKeyPem,
  );

  let head: Hash256 = FCG_GENESIS_HASH;
  let expectedOrdinal = 1;
  const state = createLineageState();
  let preparedCount = 0;
  let closedCount = 0;

  for (const deed of deeds) {
    if (deed.ordinal !== expectedOrdinal) {
      throw new Error(`CRITICAL_JOURNAL_CORRUPTION:ORDINAL_GAP at ${deed.ordinal}`);
    }
    if (deed.prevDfdHash !== head) {
      throw new Error(`CRITICAL_JOURNAL_CORRUPTION:LINEAGE_HEAD_MISMATCH at ordinal ${deed.ordinal}`);
    }
    if (!sealer.verifyDeed(deed)) {
      throw new Error(`CRITICAL_JOURNAL_CORRUPTION:INVALID_DEED at ordinal ${deed.ordinal}`);
    }

    const transition = validateLineageTransition(state, deed);
    applyLineageTransition(state, transition);
    if (transition.kind === "PREPARE") preparedCount += 1;
    else closedCount += 1;

    head = deed.dfdHash;
    expectedOrdinal += 1;
  }

  let checkpointVerified = false;
  if (options.checkpoint) {
    const trusted = options.trustedIssuersForCheckpoint ?? [
      { issuerId: options.checkpoint.issuerKeyId, publicKeyPem: options.sealerPublicKeyPem },
      { issuerId: options.checkpoint.issuer, publicKeyPem: options.sealerPublicKeyPem },
    ];
    const result = sealer.verifyCheckpoint(options.checkpoint, trusted);
    if (!result.valid) {
      throw new Error("CRITICAL_JOURNAL_CORRUPTION:INVALID_CHECKPOINT");
    }
    if (options.checkpoint.headHash !== head || options.checkpoint.ordinal !== deeds.length) {
      throw new Error("CRITICAL_JOURNAL_CORRUPTION:CHECKPOINT_MISMATCH");
    }
    checkpointVerified = true;
  }

  const openPreparedCount = state.preparedByDeedId.size;
  return {
    state,
    report: {
      integrityValid: true,
      deedCount: deeds.length,
      preparedCount,
      closedCount,
      openPreparedCount,
      lastOrdinal: deeds.length === 0 ? 0 : deeds[deeds.length - 1].ordinal,
      headHash: head,
      checkpointProvided: Boolean(options.checkpoint),
      checkpointVerified,
      closureComplete: openPreparedCount === 0,
    },
  };
}

# Threat Model and Security Claims

Status: v0.1 reference kernel.

## Trusted Computing Base

The v0.1 TCB includes:

- FC kernel core
- active policies
- trusted issuer registry `K_T`
- fiduciary runtime clock `t_F`
- Ed25519 journal sealer key
- HMAC capability secret
- crash-durable storage, host OS and Node.js runtime
- integrity of the enforcement path
- any upstream evidence verifier \(\mathcal V_E\) that produces pre-verified admission-evidence references consumed by the Gateway

Out of scope:

- host OS or Node.js process compromise
- private-key extraction
- hardware or memory corruption
- side-channel attacks
- target systems with bypass paths outside FC mediation
- concurrent writers to the same lineage journal
- forged evidence already accepted by \(\mathcal V_E\) (outside Gateway claim; ADV-04 covers malformed/self-trusted input only)

## Constitutional Rules

```text
No ADMIT, no capability.
No valid unconsumed capability, no protected execution.
No protected execution begins before durable PREPARED commitment.
Every PREPARED execution is closed as SUCCESS, NO_EFFECT, or UNKNOWN after successful reconciliation.
```

## ADV Suite

| ID | Vector | Expected result |
| --- | --- | --- |
| ADV-01 | Policy bypass / over-limit proposal | REJECT |
| ADV-02 | Capability replay after restart | REJECT |
| ADV-03 | Lineage tampering or corruption | FAIL_CLOSED |
| ADV-04A | Malformed admission-evidence material | INVALID_PAYLOAD / reject |
| ADV-04B | Self-trusted admission-evidence material | Projected/ignored; no fiduciary effect |
| ADV-05 | Missing or ambiguous policy | REJECT |
| ADV-06 | Forged authority from unknown issuer | REJECT |
| ADV-07 | Future or expired authority claim | REJECT |
| ADV-08 | Admission binding attack | THROW/REJECT |
| ADV-09 | Multiple capabilities from one admission | REJECT second execution |

ADV-09 is included as hardening discovered after the canonical ADV-08 set: one admission must not fan out into multiple protected executions.

## Metrics

Kernel metrics:

```text
ASR = adversarial attempts that produce protected consequence / adversarial attempts
UCR = protected executions without valid ADMIT / protected executions
AD  = identical canonical inputs with identical AdmissionDecision / repeated identical evaluations
ELC = protected execution attempts with durable PREPARED lineage / protected execution attempts
FCC = PREPARED deeds with closure / PREPARED deeds
```

Deployment metric:

```text
BR = protected actions executed outside FC / total protected actions
```

`BR` is not a kernel property. It depends on network topology, credentials, application routing and whether the protected tool can be reached outside the gateway.

## Journal Conformance Gates

The journal must pass these gates before a conformant `v0.1.0` tag:

- hash integrity
- Ed25519 authenticity
- transition validity for `EXECUTION_PREPARED -> OUTCOME_*`
- admission at-most-once
- crash recovery and idempotent reconciliation
- checkpoint verification
- RFC 8785 value conformance

## Core Limitation

FC does not infer safety intent absent explicit fiduciary policy. Its strength is bounded by the correctness and expressiveness of configured policy.

```text
FC enforcement strength <= expressiveness and correctness of policy
```

## Offline Verification Levels

Structural verification checks DFD hashes, Ed25519 signatures, chain continuity and checkpoint relation.

Admission replay verification additionally requires proposal, policies, claims, public keys, evidences, admission records, DFDs and checkpoints. A later portable bundle should contain all of these artifacts.

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

pnpm benchmark:q1 -- --profile candidate `
  --samples 5 `
  --warmup-core 1 `
  --warmup-b5 1 `
  --warmup-b6 1 `
  --lineage-sizes 10,100 `
  --output benchmarks/q1-performance/results/pilot-lab

Write-Host ""
Write-Host "Pilot finished. Inspect benchmarks/q1-performance/results/pilot-lab/summary.json"
Write-Host "Pilots are not publication evidence."

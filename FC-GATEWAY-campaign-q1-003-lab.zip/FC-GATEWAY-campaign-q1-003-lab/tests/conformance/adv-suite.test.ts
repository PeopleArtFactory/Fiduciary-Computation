import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import {
  FiduciaryExecutor,
  FiduciaryGateway,
  FiduciaryJournal,
  generateEd25519KeyPair,
  issueCapabilityToken,
  normalizeProposal,
  signAuthorityClaim,
  tryIssueCapabilityToken,
  verifyLineage,
} from "../../src/index.js";
import { cleanupFixture, createConformanceFixture, FIXED_CLOCK, HMAC_SECRET } from "./fixtures.js";
import { createInstrumentedTool } from "./instrumentation.js";
import { buildK9Metrics } from "./metrics.js";

test("K9 adversarial suite: positive control + ADV-01..09", async () => {
  const f = createConformanceFixture();
  const consequenceBreaches = new Set<string>();
  const consequenceCases: string[] = [];
  const integrityCases: string[] = [];
  const integrityFailures: string[] = [];

  const markAttempt = (id: string) => {
    consequenceCases.push(id);
    f.counters.attackAttempts += 1;
  };
  const markBreach = (id: string, unsanctionedBefore: number) => {
    if (f.counters.unsanctionedEffects > unsanctionedBefore) {
      consequenceBreaches.add(id.split(".")[0] ?? id);
    }
  };

  try {
    // Positive control
    const decision = f.gateway.evaluate(f.proposal, [f.claim], [f.evidence]);
    assert.equal(decision.result, "ADMIT");
    const capability = issueCapabilityToken(decision, f.proposal, {
      issuer: "fc-gateway",
      audience: "fiduciary-executor",
      fiduciaryClock: FIXED_CLOCK,
      hmacSecret: HMAC_SECRET,
    });
    const result = await f.executor.executeConsequence(f.proposal, decision, capability, FIXED_CLOCK + 100, f.authorizedTool);
    assert.equal(result.success, true);
    assert.equal(result.outcomeDeed.phase, "OUTCOME_SUCCESS");
    assert.equal(f.counters.authorizedEffects, 1);
    assert.equal(f.counters.unsanctionedEffects, 0);
    const lineage = verifyLineage(f.journal.readAllDeeds(), { sealerPublicKeyPem: f.sealerKeys.publicKeyPem });
    assert.equal(lineage.report.openPreparedCount, 0);
    const positiveControlPassed = true;

    // ADV-01 policy bypass
    {
      markAttempt("ADV-01");
      const before = f.counters.unsanctionedEffects;
      const over = normalizeProposal({ ...f.rawProposal, parameters: { amount: 1_000_000 } });
      const d = f.gateway.evaluate(over, [f.claim], [f.evidence]);
      assert.equal(d.result, "REJECT");
      assert.equal(tryIssueCapabilityToken(d, over, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: FIXED_CLOCK, hmacSecret: HMAC_SECRET }), null);
      markBreach("ADV-01", before);
    }

    // ADV-02 replay after restart
    {
      markAttempt("ADV-02");
      const before = f.counters.unsanctionedEffects;
      const d = f.gateway.evaluate(f.proposal, [f.claim], [f.evidence]);
      // use fresh journal path for isolated replay case
      const replayDir = path.join(f.dir, "replay");
      fs.mkdirSync(replayDir);
      const journal = new FiduciaryJournal(f.sealer, replayDir);
      const executor = new FiduciaryExecutor(HMAC_SECRET, journal);
      const cap = issueCapabilityToken(d, f.proposal, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: FIXED_CLOCK, hmacSecret: HMAC_SECRET });
      await executor.executeConsequence(f.proposal, d, cap, FIXED_CLOCK + 100, createInstrumentedTool(f.counters, "authorized"));
      const reloaded = new FiduciaryJournal(f.sealer, replayDir);
      const reExec = new FiduciaryExecutor(HMAC_SECRET, reloaded);
      await assert.rejects(() => reExec.executeConsequence(f.proposal, d, cap, FIXED_CLOCK + 200, createInstrumentedTool(f.counters, "adversarial")));
      markBreach("ADV-02", before);
    }

    // ADV-04A malformed / ADV-04B self-classification
    {
      markAttempt("ADV-04A");
      const beforeA = f.counters.unsanctionedEffects;
      assert.throws(() => normalizeProposal({ ...f.rawProposal, parameters: { amount: Number.NaN } }));
      markBreach("ADV-04A", beforeA);

      markAttempt("ADV-04B");
      const beforeB = f.counters.unsanctionedEffects;
      const projected = normalizeProposal({ ...f.rawProposal, parameters: { amount: 1_000_000 }, riskLevel: 0, consequenceClass: "READ", overrideAdmission: true });
      assert.equal("riskLevel" in projected, false);
      assert.equal(f.gateway.evaluate(projected, [f.claim], [f.evidence]).result, "REJECT");
      markBreach("ADV-04B", beforeB);
    }

    // ADV-05 policy substitution
    {
      markAttempt("ADV-05");
      const before = f.counters.unsanctionedEffects;
      const policies = [f.policy];
      const gateway = new FiduciaryGateway({
        policies,
        trustedIssuers: f.trustedIssuers,
        hmacSecret: HMAC_SECRET,
        journal: new FiduciaryJournal(f.sealer, path.join(f.dir, "adv05")),
        now: () => FIXED_CLOCK,
      });
      policies.push({ ...f.policy, policyId: "attacker", constraints: [], requiredAuthorityPermits: [], requiredEvidenceTypes: [] });
      const over = normalizeProposal({ ...f.rawProposal, parameters: { amount: 999_999 } });
      assert.equal(gateway.evaluate(over, [f.claim], [f.evidence]).result, "REJECT");
      markBreach("ADV-05", before);
    }

    // ADV-06 forged-but-authentic authority
    {
      markAttempt("ADV-06");
      const before = f.counters.unsanctionedEffects;
      const attacker = generateEd25519KeyPair();
      const forged = signAuthorityClaim(
        {
          claimId: "forged",
          issuer: "authority:attacker",
          subject: f.proposal.actor.id,
          permits: ["TRANSFER_APPROVE"],
          issuedAt: 1_000,
          expiresAt: 5_000,
          nonce: "x",
        },
        attacker.privateKeyPem,
      );
      assert.equal(f.gateway.evaluate(f.proposal, [forged], [f.evidence]).result, "REJECT");
      markBreach("ADV-06", before);
    }

    // ADV-07A/B temporal authority claims
    {
      markAttempt("ADV-07A");
      const beforeA = f.counters.unsanctionedEffects;
      const future = signAuthorityClaim(
        {
          claimId: "future",
          issuer: "authority:finance-root",
          subject: f.proposal.actor.id,
          permits: ["TRANSFER_APPROVE"],
          issuedAt: 3_000,
          expiresAt: 5_000,
          nonce: "f",
        },
        f.auth.privateKeyPem,
      );
      assert.equal(f.gateway.evaluate(f.proposal, [future], [f.evidence]).result, "REJECT");
      markBreach("ADV-07A", beforeA);

      markAttempt("ADV-07B");
      const beforeB = f.counters.unsanctionedEffects;
      const expired = signAuthorityClaim(
        {
          claimId: "expired",
          issuer: "authority:finance-root",
          subject: f.proposal.actor.id,
          permits: ["TRANSFER_APPROVE"],
          issuedAt: 1_000,
          expiresAt: 1_500,
          nonce: "e",
        },
        f.auth.privateKeyPem,
      );
      assert.equal(f.gateway.evaluate(f.proposal, [expired], [f.evidence]).result, "REJECT");
      markBreach("ADV-07B", beforeB);
    }

    // ADV-08 admission binding
    {
      markAttempt("ADV-08");
      const before = f.counters.unsanctionedEffects;
      const dA = f.gateway.evaluate(f.proposal, [f.claim], [f.evidence]);
      const capA = issueCapabilityToken(dA, f.proposal, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: FIXED_CLOCK, hmacSecret: HMAC_SECRET });
      const proposalB = normalizeProposal({ ...f.rawProposal, proposalId: "prop_b", parameters: { amount: 2_000 } });
      const journal = new FiduciaryJournal(f.sealer, path.join(f.dir, "adv08"));
      const executor = new FiduciaryExecutor(HMAC_SECRET, journal);
      await assert.rejects(() => executor.executeConsequence(proposalB, dA, capA, FIXED_CLOCK + 100, createInstrumentedTool(f.counters, "adversarial")));
      markBreach("ADV-08", before);
    }

    // ADV-09 multiple capabilities / one admission
    {
      markAttempt("ADV-09");
      const before = f.counters.unsanctionedEffects;
      const d = f.gateway.evaluate(f.proposal, [f.claim], [f.evidence]);
      const journal = new FiduciaryJournal(f.sealer, path.join(f.dir, "adv09"));
      const executor = new FiduciaryExecutor(HMAC_SECRET, journal);
      const a1 = issueCapabilityToken(d, f.proposal, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: FIXED_CLOCK, hmacSecret: HMAC_SECRET });
      const a2 = issueCapabilityToken(d, f.proposal, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: FIXED_CLOCK + 1, hmacSecret: HMAC_SECRET });
      await executor.executeConsequence(f.proposal, d, a1, FIXED_CLOCK + 100, createInstrumentedTool(f.counters, "authorized"));
      await assert.rejects(() => executor.executeConsequence(f.proposal, d, a2, FIXED_CLOCK + 200, createInstrumentedTool(f.counters, "adversarial")));
      markBreach("ADV-09", before);
    }

    // ADV-03 integrity family (not in ASR)
    {
      const d = f.gateway.evaluate(f.proposal, [f.claim], [f.evidence]);
      const journal = new FiduciaryJournal(f.sealer, path.join(f.dir, "adv03"));
      const executor = new FiduciaryExecutor(HMAC_SECRET, journal);
      const cap = issueCapabilityToken(d, f.proposal, { issuer: "fc-gateway", audience: "fiduciary-executor", fiduciaryClock: FIXED_CLOCK, hmacSecret: HMAC_SECRET });
      await executor.executeConsequence(f.proposal, d, cap, FIXED_CLOCK + 100, createInstrumentedTool(f.counters, "authorized"));
      const deeds = journal.readAllDeeds();

      integrityCases.push("ADV-03A", "ADV-03B", "ADV-03C", "ADV-03D");

      const mutated = structuredClone(deeds);
      mutated[1].phase = "OUTCOME_NO_EFFECT";
      try {
        verifyLineage(mutated, { sealerPublicKeyPem: f.sealerKeys.publicKeyPem });
        integrityFailures.push("ADV-03A");
      } catch {
        /* expected */
      }

      const deleted = [deeds[0], deeds[1]].filter((_, i) => i !== 0);
      // middle deletion: keep only outcome-ish by removing prepared - use deeds without first
      const middleDeleted = [deeds[1]];
      try {
        verifyLineage(middleDeleted, { sealerPublicKeyPem: f.sealerKeys.publicKeyPem });
        integrityFailures.push("ADV-03B");
      } catch {
        /* expected */
      }
      void deleted;

      const reordered = [deeds[1], deeds[0]];
      try {
        verifyLineage(reordered, { sealerPublicKeyPem: f.sealerKeys.publicKeyPem });
        integrityFailures.push("ADV-03C");
      } catch {
        /* expected */
      }

      const checkpoint = journal.generateCheckpoint(FIXED_CLOCK + 500);
      const truncated = deeds.slice(0, -1);
      try {
        verifyLineage(truncated, {
          sealerPublicKeyPem: f.sealerKeys.publicKeyPem,
          checkpoint,
          trustedIssuersForCheckpoint: [{ issuerId: f.sealer.issuerKeyId, publicKeyPem: f.sealerKeys.publicKeyPem }],
        });
        integrityFailures.push("ADV-03D");
      } catch {
        /* expected */
      }
    }

    const vectorIds = ["ADV-01", "ADV-02", "ADV-04", "ADV-05", "ADV-06", "ADV-07", "ADV-08", "ADV-09"];
    const metrics = buildK9Metrics({
      positiveControlPassed,
      consequenceCases: consequenceCases.length,
      consequenceBreaches: consequenceBreaches.size,
      consequenceVectors: vectorIds.length,
      compromisedVectors: vectorIds.filter((id) => consequenceBreaches.has(id)).length,
      integrityCases: integrityCases.length,
      integrityFailures: integrityFailures.length,
      externalEffects: f.counters.externalEffects,
      authorizedEffects: f.counters.authorizedEffects,
      unsanctionedEffects: f.counters.unsanctionedEffects,
    });

    assert.equal(metrics.positiveControlPassed, true);
    assert.equal(metrics.unsanctionedEffects, 0);
    assert.equal(metrics.asrCase.value, 0);
    assert.equal(metrics.asrVector.value, 0);
    assert.equal(metrics.ucr.value, 0);
    assert.ok((metrics.asrCase.denominator ?? 0) > 0);
    assert.ok((metrics.ucr.denominator ?? 0) > 0);
    assert.equal(metrics.integrityFailures, 0);

    const artifactsDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../artifacts");
    fs.mkdirSync(artifactsDir, { recursive: true });
    fs.writeFileSync(
      path.join(artifactsDir, "K9_ADVERSARIAL.json"),
      JSON.stringify(
        {
          schema: "FCG-K9-ADVERSARIAL-0.1",
          kernelVersion: "0.1.0",
          sourceRevision: "local",
          generatedAt: new Date().toISOString(),
          ...metrics,
        },
        null,
        2,
      ),
    );
  } finally {
    cleanupFixture(f);
  }
});

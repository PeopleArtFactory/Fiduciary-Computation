import { verifyLineage } from "../../../dist/src/index.js";
import { measure, type BenchmarkSample } from "./statistics.js";
import type { LineageFixture } from "./lineage-fixtures.js";

export interface B5Result {
  lineageSize: number;
  samples: BenchmarkSample[];
}

export async function runB5(
  fixtures: readonly LineageFixture[],
  iterations: number,
  warmup: number,
): Promise<B5Result[]> {
  const results: B5Result[] = [];
  for (const fixture of fixtures) {
    for (let i = 0; i < warmup; i++) {
      const result = verifyLineage(fixture.deeds, {
        sealerPublicKeyPem: fixture.sealerPublicKeyPem,
        sealerIssuer: fixture.sealerIssuer,
        sealerIssuerKeyId: fixture.sealerIssuerKeyId,
      });
      if (
        !result.report.integrityValid ||
        !result.report.closureComplete ||
        result.report.deedCount !== fixture.size
      ) {
        throw new Error(`INVALID_MEASUREMENT: B5 warmup invariant failed for N=${fixture.size}`);
      }
    }

    const samples: BenchmarkSample[] = [];
    for (let i = 0; i < iterations; i++) {
      let report: ReturnType<typeof verifyLineage>["report"] | undefined;
      const sample = await measure("B5", i, () => {
        const result = verifyLineage(fixture.deeds, {
          sealerPublicKeyPem: fixture.sealerPublicKeyPem,
          sealerIssuer: fixture.sealerIssuer,
          sealerIssuerKeyId: fixture.sealerIssuerKeyId,
        });
        report = result.report;
      }, { lineageSize: fixture.size });
      if (!sample.success) throw new Error(`INVALID_MEASUREMENT: B5 failed N=${fixture.size}, i=${i}`);
      if (
        !report ||
        !report.integrityValid ||
        !report.closureComplete ||
        report.deedCount !== fixture.size
      ) {
        throw new Error(`INVALID_MEASUREMENT: B5 verification invariant failed for N=${fixture.size}`);
      }
      samples.push(sample);
    }
    results.push({ lineageSize: fixture.size, samples });
  }
  return results;
}

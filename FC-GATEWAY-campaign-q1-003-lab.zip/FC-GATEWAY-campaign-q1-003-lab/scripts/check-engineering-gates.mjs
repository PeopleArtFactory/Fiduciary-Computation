#!/usr/bin/env node
import * as fs from "node:fs";
import * as path from "node:path";

const args = parseArgs(process.argv.slice(2));
const packagePath = path.resolve(args.package ?? "package.json");
const distRoot = path.resolve(args.dist ?? "dist/src");
const outputPath = path.resolve(args.output ?? "artifacts/K11_ENGINEERING_GATES.json");

try {
  if (!fs.existsSync(packagePath)) throw new Error("MISSING_PACKAGE_JSON");
  const pkg = JSON.parse(fs.readFileSync(packagePath, "utf8"));
  const names = [
    ...Object.keys(pkg.dependencies ?? {}),
    ...Object.keys(pkg.optionalDependencies ?? {}),
    ...Object.keys(pkg.peerDependencies ?? {}),
    ...Object.keys(pkg.bundledDependencies ?? pkg.bundleDependencies ?? {}),
  ];
  const runtimeCount = names.length;
  const runtimeStatus = runtimeCount === 0 ? "PASS" : "FAIL";

  if (!fs.existsSync(distRoot)) throw new Error("MISSING_DIST_ROOT");
  const bytes = measureBytes(distRoot);
  const distributableStatus = bytes < 1_400_000 ? "PASS" : "FAIL";

  const result = runtimeStatus === "PASS" && distributableStatus === "PASS" ? "PASS" : "FAIL";
  const artifact = {
    schema: "FCG-ENGINEERING-GATES-0.1",
    kernelVersion: pkg.version ?? "0.1.0",
    sourceRevision: "local",
    runtimeDependencies: {
      count: runtimeCount,
      names,
      target: 0,
      status: runtimeStatus,
    },
    distributable: {
      root: path.relative(process.cwd(), distRoot).replace(/\\/g, "/") || ".",
      bytes,
      limitBytes: 1_400_000,
      constraint: "<",
      status: distributableStatus,
    },
    result,
    generatedAt: new Date().toISOString(),
  };

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(artifact, null, 2));
  process.exit(result === "PASS" ? 0 : 1);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  console.error(message);
  process.exit(2);
}

function measureBytes(root) {
  let total = 0;
  const stack = [root];
  while (stack.length) {
    const current = stack.pop();
    const st = fs.lstatSync(current);
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) {
      for (const entry of fs.readdirSync(current)) stack.push(path.join(current, entry));
      continue;
    }
    if (st.isFile()) total += st.size;
  }
  return total;
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    if (!argv[i].startsWith("--")) continue;
    out[argv[i].slice(2)] = argv[i + 1];
    i += 1;
  }
  return out;
}

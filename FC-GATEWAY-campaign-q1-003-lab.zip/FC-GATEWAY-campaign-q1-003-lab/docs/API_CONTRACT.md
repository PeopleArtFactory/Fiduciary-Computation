# MVP API Contract

This file preserves the small HTTP surface proposed in the conversation. The reference kernel currently exposes TypeScript classes; an HTTP daemon should wrap these operations without changing kernel semantics.

## Endpoints

```text
POST /admit
POST /execute
GET  /verify/:dfd
GET  /lineage/:id
```

## `POST /admit`

Input: untrusted proposal plus optional claims/evidence references. The daemon must normalize the proposal, discard non-fiduciary top-level fields, reject malformed required fields, and evaluate against trusted configuration only.

Admission evidence is **pre-verified** by an upstream verifier \(\mathcal V_E\) outside the Gateway:

```text
E_raw  --V_E-->  E_adm  --Pi_F-->  D
```

The Gateway binds `PreverifiedEvidenceRef` / historical `VerifiedEvidenceRef` into the admission context; it does not authenticate raw evidence artifacts or operate as an evidence PKI.

Response:

```json
{
  "result": "ADMIT",
  "admissionId": "adm_...",
  "admissionHash": "...",
  "reasons": ["POLICY_REQUIREMENTS_SATISFIED"]
}
```

No caller-supplied policy set is accepted in production. The HTTP boundary should call `gateway.evaluate(proposal, claims, evidence)` where policies, trust store and clock are owned by the gateway.

## `POST /execute`

Input: proposal, admission decision, and operation adapter reference. Execution must follow:

```text
validate Proposal <-> Admission
validate Admission integrity
validate ADMIT
mint/validate Capability
reserve admissionHash + tokenId
append EXECUTION_PREPARED + fsync
run operation adapter
append OUTCOME_SUCCESS | OUTCOME_NO_EFFECT | OUTCOME_UNKNOWN + fsync
```

`OUTCOME_NO_EFFECT` may be emitted only when the adapter can prove the external effect did not occur. Timeouts, disconnections and crashes resolve to `OUTCOME_UNKNOWN`.

## `GET /verify/:dfd`

Verifies a DFD or lineage fragment structurally:

- canonical hash identity
- Ed25519 signature
- chain continuity
- checkpoint relation when supplied

This is structural verification, not full admission replay.

## `GET /lineage/:id`

Returns the local lineage around a proposal, admission, capability token or DFD id.

## Initial Config Artifacts

The first daemon should be configured by simple local files:

```text
policy.yaml
authority.json
dfd.json / lineage.ndjson
```

Example policy idea from the conversation:

```yaml
action: email.send_external
rules:
  - recipient_domain: company.com
    admission: autonomous

  - recipient_domain: "*"
    requires:
      - human_approval

  - attachment_classification: confidential
    admission: reject
```

The TypeScript kernel deliberately keeps policies as canonical data. A later YAML parser must compile this shape into `FiduciaryPolicy` objects without embedding arbitrary executable policy functions.

import test from "node:test";
import assert from "node:assert/strict";
import { fork } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { DFDSealer, FiduciaryJournal, verifyLineage } from "../../src/index.js";
import { buildCrashRuntime, prepareCrashBundle, writeCrashFixture } from "./crash-fixture.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const worker = path.resolve(here, "../workers/crash-inside-execution.js");

test("K10 CP-05 crash inside handler → PREPARED then UNKNOWN recovery + idempotence", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k10-"));
  try {
    const bundle = await prepareCrashBundle(dir);
    buildCrashRuntime(bundle);
    const fixturePath = writeCrashFixture(bundle);

    const child = fork(worker, [fixturePath], { stdio: ["pipe", "pipe", "pipe", "ipc"] });
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("timeout waiting for EXTERNAL_HANDLER_ENTERED")), 10_000);
      child.on("message", (msg: { type?: string }) => {
        if (msg?.type === "EXTERNAL_HANDLER_ENTERED") {
          clearTimeout(timer);
          resolve();
        }
      });
      child.on("error", reject);
    });

    const deedsBefore = fs
      .readFileSync(path.join(dir, "lineage.ndjson"), "utf8")
      .split(/\r?\n/)
      .filter(Boolean)
      .map((line) => JSON.parse(line));
    const reportBefore = verifyLineage(deedsBefore, { sealerPublicKeyPem: bundle.sealerPublicKeyPem }).report;
    assert.equal(reportBefore.preparedCount, 1);
    assert.equal(reportBefore.closedCount, 0);
    assert.equal(reportBefore.openPreparedCount, 1);

    child.kill("SIGKILL");
    await new Promise<void>((resolve) => child.on("exit", () => resolve()));

    const deedsAfterCrash = fs
      .readFileSync(path.join(dir, "lineage.ndjson"), "utf8")
      .split(/\r?\n/)
      .filter(Boolean)
      .map((line) => JSON.parse(line));
    const reportCrash = verifyLineage(deedsAfterCrash, { sealerPublicKeyPem: bundle.sealerPublicKeyPem }).report;
    assert.equal(reportCrash.openPreparedCount, 1);
    assert.equal(reportCrash.closureComplete, false);

    const runtime1 = buildCrashRuntime(bundle);
    assert.equal(runtime1.journal.reconcileStartupState(bundle.fiduciaryClock + 1_000), 1);
    const reportRecovered = verifyLineage(runtime1.journal.readAllDeeds(), { sealerPublicKeyPem: bundle.sealerPublicKeyPem }).report;
    assert.equal(reportRecovered.openPreparedCount, 0);
    assert.equal(reportRecovered.closedCount, 1);
    assert.equal(reportRecovered.closureComplete, true);

    const runtime2 = new FiduciaryJournal(
      new DFDSealer(bundle.sealerIssuer, bundle.sealerIssuerKeyId, bundle.sealerPublicKeyPem, bundle.sealerPrivateKeyPem),
      dir,
    );
    assert.equal(runtime2.reconcileStartupState(bundle.fiduciaryClock + 2_000), 0);
    assert.equal(runtime2.readAllDeeds().length, 2);

    const artifactsDir = path.resolve(here, "../../../artifacts");
    fs.mkdirSync(artifactsDir, { recursive: true });
    fs.writeFileSync(
      path.join(artifactsDir, "K10_CRASH_RECOVERY.json"),
      JSON.stringify(
        {
          schema: "FCG-K10-CRASH-0.1",
          kernelVersion: "0.1.0",
          sourceRevision: "local",
          generatedAt: new Date().toISOString(),
          externalHandlerEntries: 1,
          handlerEntriesWithPrepared: 1,
          preparedRecordsAfterRecovery: 1,
          correctlyClosedPrepared: 1,
          crashRecoveryPassed: true,
          reconciliationIdempotent: true,
          elc: { numerator: 1, denominator: 1, value: 1, target: 1, status: "PASS" },
          fcc: { numerator: 1, denominator: 1, value: 1, target: 1, status: "PASS" },
        },
        null,
        2,
      ),
    );
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

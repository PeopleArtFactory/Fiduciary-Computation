#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== FC Gateway lab bootstrap =="
command -v node >/dev/null || { echo "ERROR: node required"; exit 1; }
command -v git >/dev/null || { echo "ERROR: git required"; exit 1; }

if ! command -v pnpm >/dev/null; then
  if command -v corepack >/dev/null; then
    corepack enable
    corepack prepare pnpm@10.0.0 --activate
  else
    echo "ERROR: pnpm not found; install pnpm 10 or enable corepack"
    exit 1
  fi
fi

echo "node: $(node -v)"
echo "pnpm: $(pnpm -v)"
if [ "$(pnpm -v)" != "10.0.0" ]; then
  echo "ERROR: campaign-q1-003 requires pnpm 10.0.0 exactly"
  exit 1
fi

pnpm install --frozen-lockfile

echo "typescript: $(node -p "require('./node_modules/typescript/package.json').version")"
echo "@types/node: $(node -p "require('./node_modules/@types/node/package.json').version")"

if [ ! -d .git ]; then
  git init
  git add -A
  git -c user.email="lab@fc-gateway.local" -c user.name="FC Gateway Lab" commit -m "lab: bootstrap campaign-q1-003 pack"
  echo "Created local git commit for clean-tree gate."
else
  if [ -n "$(git status --porcelain -- src tests package.json tsconfig.json benchmarks/q1-performance)" ]; then
    echo "WARNING: monitored tree is dirty. Commit before a VALID campaign."
    git status --porcelain -- src tests package.json tsconfig.json benchmarks/q1-performance | head
  else
    echo "Monitored tree is clean."
  fi
fi

pnpm build
pnpm test

echo
echo "Bootstrap OK. Next: ./lab/01-pilot.sh  then  ./lab/02-campaign-q1-003.sh"
echo "HEAD=$(git rev-parse HEAD)"

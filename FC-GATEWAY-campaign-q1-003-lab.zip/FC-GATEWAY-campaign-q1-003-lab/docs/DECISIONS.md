# v0.1 Decisions And Non-Goals

This file captures useful decisions from the conversation so they are not reopened accidentally during implementation.

## Frozen Decisions

- The kernel is model-agnostic. No LLM is embedded in core.
- A proposer can be an AI, human, sensor, script, rules engine or workflow.
- `Proposal` is the universal input. It is not called prompt, message or AI output.
- Policies are data only. No `PolicyRule.evaluate()` functions in canonical policy.
- Trusted issuers are canonical arrays of `{ issuerId, publicKeyPem }`, not Map/Set in the fiduciary input domain.
- HMAC-SHA256 is used for runtime-local capability tokens.
- Ed25519 is used for AuthorityClaim, DFD and checkpoints.
- Capability HMACs, durable lineage signatures and checkpoint signatures are domain-separated.
- `admissionHash` and `proposalHash` must remain explicit in `CapabilityToken`.
- `CapabilityToken` must include `issuer`, `audience`, `scope`, `nonce`, and `mac`; it is not a public signature artifact.
- Durable DFD lineage must include `proposalHash`, `admissionHash`, the token id and a fixed genesis previous hash.
- The journal reserves both `tokenId` and `admissionHash`, preventing multiple capabilities from one admission from executing twice.
- `EXECUTION_PREPARED` is the durable causal precondition before protected execution begins.
- `OUTCOME_UNKNOWN` is a legitimate fiduciary state, not a bug to hide.
- `OUTCOME_NO_EFFECT` requires proof that no external effect occurred.
- Checkpoints are separate artifacts; signatures are not embedded as optional fields in every record.
- RFC 8785 compliance is a release gate, not a claim until conformance vectors pass.
- Each lineage journal has exactly one active writer process in v0.1; multiwriter coordination is out of scope.

## Cryptographic Protocol Freeze (v0.1.0)

These constructions are normative for FC Gateway v0.1. Changing them requires a new protocol version.

### Canonical identity

```text
H(X) = SHA-256( UTF8( JCS(X) ) )
```

`JCS` is the productive canonicalizer in `src/dfd/canonicalize.ts`.

### Ed25519 signatures (AuthorityClaim, Checkpoint, Lineage DFD)

v0.1 signs the UTF-8 encoding of a domain-wrapped canonical JSON object. There is **no SHA-256 prehash** inside the signature message:

```text
M = UTF8( JCS({ domain: D, ...payloadFields }) )
σ = Ed25519.Sign(sk, M)
Ed25519.Verify(pk, M, σ)
```

Domain constants:

- AuthorityClaim: `FCG:v0.1:AUTHORITY_CLAIM`
- Lineage DFD: `FCG:v0.1:LINEAGE`
- Checkpoint: `FCG:v0.1:CHECKPOINT`

A future `Domain || JCS(payload)` raw-concatenation format, or `Domain || SHA-256(JCS(payload))`, would be a new protocol version, not an internal refactor.

### Capability MAC

```text
MAC = HMAC-SHA256(
  Kc,
  UTF8(D) || 0x00 || UTF8( JCS(CapabilityToken - { mac }) )
)
```

with `D = FCG:v0.1:CAPABILITY` and `|Kc| >= 32` bytes.

### Genesis

Empty lineage predecessor hash is the frozen constant `FCG_GENESIS_HASH` in `src/core/constants.ts`.

## Non-Goals For v0.1

- No blockchain.
- No Merkle tree requirement.
- No distributed consensus.
- No mandatory database.
- No cloud dependency.
- No HSM/KMS dependency.
- No universal semantic safety inference.
- No promise that FC protects channels that bypass the gateway.
- No claim that a thrown exception proves absence of external effect.

## Release Gates

```text
ADV-01..ADV-09 = PASS
ASR = 0
UCR = 0
AD = 1
ELC = 1
FCC = 1
runtime dependencies = 0
RFC 8785 conformance vectors = 100 percent
real distributable size < 1.4 MB
```

## First Market

Start with agents that already have write capability:

- email sending
- CRM/ERP changes
- file creation/deletion
- GitHub agents
- SQL execution
- cloud operations
- purchase workflows
- low-value financial simulations

Do not start with nuclear plants, hospitals or national infrastructure. The first demo should be understandable in five minutes.

import { DOMAIN_LINEAGE } from "../core/constants.js";
import { hashJson, isHash256 } from "../crypto/hash.js";
import { isEd25519SignatureHex } from "../crypto/encoding.js";
import { signCanonical, signCheckpoint as signSignedCheckpoint, verifyCanonical, verifyCheckpoint as verifySignedCheckpoint } from "../crypto/signatures.js";
import type { DFDDeed, Hash256, JsonValue, LineageCheckpoint, TrustedIssuer, UnsignedDFDDeed } from "../core/types.js";

export interface DeedDraft {
  phase: DFDDeed["phase"];
  tokenId: string;
  admissionHash: Hash256;
  proposalHash: Hash256;
  actor: DFDDeed["actor"];
  action: string;
  target?: string;
  outcomeHash?: Hash256;
  errorCode?: string;
  preparedDeedId?: string;
  preparedDfdHash?: Hash256;
  timestamp: number;
}

export class DFDSealer {
  constructor(
    public readonly issuer: string,
    public readonly issuerKeyId: string,
    public readonly publicKeyPem: string,
    private readonly privateKeyPem?: string,
  ) {}

  public sealDeed(draft: DeedDraft, ordinal: number, prevDfdHash: Hash256): DFDDeed {
    if (!this.privateKeyPem) throw new Error("MISSING_DFD_PRIVATE_KEY");
    if (!isHash256(prevDfdHash)) throw new Error("MALFORMED_PREV_DFD_HASH");
    const unsigned: UnsignedDFDDeed = {
      dfdVersion: "0.1",
      ordinal,
      deedId: `dfd_${ordinal}_${hashJson({ ordinal, phase: draft.phase, tokenId: draft.tokenId, timestamp: draft.timestamp } as JsonValue).slice(0, 16)}`,
      phase: draft.phase,
      tokenId: draft.tokenId,
      admissionHash: draft.admissionHash,
      proposalHash: draft.proposalHash,
      actor: draft.actor,
      action: draft.action,
      ...(draft.target ? { target: draft.target } : {}),
      ...(draft.outcomeHash ? { outcomeHash: draft.outcomeHash } : {}),
      ...(draft.errorCode ? { errorCode: draft.errorCode } : {}),
      ...(draft.preparedDeedId ? { preparedDeedId: draft.preparedDeedId } : {}),
      ...(draft.preparedDfdHash ? { preparedDfdHash: draft.preparedDfdHash } : {}),
      timestamp: draft.timestamp,
      prevDfdHash,
      issuer: this.issuer,
      issuerKeyId: this.issuerKeyId,
    };
    const dfdHash = hashJson(unsigned as unknown as JsonValue);
    const signature = signCanonical({ domain: DOMAIN_LINEAGE, dfdHash }, this.privateKeyPem);
    return { ...unsigned, dfdHash, signature };
  }

  public verifyDeed(deed: DFDDeed): boolean {
    if (!isEd25519SignatureHex(deed.signature)) return false;
    const { dfdHash, signature: _signature, ...unsigned } = deed;
    if (hashJson(unsigned as unknown as JsonValue) !== dfdHash) return false;
    try {
      return verifyCanonical({ domain: DOMAIN_LINEAGE, dfdHash }, deed.signature, this.publicKeyPem);
    } catch {
      return false;
    }
  }

  public signCheckpoint(input: Omit<LineageCheckpoint, "signature">): LineageCheckpoint {
    if (!this.privateKeyPem) throw new Error("MISSING_DFD_PRIVATE_KEY");
    return signSignedCheckpoint(input, this.privateKeyPem);
  }

  public verifyCheckpoint(checkpoint: LineageCheckpoint, trustedIssuers: readonly TrustedIssuer[]) {
    return verifySignedCheckpoint(checkpoint, trustedIssuers);
  }
}

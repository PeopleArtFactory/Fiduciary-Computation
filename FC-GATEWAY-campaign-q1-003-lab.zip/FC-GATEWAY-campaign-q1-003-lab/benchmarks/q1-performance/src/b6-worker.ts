/**
 * B6 recovery worker — must run in a fresh Node process.
 * Usage: node dist/b6-worker.js <journalDir>
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { DFDSealer, FiduciaryJournal, verifyLineage } from "../../../dist/src/index.js";

const journalDir = process.argv[2];
if (!journalDir) {
  console.error("usage: b6-worker <journalDir>");
  process.exit(2);
}

const processStart = process.hrtime.bigint();
const meta = JSON.parse(fs.readFileSync(path.join(journalDir, "b6-meta.json"), "utf8")) as {
  preparedDeedId: string;
  sealer: { issuer: string; issuerKeyId: string; publicKeyPem: string; privateKeyPem: string };
  reconcileTimestamp: number;
};

const bootstrapStart = process.hrtime.bigint();
const sealer = new DFDSealer(
  meta.sealer.issuer,
  meta.sealer.issuerKeyId,
  meta.sealer.publicKeyPem,
  meta.sealer.privateKeyPem,
);
const journal = new FiduciaryJournal(sealer, journalDir);
const bootstrapEnd = process.hrtime.bigint();
// Methodological correction: no handoff epsilon between bootstrap and reconcile.
const reconcileStart = bootstrapEnd;
const closed = journal.reconcileStartupState(meta.reconcileTimestamp);
const reconcileEnd = process.hrtime.bigint();

const deeds = journal.readAllDeeds();
const verification = verifyLineage(deeds, {
  sealerPublicKeyPem: meta.sealer.publicKeyPem,
  sealerIssuer: meta.sealer.issuer,
  sealerIssuerKeyId: meta.sealer.issuerKeyId,
});
const closures = deeds.filter((d) => d.preparedDeedId === meta.preparedDeedId);
const processEnd = process.hrtime.bigint();

const payload = {
  closed,
  preparedDeedId: meta.preparedDeedId,
  closureCount: closures.length,
  integrityValid: verification.report.integrityValid,
  openPreparedCount: verification.report.openPreparedCount,
  coldProcessNs: (processEnd - processStart).toString(),
  bootstrapNs: (bootstrapEnd - bootstrapStart).toString(),
  reconcileNs: (reconcileEnd - reconcileStart).toString(),
  coreRecoveryNs: (reconcileEnd - bootstrapStart).toString(),
  // By construction: bootstrap + reconcile == coreRecovery (no handoff gap)
  identityOk:
    BigInt((bootstrapEnd - bootstrapStart).toString()) + BigInt((reconcileEnd - reconcileStart).toString()) ===
    BigInt((reconcileEnd - bootstrapStart).toString()),
};

process.stdout.write(JSON.stringify(payload));

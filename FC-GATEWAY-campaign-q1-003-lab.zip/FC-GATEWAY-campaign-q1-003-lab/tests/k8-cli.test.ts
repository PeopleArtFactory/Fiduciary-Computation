import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryExecutor,
  FiduciaryJournal,
  generateEd25519KeyPair,
  signAuthorityClaim,
} from "../src/index.js";
import type { FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");
const here = path.dirname(fileURLToPath(import.meta.url));
const cli = path.resolve(here, "../src/cli/verify.js");

function runCli(args: string[]) {
  return spawnSync(process.execPath, [cli, ...args], { encoding: "utf8" });
}

function makeJournal() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k8-"));
  const auth = generateEd25519KeyPair();
  const keys = generateEd25519KeyPair();
  const trustedIssuers: TrustedIssuer[] = [{ issuerId: "authority:finance-root", publicKeyPem: auth.publicKeyPem }];
  const actor = { type: "ai" as const, id: "a" };
  const policy: FiduciaryPolicy = {
    policyId: "p",
    version: "1",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 1,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 10 }],
    effectOnMatch: "ADMIT",
  };
  const evidence: VerifiedEvidenceRef = {
    evidenceId: "e",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1,
  };
  const proposal: Proposal = {
    proposalId: "prop",
    actor,
    action: "bank.transfer",
    parameters: { amount: 1 },
    contextRefs: [evidence.evidenceId],
    requestedAt: 1,
  };
  const claim = signAuthorityClaim(
    {
      claimId: "c",
      issuer: "authority:finance-root",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1,
      expiresAt: 9_999,
      nonce: "n",
    },
    auth.privateKeyPem,
  );
  const sealer = new DFDSealer("n", "k", keys.publicKeyPem, keys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir);
  const engine = new FiduciaryEngine();
  const executor = new FiduciaryExecutor(hmacSecret, journal);
  const decision = engine.evaluate(proposal, [policy], [claim], trustedIssuers, [evidence], 10);
  const capability = engine.mintCapability(decision, proposal, hmacSecret, 10)!;
  return { dir, keys, journal, executor, proposal, decision, capability, sealer };
}

test("K8 CLI exits 0 for valid lineage and open PREPARED", async () => {
  const f = makeJournal();
  try {
    await f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => ({ ok: true }));
    const keyPath = path.join(f.dir, "pub.pem");
    fs.writeFileSync(keyPath, f.keys.publicKeyPem);
    const closed = runCli(["--journal", f.journal.getLineagePath(), "--key", keyPath, "--format", "json"]);
    assert.equal(closed.status, 0);
    assert.match(closed.stdout, /"result": "VALID"/);
    assert.doesNotMatch(closed.stdout, /ASR|UCR|CONFORMANT/);

    const openDir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k8o-"));
    try {
      const sealer = new DFDSealer("n", "k", f.keys.publicKeyPem, f.keys.privateKeyPem);
      const journal = new FiduciaryJournal(sealer, openDir);
      journal.reserveExecution({
        tokenId: "cap_open",
        admissionHash: "b".repeat(64),
        proposalHash: "c".repeat(64),
        actor: f.proposal.actor,
        action: "email.send",
        timestamp: 1,
      });
      const key2 = path.join(openDir, "pub.pem");
      fs.writeFileSync(key2, f.keys.publicKeyPem);
      const open = runCli(["--journal", journal.getLineagePath(), "--key", key2, "--format", "human"]);
      assert.equal(open.status, 0);
      assert.match(open.stdout, /openPreparedCount: 1/);
    } finally {
      fs.rmSync(openDir, { recursive: true, force: true });
    }
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

test("K8 CLI exits 1 for tampered lineage and 2 for usage/IO", async () => {
  const f = makeJournal();
  try {
    await f.executor.executeConsequence(f.proposal, f.decision, f.capability, 20, () => ({ ok: true }));
    const keyPath = path.join(f.dir, "pub.pem");
    fs.writeFileSync(keyPath, f.keys.publicKeyPem);
    const lineage = fs.readFileSync(f.journal.getLineagePath(), "utf8").replace("OUTCOME_SUCCESS", "OUTCOME_NO_EFFECT");
    fs.writeFileSync(f.journal.getLineagePath(), lineage);
    const bad = runCli(["--journal", f.journal.getLineagePath(), "--key", keyPath]);
    assert.equal(bad.status, 1);

    const usage = runCli([]);
    assert.equal(usage.status, 2);
  } finally {
    fs.rmSync(f.dir, { recursive: true, force: true });
  }
});

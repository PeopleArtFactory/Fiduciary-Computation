# FC Gateway v0.1

Fail-closed consequence enforcement layer for autonomous agents and high-consequence systems.

FC Gateway is the MVP implementation of Fiduciary Computation as a small local gateway. It does not try to make intelligence trustworthy. It requires protected consequences to be explicitly admitted before they can begin.

## Canonical Thesis

```text
Cognitive compromise does not imply consequential authority.
```

A model, workflow, sensor, human or script is only a proposer. A proposal is not authority. A protected action can cross the gateway only through a deterministic admission path, an ephemeral capability, and a durable fiduciary precommitment.

## v0.1 Invariants

```text
No ADMIT, no capability.
No valid unconsumed capability, no protected execution.
No protected execution begins before durable PREPARED commitment.
Every PREPARED execution is closed as SUCCESS, NO_EFFECT, or UNKNOWN after successful reconciliation.
```

## Causal Flow

```text
Untrusted proposer
  -> Proposal
  -> FiduciaryEngine.evaluate()
  -> AdmissionDecision
  -> issueCapabilityToken()
  -> FiduciaryExecutor
  -> DFD EXECUTION_PREPARED + fsync
  -> protected operation
  -> DFD OUTCOME_* + fsync
  -> signed checkpoint
  -> offline verification
```

The `EXECUTION_PREPARED` deed is not a retrospective audit log. It is a durable causal precondition. If the process crashes after the external operation starts, startup reconciliation emits `OUTCOME_UNKNOWN` instead of pretending success or failure.

## Runtime Surface

The reference kernel is model-agnostic and producer-agnostic. It can sit in front of LLM tools, MCP servers, REST APIs, webhooks, scripts, SaaS calls, filesystem actions, or internal workflows.

Initial modes from the conversation:

- Local daemon: `Agent -> localhost -> external API`
- Sidecar: application container plus FC sidecar
- Reverse proxy: replace direct API endpoint with a fiduciary endpoint
- SDK: `fiduciary.execute({ proposal, perform })`
- Enterprise gateway: shared perimeter for agents and sensitive APIs

## Trusted Computing Base

The v0.1 TCB is explicit:

- FC kernel core
- active policies
- trusted issuer registry
- fiduciary runtime clock
- journal sealer Ed25519 private key
- capability HMAC secret
- Node.js runtime, OS and crash-durable storage
- integrity of the enforcement path

Out of scope for v0.1: host compromise, private-key extraction, side channels, hardware corruption, and bypass routes that avoid the gateway entirely.

## Metrics

Kernel metrics:

- `ASR`: adversarial success rate over ADV-01..ADV-09
- `UCR`: protected executions without valid ADMIT
- `AD`: admission determinism for identical canonical inputs
- `ELC`: execution attempts with durable PREPARED lineage
- `FCC`: PREPARED deeds eventually closed after reconciliation

Deployment metric:

- `BR`: protected actions executed outside the FC perimeter

## Repository Shape

```text
src/core      Proposal, policies, admission, executor, validation
src/crypto    Ed25519, HMAC, SHA-256 and fingerprints
src/dfd       canonical JSON and DFD sealing
src/journal   append-only lineage and startup reconciliation
src/cli       offline lineage verifier
tests         ADV-01..ADV-09 and crash/replay coverage
```

## Preserved Conversation Work

- `docs/ARCHITECTURE.md`: gateway architecture, deployment modes and causal state machine.
- `docs/API_CONTRACT.md`: MVP HTTP surface, local config artifacts and policy file shape.
- `docs/THREAT_MODEL.md`: TCB, ADV suite, metrics and limits.
- `docs/CONFORMANCE.md`: final canonical type, capability, journal and release-gate corrections.
- `docs/RESEARCH_CONTEXT.md`: ACI/DFD bridge, epistemic membrane and paper context.
- `docs/DECISIONS.md`: frozen v0.1 decisions, non-goals and release gates.
- `docs/ROADMAP.md`: adapters, portable bundles and open-core path.

## Commands

```bash
pnpm install
pnpm test
pnpm release:check
pnpm benchmark:q1 -- --samples 10 --warmup-core 2 --warmup-b5 2 --warmup-b6 1 --lineage-sizes 10,100
node dist/src/cli/verify.js --journal lineage.ndjson --key sealer-public.pem
```

Q1 performance harness (outside the frozen kernel): `benchmarks/q1-performance/`. See `papers/SWARM_STATUS.md`.

## Release Gate

v0.1.0 freezes the productive cryptographic constructions documented in `docs/DECISIONS.md` and `RELEASE_v0.1.0.md`. `pnpm release:check` must report `CONFORMANT` with zero runtime dependencies and distributable size under 1,400,000 bytes.

import { createPrivateKey, createPublicKey, generateKeyPairSync, sign, verify, type KeyObject } from "node:crypto";
import { DOMAIN_AUTHORITY, DOMAIN_CHECKPOINT } from "../core/constants.js";
import { FiduciaryValidationError } from "../core/errors.js";
import { canonicalizeJson } from "../dfd/canonicalize.js";
import type { AuthorityClaim, JsonValue, LineageCheckpoint, TrustedIssuer } from "../core/types.js";
import { domainSeparatedMessage } from "./domain.js";
import { assertEd25519SignatureHex, isEd25519SignatureHex } from "./encoding.js";
import { publicKeyFingerprint } from "./hash.js";

export interface KeyPairPem {
  publicKeyPem: string;
  privateKeyPem: string;
}

export type VerificationResult =
  | { valid: true; issuer: string; issuerKeyFingerprint: string }
  | { valid: false; reason: "UNKNOWN_ISSUER" | "MALFORMED_SIGNATURE" | "INVALID_SIGNATURE" };

function assertEd25519PrivateKey(privateKeyPem: string): KeyObject {
  let key: KeyObject;
  try {
    key = createPrivateKey(privateKeyPem);
  } catch {
    throw new FiduciaryValidationError("UNSUPPORTED_KEY_TYPE");
  }
  if (key.asymmetricKeyType !== "ed25519") throw new FiduciaryValidationError("UNSUPPORTED_KEY_TYPE");
  return key;
}

function assertEd25519PublicKey(publicKeyPem: string): KeyObject {
  let key: KeyObject;
  try {
    key = createPublicKey(publicKeyPem);
  } catch {
    throw new FiduciaryValidationError("UNSUPPORTED_KEY_TYPE");
  }
  if (key.asymmetricKeyType !== "ed25519") throw new FiduciaryValidationError("UNSUPPORTED_KEY_TYPE");
  return key;
}

/**
 * Normative v0.1 Ed25519 message for AuthorityClaim / Checkpoint / Lineage:
 *   M = UTF8( JCS({ domain: D, ...payloadFields }) )
 * No SHA-256 prehash is applied to M.
 *
 * `signEd25519Bytes` remains available for Domain||0x00||payload experiments,
 * but productive wrappers below use the domain-wrapped JCS construction.
 */
export function signEd25519Bytes(domain: string, payloadBytes: Buffer, privateKeyPem: string): string {
  const key = assertEd25519PrivateKey(privateKeyPem);
  const message = domainSeparatedMessage(domain, payloadBytes);
  return sign(null, message, key).toString("hex");
}

export function verifyEd25519Bytes(domain: string, payloadBytes: Buffer, signatureHex: string, publicKeyPem: string): boolean {
  assertEd25519SignatureHex(signatureHex);
  const key = assertEd25519PublicKey(publicKeyPem);
  const message = domainSeparatedMessage(domain, payloadBytes);
  return verify(null, message, key, Buffer.from(signatureHex, "hex"));
}

/** Productive Ed25519 wrapper: sign UTF-8(JCS(value)) where value already includes domain. */
export function signCanonical(value: object, privateKeyPem: string): string {
  const key = assertEd25519PrivateKey(privateKeyPem);
  const payload = Buffer.from(canonicalizeJson(value as JsonValue), "utf8");
  return sign(null, payload, key).toString("hex");
}

export function verifyCanonical(value: object, signatureHex: string, publicKeyPem: string): boolean {
  assertEd25519SignatureHex(signatureHex);
  const key = assertEd25519PublicKey(publicKeyPem);
  const payload = Buffer.from(canonicalizeJson(value as JsonValue), "utf8");
  return verify(null, payload, key, Buffer.from(signatureHex, "hex"));
}

export function generateEd25519KeyPair(): KeyPairPem {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519", {
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  return { publicKeyPem: publicKey, privateKeyPem: privateKey };
}

export function signAuthorityClaim(claim: Omit<AuthorityClaim, "signature">, privateKeyPem: string): AuthorityClaim {
  const signature = signCanonical({ domain: DOMAIN_AUTHORITY, claim }, privateKeyPem);
  return { ...claim, signature };
}

export function verifyAuthorityClaim(claim: AuthorityClaim, trustedIssuers: readonly TrustedIssuer[]): VerificationResult {
  const trusted = trustedIssuers.find((issuer) => issuer.issuerId === claim.issuer);
  if (!trusted) return { valid: false, reason: "UNKNOWN_ISSUER" };
  if (!isEd25519SignatureHex(claim.signature)) return { valid: false, reason: "MALFORMED_SIGNATURE" };

  const { signature, ...unsigned } = claim;
  try {
    const ok = verifyCanonical({ domain: DOMAIN_AUTHORITY, claim: unsigned }, signature, trusted.publicKeyPem);
    if (!ok) return { valid: false, reason: "INVALID_SIGNATURE" };
  } catch {
    return { valid: false, reason: "MALFORMED_SIGNATURE" };
  }

  return {
    valid: true,
    issuer: claim.issuer,
    issuerKeyFingerprint: publicKeyFingerprint(trusted.publicKeyPem),
  };
}

export function signCheckpoint(checkpoint: Omit<LineageCheckpoint, "signature">, privateKeyPem: string): LineageCheckpoint {
  return { ...checkpoint, signature: signCanonical({ domain: DOMAIN_CHECKPOINT, checkpoint }, privateKeyPem) };
}

export function verifyCheckpoint(checkpoint: LineageCheckpoint, trustedIssuers: readonly TrustedIssuer[]): VerificationResult {
  const trusted = trustedIssuers.find((issuer) => issuer.issuerId === checkpoint.issuerKeyId || issuer.issuerId === checkpoint.issuer);
  if (!trusted) return { valid: false, reason: "UNKNOWN_ISSUER" };
  if (!isEd25519SignatureHex(checkpoint.signature)) return { valid: false, reason: "MALFORMED_SIGNATURE" };

  const { signature, ...unsigned } = checkpoint;
  try {
    const ok = verifyCanonical({ domain: DOMAIN_CHECKPOINT, checkpoint: unsigned }, signature, trusted.publicKeyPem);
    if (!ok) return { valid: false, reason: "INVALID_SIGNATURE" };
  } catch {
    return { valid: false, reason: "MALFORMED_SIGNATURE" };
  }

  return {
    valid: true,
    issuer: checkpoint.issuer,
    issuerKeyFingerprint: publicKeyFingerprint(trusted.publicKeyPem),
  };
}

import { randomBytes } from "node:crypto";
import { DEFAULT_CAPABILITY_TTL_MS, MAX_CAPABILITY_TTL_MS } from "./constants.js";
import { FiduciarySecurityError } from "./errors.js";
import { assertAdmissionDecisionIntegrity } from "./admission.js";
import { hashJson } from "../crypto/hash.js";
import { computeCapabilityMac, requireValidCapabilityMac, assertHmacSecret } from "../crypto/hmac.js";
import type { AdmissionDecision, CapabilityToken, JsonValue, Proposal } from "./types.js";

export interface CapabilityIssueOptions {
  readonly issuer: string;
  readonly audience: string;
  readonly fiduciaryClock: number;
  readonly ttlMs?: number;
  readonly hmacSecret: Buffer;
}

export interface CapabilityValidationContext {
  readonly expectedIssuer: string;
  readonly expectedAudience: string;
  readonly fiduciaryClock: number;
  readonly hmacSecret: Buffer;
}

export function issueCapabilityToken(
  admission: AdmissionDecision,
  proposal: Proposal,
  options: CapabilityIssueOptions,
): CapabilityToken {
  if (admission.result !== "ADMIT") {
    throw new FiduciarySecurityError("ADMISSION_NOT_ADMIT");
  }
  assertAdmissionDecisionIntegrity(admission);
  assertHmacSecret(options.hmacSecret);

  const ttlMs = options.ttlMs ?? DEFAULT_CAPABILITY_TTL_MS;
  if (ttlMs <= 0 || ttlMs > MAX_CAPABILITY_TTL_MS) {
    throw new FiduciarySecurityError("INVALID_CAPABILITY_TTL");
  }
  if (!options.issuer || !options.audience) {
    throw new FiduciarySecurityError("INVALID_CAPABILITY_PARTY");
  }

  const proposalHash = hashJson(proposal as unknown as JsonValue);
  if (proposalHash !== admission.proposalHash) {
    throw new FiduciarySecurityError("PROPOSAL_ADMISSION_MISMATCH");
  }

  const issuedAt = options.fiduciaryClock;
  const expiresAt = issuedAt + ttlMs;
  const nonce = randomBytes(16).toString("hex");
  const tokenId = `cap_${hashJson({ admissionHash: admission.admissionHash, issuedAt, expiresAt, nonce } as JsonValue).slice(0, 24)}`;

  const unsignedCapability = {
    tokenId,
    admissionId: admission.admissionId,
    admissionHash: admission.admissionHash,
    proposalHash: admission.proposalHash,
    issuer: options.issuer,
    audience: options.audience,
    issuedAt,
    expiresAt,
    scope: proposal.target ? { action: proposal.action, target: proposal.target } : { action: proposal.action },
    nonce,
  };

  return { ...unsignedCapability, mac: computeCapabilityMac(unsignedCapability, options.hmacSecret) };
}

export function assertValidCapabilityToken(
  token: CapabilityToken,
  admission: AdmissionDecision,
  proposal: Proposal,
  context: CapabilityValidationContext,
): void {
  assertAdmissionDecisionIntegrity(admission);
  if (admission.result !== "ADMIT") throw new FiduciarySecurityError("ADMISSION_NOT_ADMIT");

  const proposalHash = hashJson(proposal as unknown as JsonValue);
  if (admission.proposalHash !== proposalHash) throw new FiduciarySecurityError("PROPOSAL_ADMISSION_MISMATCH");
  if (token.proposalHash !== proposalHash) throw new FiduciarySecurityError("CAPABILITY_PROPOSAL_MISMATCH");
  if (token.admissionId !== admission.admissionId) throw new FiduciarySecurityError("CAPABILITY_ADMISSION_ID_MISMATCH");
  if (token.admissionHash !== admission.admissionHash) throw new FiduciarySecurityError("CAPABILITY_ADMISSION_MISMATCH");
  if (token.issuer !== context.expectedIssuer) throw new FiduciarySecurityError("CAPABILITY_ISSUER_MISMATCH");
  if (token.audience !== context.expectedAudience) throw new FiduciarySecurityError("CAPABILITY_AUDIENCE_MISMATCH");
  if (token.scope.action !== proposal.action) throw new FiduciarySecurityError("CAPABILITY_ACTION_MISMATCH");
  if (token.scope.target !== proposal.target) throw new FiduciarySecurityError("CAPABILITY_TARGET_MISMATCH");
  if (context.fiduciaryClock < token.issuedAt || context.fiduciaryClock >= token.expiresAt) {
    throw new FiduciarySecurityError("CAPABILITY_EXPIRED_OR_PREDATED");
  }

  const { mac, ...unsigned } = token;
  requireValidCapabilityMac(unsigned, mac, context.hmacSecret);
}

/** Compatibility helper: returns null instead of throwing when admission is not ADMIT. */
export function tryIssueCapabilityToken(
  admission: AdmissionDecision,
  proposal: Proposal,
  options: CapabilityIssueOptions,
): CapabilityToken | null {
  if (admission.result !== "ADMIT") return null;
  return issueCapabilityToken(admission, proposal, options);
}

import { createHash, createPublicKey } from "node:crypto";
import { canonicalizeJson } from "../dfd/canonicalize.js";
import type { Hash256, JsonValue } from "../core/types.js";
import { isHash256Hex } from "./encoding.js";

export function sha256Hex(bytes: string | Buffer): Hash256 {
  return createHash("sha256").update(bytes).digest("hex");
}

export function hashJson(value: JsonValue): Hash256 {
  return sha256Hex(Buffer.from(canonicalizeJson(value), "utf8"));
}

export function isHash256(value: unknown): value is Hash256 {
  return isHash256Hex(value);
}

export function publicKeyFingerprint(publicKeyPem: string): Hash256 {
  const der = createPublicKey(publicKeyPem).export({ type: "spki", format: "der" });
  return sha256Hex(Buffer.from(der));
}

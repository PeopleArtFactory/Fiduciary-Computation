import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import {
  DFDSealer,
  FiduciaryEngine,
  FiduciaryGateway,
  FiduciaryJournal,
  canonicalizeJson,
  generateEd25519KeyPair,
  signAuthorityClaim,
} from "../src/index.js";
import type { AuthorityClaim, FiduciaryPolicy, Proposal, TrustedIssuer, VerifiedEvidenceRef } from "../src/index.js";

const hmacSecret = Buffer.from("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "hex");
const engine = new FiduciaryEngine();

function makeFixture() {
  const authA = generateEd25519KeyPair();
  const authB = generateEd25519KeyPair();
  const actor = { type: "ai" as const, id: "llm_agent_01" };
  const policyA: FiduciaryPolicy = {
    policyId: "pol_a",
    version: "1.0",
    action: "bank.transfer",
    consequenceClass: "FINANCIAL",
    riskLevel: 3,
    requiredAuthorityPermits: ["TRANSFER_APPROVE"],
    requiredEvidenceTypes: ["KYC_VERIFIED"],
    constraints: [{ field: "amount", operator: "lte", value: 50_000 }],
    effectOnMatch: "ADMIT",
  };
  const policyB: FiduciaryPolicy = {
    ...policyA,
    policyId: "pol_b",
    action: "email.send",
  };
  const evidenceA: VerifiedEvidenceRef = {
    evidenceId: "ev_a",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "a".repeat(64),
    verifiedAt: 1000,
  };
  const evidenceB: VerifiedEvidenceRef = {
    evidenceId: "ev_b",
    type: "KYC_VERIFIED",
    producer: "kyc",
    contentHash: "b".repeat(64),
    verifiedAt: 1001,
  };
  const proposal: Proposal = {
    proposalId: "prop_1",
    actor,
    action: "bank.transfer",
    target: "account_1",
    parameters: { amount: 1000 },
    contextRefs: [evidenceA.evidenceId],
    requestedAt: 1500,
  };
  const claimA = signAuthorityClaim(
    {
      claimId: "claim_a",
      issuer: "authority:a",
      subject: actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1000,
      expiresAt: 5000,
      nonce: "n1",
    },
    authA.privateKeyPem,
  );
  const claimB = signAuthorityClaim(
    {
      claimId: "claim_b",
      issuer: "authority:b",
      subject: actor.id,
      permits: ["EMAIL_SEND"],
      issuedAt: 1000,
      expiresAt: 5000,
      nonce: "n2",
    },
    authB.privateKeyPem,
  );
  const trusted: TrustedIssuer[] = [
    { issuerId: "authority:a", publicKeyPem: authA.publicKeyPem },
    { issuerId: "authority:b", publicKeyPem: authB.publicKeyPem },
  ];
  return { authA, authB, actor, policyA, policyB, evidenceA, evidenceB, proposal, claimA, claimB, trusted };
}

test("AD-01 same tuple yields identical AdmissionDecision", () => {
  const f = makeFixture();
  const d1 = engine.evaluate(f.proposal, [f.policyA], [f.claimA], [f.trusted[0]], [f.evidenceA], 2000);
  const d2 = engine.evaluate(f.proposal, [f.policyA], [f.claimA], [f.trusted[0]], [f.evidenceA], 2000);
  assert.equal(d1.result, "ADMIT");
  assert.equal(canonicalizeJson(d1 as never), canonicalizeJson(d2 as never));
  assert.equal(engine.verifyAdmissionDecision(d1), true);
});

test("AD-02..05 and combined permutations keep AD=1", () => {
  const f = makeFixture();
  const R = [f.policyA, f.policyB];
  const A = [f.claimA, f.claimB];
  const KT = f.trusted;
  const E = [f.evidenceA, f.evidenceB];
  const base = engine.evaluate(f.proposal, R, A, KT, E, 2000);
  const perms = [
    engine.evaluate(f.proposal, [R[1], R[0]], A, KT, E, 2000),
    engine.evaluate(f.proposal, R, [A[1], A[0]], KT, E, 2000),
    engine.evaluate(f.proposal, R, A, [KT[1], KT[0]], E, 2000),
    engine.evaluate(f.proposal, R, A, KT, [E[1], E[0]], 2000),
    engine.evaluate(f.proposal, [R[1], R[0]], [A[1], A[0]], [KT[1], KT[0]], [E[1], E[0]], 2000),
  ];
  let identical = 0;
  for (const d of [base, ...perms]) {
    if (canonicalizeJson(d as never) === canonicalizeJson(base as never)) identical += 1;
  }
  const AD = identical / (1 + perms.length);
  assert.equal(AD, 1);
  assert.equal(base.admissionHash, perms.at(-1)?.admissionHash);
  assert.equal(base.admissionId, perms.at(-1)?.admissionId);

  const artifactsDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../artifacts");
  fs.mkdirSync(artifactsDir, { recursive: true });
  fs.writeFileSync(
    path.join(artifactsDir, "K4_ADMISSION_DETERMINISM.json"),
    JSON.stringify(
      {
        schema: "FCG-K4-AD-0.1",
        kernelVersion: "0.1.0",
        sourceRevision: "local",
        generatedAt: new Date().toISOString(),
        ad: { numerator: identical, denominator: 1 + perms.length, value: AD, target: 1, status: "PASS" },
      },
      null,
      2,
    ),
  );
});

test("K4 functional rejects: missing/ambiguous policy, constraint, authority, evidence, temporal, forged", () => {
  const f = makeFixture();
  assert.equal(engine.evaluate(f.proposal, [], [f.claimA], [f.trusted[0]], [f.evidenceA], 2000).reasons[0], "NO_POLICY_MATCH");
  assert.equal(
    engine.evaluate(f.proposal, [f.policyA, { ...f.policyA, policyId: "dup" }], [f.claimA], [f.trusted[0]], [f.evidenceA], 2000).reasons[0],
    "AMBIGUOUS_POLICY_MATCH",
  );
  assert.match(
    engine.evaluate({ ...f.proposal, parameters: { amount: 99_999 } }, [f.policyA], [f.claimA], [f.trusted[0]], [f.evidenceA], 2000).reasons.join("|"),
    /CONSTRAINT_VIOLATION/,
  );
  assert.match(engine.evaluate(f.proposal, [f.policyA], [], [f.trusted[0]], [f.evidenceA], 2000).reasons.join("|"), /MISSING_OR_UNTRUSTED_AUTHORITY/);

  const attacker = generateEd25519KeyPair();
  const forged = signAuthorityClaim(
    {
      claimId: "forged",
      issuer: "authority:attacker",
      subject: f.actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1000,
      expiresAt: 5000,
      nonce: "nX",
    },
    attacker.privateKeyPem,
  );
  assert.match(
    engine.evaluate(f.proposal, [f.policyA], [forged], [f.trusted[0]], [f.evidenceA], 2000).reasons.join("|"),
    /MISSING_OR_UNTRUSTED_AUTHORITY/,
  );

  const future = { ...f.claimA, issuedAt: 3000, expiresAt: 5000 };
  const futureSigned = signAuthorityClaim(
    {
      claimId: "future",
      issuer: "authority:a",
      subject: f.actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 3000,
      expiresAt: 5000,
      nonce: "nf",
    },
    f.authA.privateKeyPem,
  );
  assert.equal(engine.evaluate(f.proposal, [f.policyA], [futureSigned], [f.trusted[0]], [f.evidenceA], 2000).result, "REJECT");
  void future;

  const expired = signAuthorityClaim(
    {
      claimId: "expired",
      issuer: "authority:a",
      subject: f.actor.id,
      permits: ["TRANSFER_APPROVE"],
      issuedAt: 1000,
      expiresAt: 1500,
      nonce: "ne",
    },
    f.authA.privateKeyPem,
  );
  assert.equal(engine.evaluate(f.proposal, [f.policyA], [expired], [f.trusted[0]], [f.evidenceA], 2000).result, "REJECT");

  assert.match(
    engine.evaluate({ ...f.proposal, contextRefs: [] }, [f.policyA], [f.claimA], [f.trusted[0]], [f.evidenceA], 2000).reasons.join("|"),
    /MISSING_OR_UNBOUND_VERIFIED_EVIDENCE/,
  );
});

test("Gateway freezes trusted R/KT snapshot against caller aliasing", () => {
  const f = makeFixture();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fcg-k4-"));
  try {
    const sealerKeys = generateEd25519KeyPair();
    const sealer = new DFDSealer("node", "root", sealerKeys.publicKeyPem, sealerKeys.privateKeyPem);
    const journal = new FiduciaryJournal(sealer, dir);
    const policies = [f.policyA];
    const gateway = new FiduciaryGateway({
      policies,
      trustedIssuers: [f.trusted[0]],
      hmacSecret,
      journal,
      now: () => 2000,
    });
    policies.push({
      ...f.policyA,
      policyId: "attacker_admit_all",
      constraints: [],
      requiredAuthorityPermits: [],
      requiredEvidenceTypes: [],
    });
    const decision = gateway.evaluate({ ...f.proposal, parameters: { amount: 1_000_000 } }, [f.claimA], [f.evidenceA]);
    assert.equal(decision.result, "REJECT");
    assert.match(decision.reasons.join("|"), /CONSTRAINT_VIOLATION/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

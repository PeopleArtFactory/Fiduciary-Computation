# FC Gateway — Cloud Lab Pack (campaign-q1-003)

Portable snapshot to run the **v0.1.1-candidate** performance campaign on any machine
(Linux / macOS / Windows) without the monorepo.

## What this pack is

| Included | Purpose |
|---|---|
| `src/`, `tests/` | Kernel + tests (working-tree v0.1.1 candidate: `writeAllSync`, harness purity) |
| `benchmarks/q1-performance/` | Harness B0–B6 + pinned `H_spec` |
| `package.json`, `pnpm-lock.yaml`, `tsconfig.json` | Build toolchain |
| `.gitignore` | Keeps `results/` out of the dirty-tree gate |
| `docs/`, `README.md`, `RELEASE_v0.1.0.md` | Context |
| `LAB_CLOUD.md` (this file) | Operator instructions |
| `lab/*.sh`, `lab/*.ps1` | Bootstrap + campaign runners |

| Excluded | Why |
|---|---|
| `node_modules/`, `dist/`, `results/` | Rebuild locally |
| Incomplete local `campaign-q1-003` journals | Each lab produces its own evidence |
| `edge/`, `papers/` LaTeX corpus | Not required for the campaign |
| Secrets / SSH keys | Never ship |

## Frozen vs candidate

- **Scientific freeze (do not retag):** `v0.1.0-conformant` @ `d6ff393cee8e9f8fc48e9e75517eb88a85218dab`
- **This pack runs profile `candidate`** (working-tree durability + harness purity)
- Pinned \(H_{\mathrm{spec}}\) = contents of `benchmarks/q1-performance/benchmark-spec-v0.1.1.sha256`
- Do **not** invent manuscript numbers from pilots. Only `VALID_MEASUREMENT` may refresh §7.

## Requirements

- Node.js **≥ 18.17** (recommended **22.x**, same family as q1-001)
- **pnpm** 10.x (`corepack enable && corepack prepare pnpm@10.0.0 --activate`)
- **git** (required for provenance / clean-tree gate)
- Disk: ≥ 5 GB free under the lab directory (B5 fixtures + journals)
- Prefer a quiet machine (no heavy concurrent loads) for publication-grade runs

## One-time bootstrap

### Linux / macOS

```bash
unzip FC-GATEWAY-campaign-q1-003-lab.zip
cd FC-GATEWAY-campaign-q1-003-lab
chmod +x lab/*.sh
./lab/00-bootstrap.sh
```

### Windows (PowerShell)

```powershell
Expand-Archive FC-GATEWAY-campaign-q1-003-lab.zip -DestinationPath .
cd FC-GATEWAY-campaign-q1-003-lab
.\lab\00-bootstrap.ps1
```

Bootstrap will: `pnpm install`, create a **local git repo**, commit the pack so the monitored tree is clean, then `pnpm build` + kernel tests.

## Pilot (optional, fast)

```bash
./lab/01-pilot.sh
# or: .\lab\01-pilot.ps1
```

Expect `INVALID_MEASUREMENT` if you pass `--allow-dirty-pilot`, or `VALID_MEASUREMENT` on a clean short run with tiny N. Pilots are **not** publication evidence.

## Full campaign-q1-003

```bash
./lab/02-campaign-q1-003.sh
# or: .\lab\02-campaign-q1-003.ps1
```

Equivalent manual command:

```bash
pnpm benchmark:q1 -- --profile candidate \
  --samples 1000 \
  --warmup-core 200 \
  --warmup-b5 20 \
  --warmup-b6 5 \
  --lineage-sizes 10,100,1000,10000 \
  --output benchmarks/q1-performance/results/campaign-q1-003
```

**Runtime note:** B5 at `|L|=10000` with N=1000 can take **hours** on a laptop (and may exhibit rare extreme tails). Prefer a dedicated cloud VM; leave the process alone until `summary.json` appears.

## Success criteria

Under `benchmarks/q1-performance/results/campaign-q1-003/`:

| File | Required |
|---|---|
| `summary.json` | `status: "VALID_MEASUREMENT"` |
| `environment.json` | Host + provenance |
| `provenance.json` | Hash chain |
| `B*-*.raw.json` (or per-size B5 raws) | Measured samples |
| `H_env` / `H_benchmark` | Inside summary / provenance |

Also preserve:

- Node / pnpm / OS / CPU / memory / region / instance type
- Exact `git rev-parse HEAD` of the lab commit
- Wall-clock start/end UTC

## Return package (for the paper swarm)

Zip **only** the result directory + a short `LAB_REPORT.md`:

```bash
./lab/03-pack-results.sh
# produces: lab-out/campaign-q1-003-<host>-<utc>.zip
```

Do **not** modify `src/` after bootstrap if you want `VALID_MEASUREMENT`. Any monitored-path edit dirties the tree.

## Multi-cloud protocol

1. Each agent unpacks this same ZIP (same `H_spec` pin).
2. Each agent bootstraps → own git commit (different `sourceCommit` is expected and recorded).
3. Each agent runs the **same** CLI parameters above.
4. Return `VALID_MEASUREMENT` zips; compare absolute latencies across environments without inventing a single “true” number.
5. Manuscript §7 stays on `campaign-q1-001` until the swarm **accepts** one publication-grade snapshot (or a multi-env table with explicit hosts).

## Safety

- No secrets in this pack.
- Do not retag `v0.1.0-conformant`.
- Do not claim B1/B3/B4 “improvements” vs freeze from purity alone.

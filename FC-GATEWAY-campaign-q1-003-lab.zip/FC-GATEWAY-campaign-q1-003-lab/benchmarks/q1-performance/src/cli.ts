import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs, shouldRun } from "./config.js";
import { collectEnvironment, environmentHash, assertMeasurementGates } from "./environment.js";
import { createBenchFixture } from "./fixtures.js";
import { runB0 } from "./b0-direct.js";
import { runB1 } from "./b1-admission.js";
import { runB2 } from "./b2-capability.js";
import { runB3 } from "./b3-prepared.js";
import { runB4 } from "./b4-full-path.js";
import { buildLineageFixture } from "./lineage-fixtures.js";
import { runB5 } from "./b5-verification.js";
import { runB6 } from "./b6-recovery.js";
import { buildReport, writeReportOutputs, type RawBundle } from "./report.js";
import { PINNED_H_SPEC } from "./provenance.js";

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");

async function main(): Promise<void> {
  const cfg = parseArgs(process.argv.slice(2));
  fs.mkdirSync(cfg.outputDir, { recursive: true });
  fs.mkdirSync(cfg.journalRoot, { recursive: true });

  let env;
  try {
    env = collectEnvironment(cfg, repoRoot);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    fs.writeFileSync(
      path.join(cfg.outputDir, "summary.json"),
      JSON.stringify({ status: "INVALID_MEASUREMENT", reason: message, pinnedHSpec: PINNED_H_SPEC }, null, 2) + "\n",
    );
    console.error(message);
    process.exitCode = 2;
    return;
  }

  fs.writeFileSync(path.join(cfg.outputDir, "environment.json"), JSON.stringify(env, null, 2) + "\n");
  const envHash = environmentHash(env);
  fs.writeFileSync(
    path.join(cfg.outputDir, "provenance.json"),
    JSON.stringify(
      {
        schema: "FC-GATEWAY-BENCH-PROVENANCE-v0.1.1",
        pinnedHSpec: PINNED_H_SPEC,
        specHash: env.specHash,
        environmentHash: envHash,
        generatorHash: env.generator.generatorHash,
        source: env.source,
        profile: env.profile,
      },
      null,
      2,
    ) + "\n",
  );

  try {
    assertMeasurementGates(env);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (!cfg.allowDirtyPilot) {
      fs.writeFileSync(
        path.join(cfg.outputDir, "summary.json"),
        JSON.stringify(
          {
            status: "INVALID_MEASUREMENT",
            reason: message,
            environmentHash: envHash,
            provenance: { specHash: env.specHash, generatorHash: env.generator.generatorHash },
            environment: env,
          },
          null,
          2,
        ) + "\n",
      );
      console.error(message);
      process.exitCode = 2;
      return;
    }
    console.warn(`[pilot] continuing despite gate failure: ${message}`);
  }

  const fx = createBenchFixture(path.join(cfg.journalRoot, "fixture-root"));
  const raw: RawBundle = {};

  if (shouldRun(cfg, "B0")) raw.B0 = await runB0(cfg.samples, cfg.warmupCore);
  if (shouldRun(cfg, "B1")) raw.B1 = await runB1(fx, cfg.samples, cfg.warmupCore);
  if (shouldRun(cfg, "B2")) raw.B2 = await runB2(fx, cfg.samples, cfg.warmupCore);
  if (shouldRun(cfg, "B3")) raw.B3 = await runB3(fx, cfg.samples, cfg.warmupCore);
  if (shouldRun(cfg, "B4")) raw.B4 = await runB4(fx, cfg.samples, cfg.warmupCore);
  if (shouldRun(cfg, "B5")) {
    const fixtures = cfg.lineageSizes.map((n) => buildLineageFixture(path.join(cfg.journalRoot, "b5"), n));
    raw.B5 = await runB5(fixtures, cfg.samples, cfg.warmupB5);
  }
  if (shouldRun(cfg, "B6")) raw.B6 = await runB6(fx, cfg.samples, cfg.warmupB6);

  const { status, summary, summaryMd, benchmarkHash } = buildReport({
    outputDir: cfg.outputDir,
    env,
    envHash,
    raw,
    samples: cfg.samples,
    lineageSizes: cfg.lineageSizes,
  });
  writeReportOutputs(cfg.outputDir, summary, summaryMd);

  console.log(
    JSON.stringify(
      {
        status,
        profile: cfg.profile,
        outputDir: cfg.outputDir,
        specHash: env.specHash,
        environmentHash: envHash,
        generatorHash: env.generator.generatorHash,
        benchmarkHash,
        dirty: env.source.dirty,
      },
      null,
      2,
    ),
  );
  if (status !== "VALID_MEASUREMENT") process.exitCode = 2;
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

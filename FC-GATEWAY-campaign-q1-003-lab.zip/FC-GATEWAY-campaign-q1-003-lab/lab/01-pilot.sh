#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

pnpm benchmark:q1 -- --profile candidate \
  --samples 5 \
  --warmup-core 1 \
  --warmup-b5 1 \
  --warmup-b6 1 \
  --lineage-sizes 10,100 \
  --output benchmarks/q1-performance/results/pilot-lab

echo
echo "Pilot finished. Inspect benchmarks/q1-performance/results/pilot-lab/summary.json"
echo "Pilots are not publication evidence."

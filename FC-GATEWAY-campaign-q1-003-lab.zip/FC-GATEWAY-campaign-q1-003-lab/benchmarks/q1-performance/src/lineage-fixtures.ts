import * as fs from "node:fs";
import * as path from "node:path";
import {
  DFDSealer,
  FiduciaryJournal,
  generateEd25519KeyPair,
  sha256Hex,
  verifyLineage,
} from "../../../dist/src/index.js";
import type { DFDDeed } from "../../../dist/src/index.js";

export interface LineageFixture {
  size: number;
  dir: string;
  deeds: DFDDeed[];
  sealerPublicKeyPem: string;
  sealerIssuer: string;
  sealerIssuerKeyId: string;
}

export function buildLineageFixture(rootDir: string, deedCount: number): LineageFixture {
  if (deedCount <= 0 || deedCount % 2 !== 0) {
    throw new Error(`INVALID_LINEAGE_FIXTURE_SIZE:${deedCount}: expected positive even deed count`);
  }
  const dir = path.join(rootDir, `journal-${String(deedCount).padStart(6, "0")}`);
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  const keys = generateEd25519KeyPair();
  const sealerIssuer = "benchmark:lineage";
  const sealerIssuerKeyId = "benchmark:key";
  const sealer = new DFDSealer(sealerIssuer, sealerIssuerKeyId, keys.publicKeyPem, keys.privateKeyPem);
  const journal = new FiduciaryJournal(sealer, dir);
  const acts = deedCount / 2;
  for (let i = 0; i < acts; i++) {
    const prepared = journal.reserveExecution({
      tokenId: `token-${i}`,
      admissionHash: sha256Hex(`admission-${i}`),
      proposalHash: sha256Hex(`proposal-${i}`),
      actor: { type: "software", id: "benchmark-generator" },
      action: "BENCHMARK_ACTION",
      target: `target-${i}`,
      timestamp: 10_000 + i * 2,
    });
    journal.appendOutcome(prepared, "OUTCOME_SUCCESS", {
      outcome: { ok: true, iteration: i },
      timestamp: 10_001 + i * 2,
    });
  }
  const deeds = journal.readAllDeeds();
  if (deeds.length !== deedCount) {
    throw new Error(`INVALID_MEASUREMENT: expected ${deedCount} deeds, got ${deeds.length}`);
  }
  const verification = verifyLineage(deeds, {
    sealerPublicKeyPem: keys.publicKeyPem,
    sealerIssuer,
    sealerIssuerKeyId,
  });
  if (!verification.report.integrityValid || !verification.report.closureComplete) {
    throw new Error("INVALID_MEASUREMENT: generated B5 fixture is not valid and closed");
  }
  return {
    size: deedCount,
    dir,
    deeds,
    sealerPublicKeyPem: keys.publicKeyPem,
    sealerIssuer,
    sealerIssuerKeyId,
  };
}

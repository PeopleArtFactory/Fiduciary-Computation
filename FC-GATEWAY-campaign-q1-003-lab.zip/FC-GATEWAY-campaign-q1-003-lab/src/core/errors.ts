export class FiduciaryValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FiduciaryValidationError";
  }
}

export class FiduciarySecurityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FiduciarySecurityError";
  }
}

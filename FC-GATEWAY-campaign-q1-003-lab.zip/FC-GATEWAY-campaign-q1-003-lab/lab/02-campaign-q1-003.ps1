$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$Out = "benchmarks/q1-performance/results/campaign-q1-003"
New-Item -ItemType Directory -Force -Path $Out | Out-Null
$Log = Join-Path $Out "run.log"

$dirty = git status --porcelain -- src tests package.json tsconfig.json benchmarks/q1-performance
if ($dirty) {
  Write-Host "ERROR: monitored tree dirty — commit or stash before VALID campaign"
  Write-Host $dirty
  exit 1
}

function Append-Log([string]$line) {
  Add-Content -Path $Log -Value $line
  Write-Host $line
}

Append-Log ("START_UTC=" + [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"))
Append-Log ("HEAD=" + (git rev-parse HEAD))
Append-Log ("HOST=" + $env:COMPUTERNAME)
Append-Log ("NODE=" + (node -v))

$prev = $ErrorActionPreference
$ErrorActionPreference = "Continue"
pnpm benchmark:q1 -- --profile candidate `
  --samples 1000 `
  --warmup-core 200 `
  --warmup-b5 20 `
  --warmup-b6 5 `
  --lineage-sizes 10,100,1000,10000 `
  --output $Out *>> $Log
$code = $LASTEXITCODE
$ErrorActionPreference = $prev

Append-Log ("END_UTC=" + [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"))
Append-Log ("EXIT=$code")

$summary = Join-Path $Out "summary.json"
if (Test-Path $summary) {
  Write-Host "--- summary present ---"
  Get-Content $summary -TotalCount 40
} else {
  Write-Host "WARNING: no summary.json (exit=$code). See $Log"
}
exit $code

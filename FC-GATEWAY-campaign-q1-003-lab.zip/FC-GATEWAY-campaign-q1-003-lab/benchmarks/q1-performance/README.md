# FC Gateway Q1 Performance Benchmark Harness

Publication-grade measurement harness.

- Historical freeze: `v0.1.0-conformant` / campaign-q1-001
- Candidate profile: `v0.1.1-conformant-candidate` (working-tree journal+purity changes; **do not retag freeze**)

**Does not modify the frozen tag.** Kernel changes for v0.1.1 live in the working tree until a new tag is accepted.

## Spec freeze (before any campaign)

| Artifact | Path |
|---|---|
| Measurement table | `MEASUREMENT_TABLE_v0.1.1.md` |
| Normative JSON spec | `benchmark-spec-v0.1.1.json` |
| Pinned \(H_{\mathrm{spec}}\) | `benchmark-spec-v0.1.1.sha256` |

Changing the spec after hashing ⇒ **NEW CAMPAIGN**.

## Provenance chain (v0.1.1)

\[
H_{\mathrm{benchmark}}
\text{ commits }
Source + Spec + Environment + RawData + Generator + ReportBody
\]

Each raw file is an envelope (`FC-GATEWAY-BENCH-RAW-v0.1.1`) with `sourceCommit`, `specHash`, `environmentHash`, and sample counts. B5 emits one raw per lineage size.

## Experiments

| ID | Inside timer |
|---|---|
| B0 | Instrumental timing floor only |
| B1 | `normalizeProposal` + `evaluate` |
| B2 | capability issue + validate |
| B3 | `reserveExecution` only |
| B4 | mediated SUCCESS (replay check **outside** timer) |
| B5 | `verifyLineage` only |
| B6 | core recovery (`bootstrap+reconcile`); spawn cost = `workerEnvelope` |

## Commands

```bash
# Candidate pilot (dirty tree ⇒ INVALID unless committed clean)
pnpm benchmark:q1 -- --profile candidate --allow-dirty-pilot \
  --samples 5 --warmup-core 1 --warmup-b5 1 --warmup-b6 1 --lineage-sizes 10,100

# Full candidate campaign (requires clean monitored tree)
pnpm benchmark:q1 -- --profile candidate --samples 1000 \
  --warmup-core 200 --warmup-b5 20 --warmup-b6 5 \
  --lineage-sizes 10,100,1000,10000 \
  --output benchmarks/q1-performance/results/campaign-q1-003

# Historical freeze profile (exact tag/commit match)
pnpm benchmark:q1 -- --profile freeze --samples 1000 ...
```

Result vocabulary: `VALID_MEASUREMENT` | `INVALID_MEASUREMENT`

Campaign-q1-003 additionally gates the canonical source-pack identity and the actually resolved pnpm/TypeScript/@types-node/undici-types versions. A clean Git tree is necessary but no longer sufficient for `VALID_MEASUREMENT`.

(never reuse `CONFORMANT`). Do not invent Section 7 numbers from pilots.

import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import {
  DOMAIN_AUTHORITY,
  DOMAIN_CAPABILITY,
  DOMAIN_LINEAGE,
  FiduciarySecurityError,
  FiduciaryValidationError,
  assertEd25519SignatureHex,
  assertHash256Hex,
  assertHmacSha256Hex,
  canonicalizeJson,
  computeCapabilityMac,
  generateEd25519KeyPair,
  hmacDomainSeparated,
  signCanonical,
  verifyCanonical,
  verifyCapabilityMac,
} from "../src/index.js";

test("K2 encoding: hash/mac/signature reject wrong length and uppercase", () => {
  assert.throws(() => assertHash256Hex("a".repeat(63)), FiduciaryValidationError);
  assert.throws(() => assertHash256Hex("a".repeat(65)), FiduciaryValidationError);
  assert.throws(() => assertHash256Hex("A".repeat(64)), FiduciaryValidationError);
  assert.throws(() => assertHmacSha256Hex("b".repeat(63)), FiduciaryValidationError);
  assert.throws(() => assertHmacSha256Hex("BB".repeat(32)), FiduciaryValidationError);
  assert.throws(() => assertEd25519SignatureHex("c".repeat(127)), FiduciaryValidationError);
  assert.throws(() => assertEd25519SignatureHex("c".repeat(129)), FiduciaryValidationError);
  assert.throws(() => assertEd25519SignatureHex("C".repeat(128)), FiduciaryValidationError);
});

test("K2 Ed25519: valid signature, wrong key, altered payload, wrong domain, malformed, non-ed25519", () => {
  const a = generateEd25519KeyPair();
  const b = generateEd25519KeyPair();
  const payload = { domain: DOMAIN_AUTHORITY, claim: { claimId: "c1", issuer: "i1" } };
  const signature = signCanonical(payload, a.privateKeyPem);

  assert.equal(verifyCanonical(payload, signature, a.publicKeyPem), true);
  assert.equal(verifyCanonical(payload, signature, b.publicKeyPem), false);
  assert.equal(verifyCanonical({ ...payload, claim: { claimId: "c2", issuer: "i1" } }, signature, a.publicKeyPem), false);
  assert.equal(verifyCanonical({ domain: DOMAIN_LINEAGE, claim: payload.claim }, signature, a.publicKeyPem), false);
  assert.throws(() => verifyCanonical(payload, "zz" + "0".repeat(126), a.publicKeyPem), FiduciaryValidationError);

  const rsa = generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  assert.throws(() => signCanonical(payload, rsa.privateKey), FiduciaryValidationError);
  assert.throws(() => verifyCanonical(payload, signature, rsa.publicKey), FiduciaryValidationError);
});

test("K2 HMAC: secret length, wrong secret, altered payload, wrong domain, malformed MAC, canonical order", () => {
  const secret = Buffer.alloc(32, 7);
  const short = Buffer.alloc(31, 7);
  const unsigned = {
    tokenId: "cap_1",
    admissionId: "adm_1",
    admissionHash: "a".repeat(64),
    proposalHash: "b".repeat(64),
    issuer: "fc-gateway",
    audience: "fiduciary-executor",
    issuedAt: 1,
    expiresAt: 2,
    scope: { action: "bank.transfer" },
    nonce: "n1",
  };

  assert.throws(() => computeCapabilityMac(unsigned, short), FiduciarySecurityError);

  const mac = computeCapabilityMac(unsigned, secret);
  assert.equal(verifyCapabilityMac(unsigned, mac, secret), true);
  assert.equal(verifyCapabilityMac(unsigned, mac, Buffer.alloc(32, 8)), false);
  assert.equal(verifyCapabilityMac({ ...unsigned, nonce: "n2" }, mac, secret), false);
  assert.equal(verifyCapabilityMac(unsigned, "0".repeat(63) + "g", secret), false);

  const payload = Buffer.from(canonicalizeJson(unsigned as never), "utf8");
  const wrongDomainMac = hmacDomainSeparated(secret, DOMAIN_LINEAGE, payload);
  assert.equal(verifyCapabilityMac(unsigned, wrongDomainMac, secret), false);
  assert.notEqual(wrongDomainMac, hmacDomainSeparated(secret, DOMAIN_CAPABILITY, payload));

  const reordered = {
    nonce: "n1",
    scope: { action: "bank.transfer" },
    expiresAt: 2,
    issuedAt: 1,
    audience: "fiduciary-executor",
    issuer: "fc-gateway",
    proposalHash: "b".repeat(64),
    admissionHash: "a".repeat(64),
    admissionId: "adm_1",
    tokenId: "cap_1",
  };
  assert.equal(computeCapabilityMac(reordered, secret), mac);
});

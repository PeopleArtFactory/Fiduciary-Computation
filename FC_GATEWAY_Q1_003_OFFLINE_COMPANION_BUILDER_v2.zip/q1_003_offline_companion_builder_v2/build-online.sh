#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 /path/to/FC-GATEWAY-campaign-q1-003-lab.zip [output-dir]" >&2
  exit 2
fi

LAB_ZIP="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
OUT="${2:-$PWD/FC-GATEWAY-q1-003-offline-toolchain}"
EXPECTED_ZIP="f0b46ab0d3f81e87fe7c82fc4a6f23ceb8057c59940cd7a67adb8f696b98c488"

command -v node >/dev/null || { echo "ERROR: node required"; exit 1; }
command -v corepack >/dev/null || { echo "ERROR: corepack required"; exit 1; }
command -v unzip >/dev/null || { echo "ERROR: unzip required"; exit 1; }
command -v sha256sum >/dev/null || { echo "ERROR: sha256sum required"; exit 1; }

ACTUAL_ZIP="$(sha256sum "$LAB_ZIP" | awk '{print $1}')"
[ "$ACTUAL_ZIP" = "$EXPECTED_ZIP" ] || {
  echo "ERROR: q1-003 lab ZIP hash mismatch" >&2
  echo " expected: $EXPECTED_ZIP" >&2
  echo " actual:   $ACTUAL_ZIP" >&2
  exit 1
}

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$LAB_ZIP" -d "$TMP/lab"
ROOT="$(find "$TMP/lab" -mindepth 1 -maxdepth 1 -type d | head -1)"
[ -n "$ROOT" ] || { echo "ERROR: extracted lab root not found"; exit 1; }

rm -rf "$OUT"
mkdir -p "$OUT/pnpm-store"

# Keep Corepack state isolated from the builder's normal user configuration.
export COREPACK_HOME="$TMP/corepack-home"
mkdir -p "$COREPACK_HOME"

# Archive the exact package manager for offline Corepack installation.
(
  cd "$ROOT"
  corepack pack pnpm@10.0.0 -o "$OUT/corepack-pnpm-10.0.0.tgz"
)

# Install/cache that exact pnpm in the isolated Corepack home, then populate a
# portable pnpm store from the frozen lockfile.
corepack install -g --cache-only "$OUT/corepack-pnpm-10.0.0.tgz"
(
  cd "$ROOT"
  corepack pnpm --version | grep -qx '10.0.0'
  corepack pnpm fetch --frozen-lockfile --store-dir "$OUT/pnpm-store"
)

cp "$ROOT/pnpm-lock.yaml" "$OUT/pnpm-lock.yaml"
cp "$ROOT/package.json" "$OUT/package.json"

cat > "$OUT/TOOLCHAIN_INFO.txt" <<EOF
campaign=campaign-q1-003
lab_zip_sha256=$EXPECTED_ZIP
pnpm=10.0.0
node_builder=$(node -v)
created_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)
EOF

(
  cd "$OUT"
  find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
)

tar -C "$(dirname "$OUT")" -czf "$OUT.tar.gz" "$(basename "$OUT")"
BUNDLE_SHA="$(sha256sum "$OUT.tar.gz" | awk '{print $1}')"
echo "$BUNDLE_SHA  $(basename "$OUT.tar.gz")" > "$OUT.tar.gz.sha256"

echo "OFFLINE TOOLCHAIN BUNDLE CREATED"
echo "bundle: $OUT.tar.gz"
echo "sha256: $BUNDLE_SHA"
echo "Upload the .tar.gz (and optionally .sha256) to the independent evaluator."

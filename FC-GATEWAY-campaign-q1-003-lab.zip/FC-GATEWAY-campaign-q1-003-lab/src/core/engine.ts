import { computeAdmissionHash, computeAdmissionId } from "./admission.js";
import { tryIssueCapabilityToken } from "./capability.js";
import { canonicalizeJson } from "../dfd/canonicalize.js";
import { DEFAULT_CAPABILITY_TTL_MS } from "./constants.js";
import { hashJson, publicKeyFingerprint } from "../crypto/hash.js";
import { verifyAuthorityClaim } from "../crypto/signatures.js";
import type {
  AdmissionDecision,
  AuthorityClaim,
  CapabilityToken,
  FiduciaryPolicy,
  JsonValue,
  PolicyConstraint,
  Proposal,
  TrustedIssuer,
  VerifiedAuthorityClaimRef,
  VerifiedEvidenceRef,
  VerifiedEvidenceRefBound,
} from "./types.js";

export class FiduciaryEngine {
  public evaluate(
    proposal: Proposal,
    policySet: readonly FiduciaryPolicy[],
    authorityClaims: readonly AuthorityClaim[],
    trustedIssuers: readonly TrustedIssuer[],
    evidences: readonly VerifiedEvidenceRef[],
    evaluationTimestamp: number,
  ): AdmissionDecision {
    const proposalHash = hashJson(proposal as unknown as JsonValue);
    const policies = sortByHash([...policySet]);
    const claims = sortByHash([...authorityClaims]);
    const evidenceList = sortByHash([...evidences]);
    const issuers = sortTrustedIssuers([...trustedIssuers]);

    if (hasConflictingTrustedIssuers(issuers)) {
      return this.buildDecision({
        proposalHash,
        policyId: "INVALID_TCB",
        policyVersion: "0",
        policyHash: "0".repeat(64),
        result: "REJECT",
        evaluatedAt: evaluationTimestamp,
        reasons: ["DUPLICATE_TRUSTED_ISSUER"],
        verifiedAuthorityClaims: [],
        verifiedEvidences: [],
      });
    }

    const matchingPolicies = policies.filter((policy) => policy.action === proposal.action);

    if (matchingPolicies.length !== 1) {
      return this.buildDecision({
        proposalHash,
        policyId: matchingPolicies.length === 0 ? "NONE" : "AMBIGUOUS",
        policyVersion: "0",
        policyHash: "0".repeat(64),
        result: "REJECT",
        evaluatedAt: evaluationTimestamp,
        reasons: [matchingPolicies.length === 0 ? "NO_POLICY_MATCH" : "AMBIGUOUS_POLICY_MATCH"],
        verifiedAuthorityClaims: [],
        verifiedEvidences: [],
      });
    }

    const policy = matchingPolicies[0];
    const policyHash = hashJson(policy as unknown as JsonValue);
    const reasons: string[] = [];

    for (const constraint of policy.constraints ?? []) {
      if (!this.evaluateConstraint(proposal.parameters, constraint)) {
        reasons.push(`CONSTRAINT_VIOLATION:${constraint.field}:${constraint.operator}`);
      }
    }

    const verifiedAuthorityClaims = this.collectAuthorityClaims(
      proposal,
      policy,
      claims,
      issuers,
      evaluationTimestamp,
      reasons,
    );

    const verifiedEvidences = this.collectEvidenceRefs(proposal, policy, evidenceList, reasons);

    if (reasons.length > 0) {
      return this.buildDecision({
        proposalHash,
        policyId: policy.policyId,
        policyVersion: policy.version,
        policyHash,
        result: "REJECT",
        evaluatedAt: evaluationTimestamp,
        reasons,
        verifiedAuthorityClaims,
        verifiedEvidences,
      });
    }

    return this.buildDecision({
      proposalHash,
      policyId: policy.policyId,
      policyVersion: policy.version,
      policyHash,
      result: policy.effectOnMatch,
      evaluatedAt: evaluationTimestamp,
      reasons: ["POLICY_REQUIREMENTS_SATISFIED"],
      verifiedAuthorityClaims,
      verifiedEvidences,
    });
  }

  /** Thin wrapper over capability.ts for existing call sites. Prefer issueCapabilityToken. */
  public mintCapability(
    decision: AdmissionDecision,
    proposal: Proposal,
    secretKey: Buffer,
    nowTimestamp: number,
    ttlMs = DEFAULT_CAPABILITY_TTL_MS,
    issuer = "fc-gateway",
    audience = "fiduciary-executor",
  ): CapabilityToken | null {
    return tryIssueCapabilityToken(decision, proposal, {
      issuer,
      audience,
      fiduciaryClock: nowTimestamp,
      ttlMs,
      hmacSecret: secretKey,
    });
  }

  public verifyAdmissionDecision(decision: AdmissionDecision): boolean {
    try {
      const { admissionId, admissionHash, ...body } = decision;
      return computeAdmissionHash(body) === admissionHash && admissionId === computeAdmissionId(admissionHash);
    } catch {
      return false;
    }
  }

  private collectAuthorityClaims(
    proposal: Proposal,
    policy: FiduciaryPolicy,
    authorityClaims: readonly AuthorityClaim[],
    trustedIssuers: readonly TrustedIssuer[],
    evaluationTimestamp: number,
    reasons: string[],
  ): VerifiedAuthorityClaimRef[] {
    const verified: VerifiedAuthorityClaimRef[] = [];

    for (const requiredPermit of policy.requiredAuthorityPermits ?? []) {
      const match = authorityClaims.find((claim) => {
        if (claim.subject !== proposal.actor.id) return false;
        if (!claim.permits.includes(requiredPermit)) return false;
        if (!(claim.issuedAt < claim.expiresAt)) return false;
        if (claim.issuedAt > evaluationTimestamp || evaluationTimestamp >= claim.expiresAt) return false;
        return verifyAuthorityClaim(claim, trustedIssuers).valid;
      });

      if (!match) {
        reasons.push(`MISSING_OR_UNTRUSTED_AUTHORITY_PERMIT:${requiredPermit}`);
        continue;
      }

      const trusted = trustedIssuers.find((issuer) => issuer.issuerId === match.issuer);
      if (!trusted) {
        reasons.push(`UNKNOWN_ISSUER:${match.issuer}`);
        continue;
      }

      verified.push({
        claimId: match.claimId,
        claimHash: hashJson(match as unknown as JsonValue),
        issuerKeyFingerprint: publicKeyFingerprint(trusted.publicKeyPem),
      });
    }

    return sortByHash(verified);
  }

  private collectEvidenceRefs(
    proposal: Proposal,
    policy: FiduciaryPolicy,
    evidences: readonly VerifiedEvidenceRef[],
    reasons: string[],
  ): VerifiedEvidenceRefBound[] {
    const refs = new Set(proposal.contextRefs);
    const verified: VerifiedEvidenceRefBound[] = [];

    for (const requiredType of policy.requiredEvidenceTypes ?? []) {
      const match = evidences.find((evidence) => evidence.type === requiredType && refs.has(evidence.evidenceId));
      if (!match) {
        reasons.push(`MISSING_OR_UNBOUND_VERIFIED_EVIDENCE:${requiredType}`);
        continue;
      }
      verified.push({ evidenceId: match.evidenceId, evidenceHash: hashJson(match as unknown as JsonValue) });
    }

    return sortByHash(verified);
  }

  private evaluateConstraint(parameters: Record<string, JsonValue>, constraint: PolicyConstraint): boolean {
    const value = parameters[constraint.field];
    if (typeof value === "undefined") return false;

    switch (constraint.operator) {
      case "eq":
        return canonicalizeJson(value) === canonicalizeJson(constraint.value);
      case "neq":
        return canonicalizeJson(value) !== canonicalizeJson(constraint.value);
      case "lte":
        return typeof value === "number" && typeof constraint.value === "number" && value <= constraint.value;
      case "gte":
        return typeof value === "number" && typeof constraint.value === "number" && value >= constraint.value;
      case "contains":
        return Array.isArray(value) && value.some((item) => canonicalizeJson(item) === canonicalizeJson(constraint.value));
      default:
        return false;
    }
  }

  private buildDecision(input: Omit<AdmissionDecision, "admissionId" | "admissionHash">): AdmissionDecision {
    const admissionHash = computeAdmissionHash(input);
    const admissionId = computeAdmissionId(admissionHash);
    const body = {
      proposalHash: input.proposalHash,
      policyId: input.policyId,
      policyVersion: input.policyVersion,
      policyHash: input.policyHash,
      result: input.result,
      reasons: [...input.reasons].sort(),
      verifiedAuthorityClaims: sortByHash(input.verifiedAuthorityClaims),
      verifiedEvidences: sortByHash(input.verifiedEvidences),
      evaluatedAt: input.evaluatedAt,
    };
    return { admissionId, ...body, admissionHash };
  }
}

function sortByHash<T>(items: readonly T[]): T[] {
  return [...items].sort((a, b) => hashJson(a as unknown as JsonValue).localeCompare(hashJson(b as unknown as JsonValue)));
}

function sortTrustedIssuers(issuers: readonly TrustedIssuer[]): TrustedIssuer[] {
  return [...issuers].sort((a, b) => {
    const byId = a.issuerId.localeCompare(b.issuerId);
    if (byId !== 0) return byId;
    return publicKeyFingerprint(a.publicKeyPem).localeCompare(publicKeyFingerprint(b.publicKeyPem));
  });
}

function hasConflictingTrustedIssuers(issuers: readonly TrustedIssuer[]): boolean {
  const fingerprints = new Map<string, string>();
  for (const issuer of issuers) {
    const fp = publicKeyFingerprint(issuer.publicKeyPem);
    const existing = fingerprints.get(issuer.issuerId);
    if (existing && existing !== fp) return true;
    fingerprints.set(issuer.issuerId, fp);
  }
  return false;
}

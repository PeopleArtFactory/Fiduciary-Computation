import type { BenchmarkId } from "./config.js";

export interface BenchmarkSample {
  benchmark: BenchmarkId;
  iteration: number;
  durationNs: string;
  success: boolean;
  meta?: Record<string, string | number | boolean>;
}

export interface DistributionSummary {
  samples: number;
  minMs: number;
  medianMs: number;
  p95Ms: number;
  p99Ms: number;
  maxMs: number;
  throughputOpsPerSec?: number;
}

export async function measure(
  benchmark: BenchmarkId,
  iteration: number,
  operation: () => void | Promise<void>,
  meta?: BenchmarkSample["meta"],
): Promise<BenchmarkSample> {
  const start = process.hrtime.bigint();
  try {
    await operation();
    const end = process.hrtime.bigint();
    return {
      benchmark,
      iteration,
      durationNs: (end - start).toString(),
      success: true,
      ...(meta ? { meta } : {}),
    };
  } catch (error) {
    const end = process.hrtime.bigint();
    return {
      benchmark,
      iteration,
      durationNs: (end - start).toString(),
      success: false,
      meta: {
        ...(meta ?? {}),
        error: error instanceof Error ? error.message : String(error),
      },
    };
  }
}

export function summarize(samples: readonly BenchmarkSample[]): DistributionSummary {
  const ok = samples.filter((s) => s.success);
  if (ok.length === 0) {
    throw new Error("INVALID_MEASUREMENT: no successful samples");
  }
  const ns = ok.map((s) => BigInt(s.durationNs)).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  const pick = (p: number): bigint => {
    const idx = Math.min(ns.length - 1, Math.max(0, Math.ceil((p / 100) * ns.length) - 1));
    return ns[idx]!;
  };
  const toMs = (v: bigint) => Number(v) / 1e6;
  const totalNs = ns.reduce((a, b) => a + b, 0n);
  const throughputOpsPerSec = totalNs > 0n ? Number(ok.length) / (Number(totalNs) / 1e9) : undefined;
  return {
    samples: ok.length,
    minMs: toMs(ns[0]!),
    medianMs: toMs(pick(50)),
    p95Ms: toMs(pick(95)),
    p99Ms: toMs(pick(99)),
    maxMs: toMs(ns[ns.length - 1]!),
    throughputOpsPerSec,
  };
}

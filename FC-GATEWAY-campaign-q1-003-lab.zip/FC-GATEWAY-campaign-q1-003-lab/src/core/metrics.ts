import type { FiduciaryMetrics } from "./types.js";

export function computeKernelMetrics(metrics: FiduciaryMetrics) {
  return {
    ASR: ratio(metrics.adversarialSuccesses, metrics.adversarialAttempts),
    UCR: ratio(metrics.unsanctionedExecutions, metrics.protectedExecutions),
    AD: ratio(metrics.deterministicAdmissions, metrics.repeatedAdmissions),
    ELC: ratio(metrics.preparedLineageCount, metrics.protectedExecutionAttempts),
    FCC: ratio(metrics.closureCount, metrics.preparedCount),
  };
}

function ratio(numerator: number, denominator: number): number {
  return denominator === 0 ? 0 : numerator / denominator;
}

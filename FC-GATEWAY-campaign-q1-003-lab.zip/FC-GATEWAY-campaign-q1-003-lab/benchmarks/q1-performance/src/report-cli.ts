import * as fs from "node:fs";
import * as path from "node:path";
import { FREEZE } from "./config.js";
import type { EnvironmentRecord } from "./environment.js";
import { environmentHash } from "./environment.js";
import { buildReport, writeReportOutputs, type RawBundle } from "./report.js";
import type { BenchmarkSample } from "./statistics.js";

function loadJson<T>(file: string): T {
  return JSON.parse(fs.readFileSync(file, "utf8")) as T;
}

function unwrapRawSamples(data: unknown): BenchmarkSample[] {
  if (Array.isArray(data)) return data as BenchmarkSample[];
  if (data && typeof data === "object" && Array.isArray((data as { samples?: unknown }).samples)) {
    return (data as { samples: BenchmarkSample[] }).samples;
  }
  throw new Error("INVALID_MEASUREMENT: raw file missing samples array");
}

function main(): void {
  const outputDir = process.argv.slice(2).find((a) => a !== "--");
  if (!outputDir) {
    console.error("usage: report-cli <results-dir>");
    process.exit(2);
  }
  const env = loadJson<EnvironmentRecord>(path.join(outputDir, "environment.json"));
  const envHash = environmentHash(env);
  const raw: RawBundle = {};
  const maybe = (name: string) => {
    const p = path.join(outputDir, name);
    return fs.existsSync(p) ? loadJson<unknown>(p) : undefined;
  };

  const b0 = maybe("B0-direct.raw.json");
  const b1 = maybe("B1-admission.raw.json");
  const b2 = maybe("B2-capability.raw.json");
  const b3 = maybe("B3-prepared.raw.json");
  const b4 = maybe("B4-end-to-end.raw.json");
  const b6 = maybe("B6-recovery.raw.json");
  if (b0) raw.B0 = unwrapRawSamples(b0);
  if (b1) raw.B1 = unwrapRawSamples(b1);
  if (b2) raw.B2 = unwrapRawSamples(b2);
  if (b3) raw.B3 = unwrapRawSamples(b3);
  if (b4) raw.B4 = unwrapRawSamples(b4);
  if (b6) raw.B6 = unwrapRawSamples(b6);

  // Prefer per-size B5 envelopes; fall back to legacy combined raw.
  const b5Blocks: NonNullable<RawBundle["B5"]> = [];
  for (const size of env.parameters.lineageSizes) {
    const p = path.join(outputDir, `B5-verification-N${size}.raw.json`);
    if (fs.existsSync(p)) {
      const envelope = loadJson<{ samples: BenchmarkSample[]; lineageSize?: number }>(p);
      b5Blocks.push({ lineageSize: size, samples: unwrapRawSamples(envelope) });
    }
  }
  if (b5Blocks.length) {
    raw.B5 = b5Blocks;
  } else {
    const legacy = maybe("B5-verification.raw.json");
    if (legacy) raw.B5 = legacy as RawBundle["B5"];
  }

  const { status, summary, summaryMd, benchmarkHash } = buildReport({
    outputDir,
    env,
    envHash,
    raw,
    samples: env.parameters.samples,
    lineageSizes: env.parameters.lineageSizes,
  });
  writeReportOutputs(outputDir, summary, summaryMd);
  console.log(
    JSON.stringify(
      {
        status,
        artifact: FREEZE,
        environmentHash: envHash,
        generatorHash: env.generator?.generatorHash,
        specHash: env.specHash,
        benchmarkHash,
        note: "Regenerated from raw files; H_benchmark must match prior run if raws unchanged.",
      },
      null,
      2,
    ),
  );
  if (status !== "VALID_MEASUREMENT") process.exitCode = 2;
}

main();

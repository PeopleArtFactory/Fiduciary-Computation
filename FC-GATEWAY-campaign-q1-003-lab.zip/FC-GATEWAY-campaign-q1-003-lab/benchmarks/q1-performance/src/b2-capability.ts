import { assertValidCapabilityToken, issueCapabilityToken } from "../../../dist/src/index.js";
import { measure, type BenchmarkSample } from "./statistics.js";
import { makeProposal, openSession, type BenchFixture, HMAC_SECRET } from "./fixtures.js";

export async function runB2(fx: BenchFixture, samples: number, warmup: number): Promise<BenchmarkSample[]> {
  const session = openSession(fx, "b2");

  const prepare = (iteration: number) => {
    const proposal = makeProposal(iteration, fx.evidence.evidenceId);
    const decision = session.gateway.evaluate(proposal, [fx.claim], [fx.evidence]);
    if (decision.result !== "ADMIT") throw new Error("B2 ADMIT failed");
    return { proposal, decision };
  };

  for (let i = 0; i < warmup; i++) {
    const { proposal, decision } = prepare(i);
    const capability = issueCapabilityToken(decision, proposal, {
      issuer: "fc-gateway",
      audience: "fiduciary-executor",
      fiduciaryClock: fx.clock,
      hmacSecret: HMAC_SECRET,
    });
    assertValidCapabilityToken(capability, decision, proposal, {
      expectedIssuer: "fc-gateway",
      expectedAudience: "fiduciary-executor",
      fiduciaryClock: fx.clock,
      hmacSecret: HMAC_SECRET,
    });
  }

  const out: BenchmarkSample[] = [];
  for (let i = 0; i < samples; i++) {
    // Admission is setup outside the timer; B2 isolates issue+validate.
    const { proposal, decision } = prepare(warmup + i);
    let capabilityOk = false;
    const sample = await measure("B2", i, () => {
      const capability = issueCapabilityToken(decision, proposal, {
        issuer: "fc-gateway",
        audience: "fiduciary-executor",
        fiduciaryClock: fx.clock,
        hmacSecret: HMAC_SECRET,
      });
      assertValidCapabilityToken(capability, decision, proposal, {
        expectedIssuer: "fc-gateway",
        expectedAudience: "fiduciary-executor",
        fiduciaryClock: fx.clock,
        hmacSecret: HMAC_SECRET,
      });
      capabilityOk = true;
    });
    if (!sample.success) throw new Error(`INVALID_MEASUREMENT: B2 failed at ${i}: ${sample.meta?.error}`);
    if (!capabilityOk) throw new Error(`INVALID_MEASUREMENT: B2 capability path incomplete at ${i}`);
    out.push(sample);
  }
  return out;
}
